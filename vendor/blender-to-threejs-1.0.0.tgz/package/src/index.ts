/**
 * Public surface of the node system.
 *
 * What's exported here is what an application is allowed to depend on: build a
 * graph, evaluate it on the CPU, compile it to TSL. Everything else in src/ is
 * either a consumer of this surface (preview, probe, recipes) or an
 * implementation detail behind it (the emitter tables, the reference ops).
 *
 * The split matters because the guarantees only hold for graphs that route
 * through the builder. A caller that reaches past this into the TSL emitters
 * and hand-assembles a material gets TSL's semantics, not Blender's — which is
 * the exact failure this project exists to prevent.
 *
 * `three` is a peer dependency, not a dependency. Two copies of three in one
 * bundle means two separate TSL node registries, and nodes built by one are not
 * recognised by the other's compiler — a failure that surfaces as a blank
 * material rather than an error.
 */

/* The authoring surface. Start here. */
export {
  Graph,
  graph,
  type Channel,
  type MapRangeOptions,
  type MathOptions,
  type MixOptions,
  type Space,
} from './graph/builder';

/* Reference ops the graph is defined in terms of. Exported so an application
 * can describe a Color Ramp's stops without reaching into the transpiler. */
export {
  COLOR_RAMP_RESOLUTION,
  bakeColorRamp,
  colorMapCoordinate,
  evalColorRamp,
  hashVec2ToVec3,
  mixSoftLight,
  voronoiColorF1,
  type ColorStop,
  type RampInterpolation,
  type Vec4,
} from './transpiler/blender-ops';

/* The graph model the builder produces. */
export {
  isColor,
  isNode,
  type Color,
  type GraphNode,
  type GraphValue,
  type NodeInput,
  type Scalar,
} from './graph/types';

/* GPU backend: emit TSL, or a material ready to put on a mesh. */
export {
  compile,
  compileMaterial,
  compileNode,
  emittableTypes,
  isEmittable,
  type Emitted,
  type Kind,
  type TSLNode,
} from './graph/compile';

/* CPU backend: constant-folding and the test harness. Throws rather than
 * inventing a value for anything that varies per fragment. */
export {
  evaluableTypes,
  evaluate,
  evaluateColor,
  evaluateScalar,
  isEvaluable,
} from './graph/evaluate';

/* Grease Pencil Line Art as geometry. A geometric edge tracer, not a sobel:
 * contour, crease and boundary edges classified off the mesh, which is what
 * draws a panel line between two nearly-coplanar faces that no depth pass can
 * see and what avoids firing on every stroke of a hatched surface. */
export {
  BLENDER_CREASE_THRESHOLD,
  lineArtEdges,
  lineArtSegments,
  type LineArtEdges,
  type LineArtOptions,
} from './primitives/line-art';

/* IR -> Graph. Export a .blend's node tree with tools/export_material_nodes.py,
 * hand the JSON to buildMaterialFromIR, and the material comes out the same
 * every time. This is the deterministic path; hand-transcribing a graph is the
 * one where sockets go missing. */
export {
  buildMaterialFromIR,
  irCoverage,
  irEmittableTypes,
  IRBuildError,
  type GeneratedBounds,
  type IRBuildOptions,
  type IRBuildResult,
} from './ir/build';
export type { IRGraph, IRLink, IRNode, IRSocket, IRTree } from './ir/types';

/* Blender's world into Three's: axes, and what a lens in millimetres means as
 * a vertical field of view. A ported material under an unported camera and rig
 * is not a ported look. */
export {
  blenderFovX,
  blenderFovY,
  blenderMatrixToThree,
  blenderToThree,
  vectorToThree,
  type BlenderCamera,
} from './scene/blender-space';

/* The light set a Diffuse BSDF is shaded against. A Blender scene's rig is not
 * a detail an application can be expected to reinvent: a sun is a direction and
 * an irradiance, a point light is a position and a wattage that falls off, and
 * getting the second one wrong is the difference between a shader that reads
 * and one that prints blank. */
export {
  DEFAULT_LIGHTS,
  POINT_INTENSITY,
  exposureGain,
  lightStrength,
  pointIrradiance,
  type PointLight,
  type SketchLight,
  type SunLight,
} from './primitives/eevee-lighting';

/* Engine-side post primitives (fidelity: approximate). Screen-space
 * stylisation over a rendered scene; materials stay physically meaningful. */
export {
  CASINO_PALETTE,
  MONO_PALETTE,
  createMangaPost,
  mangaNode,
  type MangaPalette,
  type MangaPassOptions,
  type MangaUniform,
  type MangaUniforms,
} from './primitives/manga-pass';

/* Compositor domain: Blender compositor semantics over whole images. Author
 * with compGraph(), evaluate on the CPU, or run live with Compositor. */
export {
  CompGraph,
  compGraph,
  type CompChannel,
  type CoordinateMode,
  type CustomNodeSpec,
  type ImageFit,
} from './comp/builder';
export {
  COMP_FIDELITY,
  isCompColor,
  isCompNode,
  type CompColor,
  type CompFidelity,
  type CompInput,
  type CompNode,
  type CompScalar,
  type CompValue,
} from './comp/types';
export {
  compEvaluableTypes,
  evaluateComp,
  renderComp,
  sampleBilinear,
  type CompEvalContext,
  type CompImage,
  type Field,
} from './comp/evaluate';
export { compEmittableTypes, compileComp, type CompCompileOptions, type CompEmit, type CompStage, type CompiledComp } from './comp/compile';
export { Compositor, type CompositorOptions } from './comp/compositor';
/** Decals (transparent quads) are kept out of the position and occluder passes: see comp/decal.ts. */
export { skipsPosition, type DecalCandidate } from './comp/decal';
export * as compOps from './comp/comp-ops';
export { fbm, mangaTone, paperGrain, valueNoise } from './comp/custom-nodes';
export { mangaGraph, type MangaCompOptions } from './recipes/manga-comp';
export { watercolorGraph, type WatercolorOptions } from './recipes/watercolor-comp';
export { applyPainterlyStyle, type PainterlyHandle, type PainterlyOptions } from './recipes/painterly-material';
export { bakeMapToVertexColors, flipInwardFaces, laplacianSmooth, taubinSmooth, weldPositionColor } from './primitives/meshtools';
export { feltMaterialGraph, watercolorMaterialGraph, type FeltOptions, type WatercolorMaterialOptions } from './recipes/watercolor-material';
export { LABELS as NODE_LABELS, deserializeGraph, layoutGraph, openInViewer, renderSVG, serializeGraph, type AnyNode, type Layout } from './viewer/layout';
export { getGraph, listGraphs, registerGraph, type GraphEntry } from './viewer/registry';
export { growFromImpact, revealMask, smoothStep, type RevealOptions } from './recipes/reveal';
export { materialUniforms, type CompileMaterialOptions } from './graph/compile';

/** Measuring imported props: the rotation a glTF export baked into the vertices, and the face a prop rests on. */
export { bakedSpin, unbakeSpin, contactPlane, planeAt, planeTilt, type BakedSpinOptions, type ContactPlane, type ContactPlaneOptions } from './stage/prop-measure';

/** In-page set dressing: TransformControls over named objects, layout JSON out, applyLayout in. */
export { SetEditor, applyLayout, readTransform, writeTransform, type Layout as StageLayout, type LayoutEntry as StageLayoutEntry, type SetEditorEntryOptions, type TransformMode } from './stage/set-editor';
/** Blender's modal transforms as a headless input controller: G / S / R, axis constraint, typed amounts. */
export { modalTransform, type ModalAxis, type ModalGesture, type ModalMode, type ModalTransformHandle, type ModalTransformOptions } from './stage/modal-transform';
export { SceneEditor, type SceneEditorEntry, type SceneEditorNode } from './stage/scene-editor';
export { transformGesture, type TransformPose, type TransformView } from './stage/transform-gesture';
export { withOverlay, collectOverlays, drawOverlays } from './comp/overlay';
export { spotLamp, lit, type SpotLampOptions } from './recipes/lamp';

/* Panels: drive a scene from a window on another monitor.
 *
 * Exported from the public surface because the app owns the rendering — the
 * schema and the transport are the library's, the React that draws a slider is
 * not. Keeping the model here and the view in the app is what lets a plain-DOM
 * page host a panel too. */
export {
  PANEL_CHANNEL,
  PROTOCOL_VERSION,
  PanelClient,
  PanelHost,
  findById,
  hasKey,
  isEditable,
  listScreens,
  outline,
  placeOn,
  precisionOf,
  requestScreens,
  screensSupported,
  type ButtonControl,
  type Control,
  type EditableControl,
  type PanelBinding,
  type PanelHostOptions,
  type PanelSchema,
  type PanelSnapshot,
  type PanelValue,
  type ReadoutControl,
  type ScreenInfo,
  type SectionControl,
  type SelectControl,
  type SliderControl,
  type OutlineOptions,
  type SnippetControl,
  type SvgControl,
  type ToggleControl,
  type TreeControl,
  type TreeNode,
} from './panels';
