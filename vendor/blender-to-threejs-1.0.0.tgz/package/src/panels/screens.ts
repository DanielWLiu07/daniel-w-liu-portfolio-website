/**
 * Putting a panel on the OTHER monitor.
 *
 * `window.open` with left/top coordinates is the old way and it does not work
 * across screens: the coordinates are interpreted against the current screen,
 * so a panel aimed at a second monitor lands clamped to the edge of the first.
 * The Window Management API is the one that knows about multiple screens —
 * `getScreenDetails()` returns their real geometry in a shared coordinate
 * space, and coordinates from it place windows correctly.
 *
 * It needs permission ("window-management"), which needs a user gesture, and it
 * only exists in Chromium. Everything here degrades: no API or no permission
 * means the panel still opens, it just opens wherever the browser felt like.
 * That is a worse experience, not a broken one, so nothing here throws.
 */

/** A screen we can place a window on. Flattened from the browser's shape. */
export interface ScreenInfo {
  readonly id: string;
  readonly label: string;
  readonly left: number;
  readonly top: number;
  readonly width: number;
  readonly height: number;
  readonly primary: boolean;
  /** True for the screen the calling window is currently on. */
  readonly current: boolean;
}

/** Minimal shape of what getScreenDetails returns, so we need no DOM lib update. */
interface RawScreen {
  availLeft?: number;
  availTop?: number;
  availWidth?: number;
  availHeight?: number;
  left?: number;
  top?: number;
  width?: number;
  height?: number;
  label?: string;
  isPrimary?: boolean;
  isInternal?: boolean;
}
interface ScreenDetails {
  screens: RawScreen[];
  currentScreen: RawScreen;
}

function api(): (() => Promise<ScreenDetails>) | null {
  const w = window as unknown as {
    getScreenDetails?: () => Promise<ScreenDetails>;
  };
  return typeof w.getScreenDetails === 'function'
    ? w.getScreenDetails.bind(w)
    : null;
}

export function screensSupported(): boolean {
  return api() !== null;
}

/**
 * List the screens.
 *
 * Returns a single entry describing the current window's screen when the API
 * is missing, so callers can render the same UI either way rather than
 * branching on support.
 */
export async function listScreens(): Promise<ScreenInfo[]> {
  const get = api();
  if (!get) {
    return [
      {
        id: 'current',
        label: 'this screen',
        left: 0,
        top: 0,
        width: window.screen.width,
        height: window.screen.height,
        primary: true,
        current: true,
      },
    ];
  }
  try {
    const details = await get();
    return details.screens.map((s, i) => ({
      id: String(i),
      label: s.label || (s.isInternal ? 'built-in' : `screen ${i + 1}`),
      // avail* excludes the menu bar and dock, which is what a window can
      // actually occupy. Falling back to the full bounds when absent.
      left: s.availLeft ?? s.left ?? 0,
      top: s.availTop ?? s.top ?? 0,
      width: s.availWidth ?? s.width ?? 0,
      height: s.availHeight ?? s.height ?? 0,
      primary: Boolean(s.isPrimary),
      current: s === details.currentScreen,
    }));
  } catch {
    // Permission denied, or the API exists but is unavailable in this context.
    return [];
  }
}

/**
 * Ask for permission, from inside a user gesture.
 *
 * Returns whether placement will work. Calling `getScreenDetails` IS the
 * permission prompt, so there is nothing separate to request.
 */
export async function requestScreens(): Promise<boolean> {
  const get = api();
  if (!get) return false;
  try {
    await get();
    return true;
  } catch {
    return false;
  }
}

/**
 * Window features that place a popup on a given screen.
 *
 * Centred by default, because a window pinned to a screen's top-left corner
 * sits under the menu bar on macOS even when using availTop.
 */
export function placeOn(
  screen: ScreenInfo,
  width: number,
  height: number,
  align: 'center' | 'top-left' | 'top-right' = 'center',
): string {
  const w = Math.min(width, screen.width);
  const h = Math.min(height, screen.height);
  let left = screen.left + Math.round((screen.width - w) / 2);
  let top = screen.top + Math.round((screen.height - h) / 2);
  if (align === 'top-left') {
    left = screen.left;
    top = screen.top;
  } else if (align === 'top-right') {
    left = screen.left + screen.width - w;
    top = screen.top;
  }
  return `popup=yes,width=${w},height=${h},left=${left},top=${top}`;
}
