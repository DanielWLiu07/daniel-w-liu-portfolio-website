/**
 * The scene window's side of a torn-off panel.
 *
 * Owns the values, answers panels that announce themselves, and pushes
 * measured readouts. Framework-agnostic on purpose: this is a class with
 * callbacks, so the React binding is thin and a plain-DOM page can use it too.
 *
 * Usage
 *   const host = new PanelHost();
 *   host.register(RUN_PANEL, { get: () => tuning, set: (v) => setTuning(v) });
 *   host.open('run');                       // must be inside a click handler
 *   host.readouts('run', { beak: 12.4 });   // per frame is fine, it throttles
 *   host.dispose();
 *
 * The host is authoritative. Panels send intent; the host applies it and echoes
 * the result to every panel. A value the host clamps or ignores therefore shows
 * up corrected in the panel instead of the two drifting apart.
 */
import {
  PANEL_CHANNEL,
  PROTOCOL_VERSION,
  isPanelMessage,
  type PanelMessage,
} from './protocol';
import { placeOn, type ScreenInfo } from './screens';
import {
  isEditable,
  type PanelSchema,
  type PanelValue,
  type TreeNode,
} from './schema';

/** How the host reaches the application's state for one panel. */
export interface PanelBinding {
  /** Current editable values. Called whenever a panel needs a refresh. */
  get(): Readonly<Record<string, PanelValue>>;
  /** Apply one edit. The host re-reads through `get` afterwards. */
  set(key: string, value: PanelValue): void;
  /** A button was pressed. */
  press?(key: string): void;
  /** Text blocks the panel offers for copying, e.g. values printed as source. */
  snippets?(): Readonly<Record<string, string>>;
  /** Hierarchies to show, keyed by tree control. Walked on demand, not per frame. */
  trees?(): Readonly<Record<string, readonly TreeNode[]>>;
  /**
   * A row in a hierarchy was clicked. `visible` present means show/hide it.
   *
   * Unlike `set`, the host cannot validate the target against the schema — it
   * names a scene object, not a declared control — so the implementation must
   * look it up in the live graph and ignore anything it does not recognise.
   */
  select?(key: string, node: string, visible?: boolean): void;
}

/**
 * Milliseconds between readout pushes.
 *
 * Readouts are fed from the frame loop, so they arrive at 60-120Hz. Posting
 * that rate down a BroadcastChannel is pointless — nothing can read numbers
 * that fast — and it is enough serialisation to show up in a frame budget.
 * Ten a second is comfortably faster than the eye tracks a changing digit.
 */
const READOUT_INTERVAL = 100;

interface Entry {
  schema: PanelSchema;
  binding: PanelBinding;
  /** Latest measured values, coalesced between pushes. */
  readouts: Record<string, number>;
  /** True when readouts changed since the last push. */
  dirty: boolean;
  /** The popup, when this host opened it. Null if the panel was opened by hand. */
  win: Window | null;
}

export interface PanelHostOptions {
  /**
   * Where a panel window lives. Receives the panel id, returns a URL.
   *
   * Defaults to `/panel/<id>` — a PATH rather than a query string, so the app
   * can server-render the window's title from it. A panel is its own OS window
   * and its title bar is the only label distinguishing three of them parked in
   * a row; setting document.title from the client does not survive a framework
   * that re-asserts its own metadata.
   */
  url?: (id: string) => string;
  /** Channel name, if one page needs more than one independent bus. */
  channel?: string;
}

export class PanelHost {
  private readonly bus: BroadcastChannel;
  private readonly entries = new Map<string, Entry>();
  private readonly url: (id: string) => string;
  private timer: ReturnType<typeof setInterval> | null = null;
  private disposed = false;

  constructor(options: PanelHostOptions = {}) {
    this.url = options.url ?? ((id) => `/panel/${encodeURIComponent(id)}`);
    this.bus = new BroadcastChannel(options.channel ?? PANEL_CHANNEL);
    this.bus.onmessage = (e) => this.onMessage(e.data);
    // A scene that goes away without saying so leaves every panel showing stale
    // numbers as though they were live, which is worse than showing nothing.
    //
    // Guarded because `window` is absent under server rendering and in Node.
    // BroadcastChannel exists in both, so the rest of this class works there —
    // and a library that throws on construct outside a browser is a trap for
    // any framework that renders on the server first.
    if (typeof window !== 'undefined') {
      window.addEventListener('pagehide', this.sayBye);
    }
  }

  private readonly sayBye = () => {
    if (this.disposed) return;
    this.post({ t: 'bye', v: PROTOCOL_VERSION });
  };

  /** Declare a panel. Registering does not open it. */
  register(schema: PanelSchema, binding: PanelBinding): void {
    this.entries.set(schema.id, {
      schema,
      binding,
      readouts: {},
      dirty: false,
      win: null,
    });
    // A panel window already open from before this registration — a reloaded
    // scene page is the common case — is waiting on a hello that will never be
    // repeated. Announce instead of making it poll.
    this.sendSchema(schema.id);
  }

  unregister(id: string): void {
    this.entries.delete(id);
  }

  /**
   * Open a panel in its own window, optionally on a named screen.
   *
   * MUST be called from a user gesture; browsers block `window.open` otherwise
   * and return null, which this reports rather than swallowing. Reopening an
   * already-open panel focuses it instead of spawning a second one.
   *
   * Pass a screen from `listScreens()` to put it on another monitor. Without
   * one the browser decides, which in practice means on top of the scene.
   */
  open(id: string, screen?: ScreenInfo): Window | null {
    const entry = this.entries.get(id);
    if (!entry) throw new Error(`[panels] no panel registered as "${id}"`);
    if (entry.win && !entry.win.closed) {
      entry.win.focus();
      return entry.win;
    }
    const w = entry.schema.width ?? 340;
    const h = entry.schema.height ?? 520;
    const features = screen
      ? placeOn(screen, w, h)
      : `popup=yes,width=${w},height=${h}`;
    const win = window.open(
      this.url(id),
      // Named, so the browser reuses the same window for the same panel rather
      // than stacking duplicates every time the button is pressed.
      `b2t-panel-${id}`,
      features,
    );
    entry.win = win;
    if (!win && typeof console !== 'undefined') {
      console.warn(
        `[panels] the browser blocked the "${id}" window. ` +
          'window.open only works from a user gesture, and popups must be ' +
          `allowed for this origin. The panel is also reachable at ${this.url(id)}.`,
      );
    }
    return win;
  }

  /**
   * Open a named set of panels at once — Blender's workspace tabs.
   *
   * "Shading" wants the outliner and the shader editor; "Layout" wants the
   * outliner and the properties. In Blender those are tab-switched screen
   * layouts; here they are window SETS, because the windows are the layout.
   *
   * Spread across the given screens round-robin when more than one is offered,
   * so a two-monitor desk gets the panels distributed rather than stacked.
   * Must be called from a user gesture like `open`, and browsers rate-limit
   * several `window.open` calls from one gesture — so this reports what it
   * actually managed to open rather than assuming.
   */
  openWorkspace(ids: readonly string[], screens: readonly ScreenInfo[] = []): string[] {
    const opened: string[] = [];
    ids.forEach((id, i) => {
      if (!this.entries.has(id)) return;
      const screen = screens.length ? screens[i % screens.length] : undefined;
      if (this.open(id, screen)) opened.push(id);
    });
    return opened;
  }

  /** Close a panel this host opened. Panels opened by hand are left alone. */
  close(id: string): void {
    const entry = this.entries.get(id);
    if (entry?.win && !entry.win.closed) entry.win.close();
    if (entry) entry.win = null;
  }

  isOpen(id: string): boolean {
    const w = this.entries.get(id)?.win;
    return Boolean(w && !w.closed);
  }

  /**
   * Push measured values. Safe to call every frame — coalesced and throttled.
   */
  readouts(id: string, values: Readonly<Record<string, number>>): void {
    const entry = this.entries.get(id);
    if (!entry) return;
    for (const [k, v] of Object.entries(values)) {
      if (entry.readouts[k] !== v) {
        entry.readouts[k] = v;
        entry.dirty = true;
      }
    }
    if (entry.dirty && this.timer === null) {
      this.timer = setInterval(() => this.flush(), READOUT_INTERVAL);
    }
  }

  /**
   * Tell every panel the values changed underneath them.
   *
   * Needed when the application edits state itself — a reset button in the
   * page, a preset loaded, values restored from storage. Without it the panel
   * keeps showing what it last sent.
   */
  refresh(id: string): void {
    this.sendValues(id);
  }

  dispose(): void {
    this.disposed = true;
    if (typeof window !== 'undefined') {
      window.removeEventListener('pagehide', this.sayBye);
    }
    if (this.timer !== null) clearInterval(this.timer);
    this.timer = null;
    this.post({ t: 'bye', v: PROTOCOL_VERSION });
    this.bus.close();
    this.entries.clear();
  }

  private flush(): void {
    let any = false;
    for (const [id, entry] of this.entries) {
      if (!entry.dirty) continue;
      entry.dirty = false;
      any = true;
      this.post({
        t: 'readouts',
        v: PROTOCOL_VERSION,
        panel: id,
        readouts: { ...entry.readouts },
      });
    }
    // Idle hosts should not hold a timer. It restarts on the next readout.
    if (!any && this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private onMessage(data: unknown): void {
    if (!isPanelMessage(data)) return;
    switch (data.t) {
      case 'hello':
        this.sendSchema(data.panel);
        break;
      case 'set': {
        const entry = this.entries.get(data.panel);
        if (!entry) return;
        // Only controls declared editable may be written. A panel is untrusted
        // in the same sense any other window is: it can post anything.
        const control = entry.schema.controls.find(
          (c) => isEditable(c) && c.key === data.key,
        );
        if (!control) return;
        entry.binding.set(data.key, data.value);
        this.sendValues(data.panel);
        break;
      }
      case 'press': {
        const entry = this.entries.get(data.panel);
        if (!entry) return;
        const control = entry.schema.controls.find(
          (c) => c.kind === 'button' && c.key === data.key,
        );
        if (!control) return;
        entry.binding.press?.(data.key);
        this.sendValues(data.panel);
        break;
      }
      case 'select': {
        const entry = this.entries.get(data.panel);
        if (!entry) return;
        // Only a declared tree control may be targeted. The NODE within it is
        // the binding's business to validate — the host has no view of the
        // scene graph.
        const control = entry.schema.controls.find(
          (c) => c.kind === 'tree' && c.key === data.key,
        );
        if (!control) return;
        entry.binding.select?.(data.key, data.node, data.visible);
        this.sendValues(data.panel);
        break;
      }
      case 'goodbye': {
        const entry = this.entries.get(data.panel);
        if (entry) entry.win = null;
        break;
      }
      default:
        // schema/values/readouts/bye are ours; ignore our own echoes.
        break;
    }
  }

  private sendSchema(id: string): void {
    const entry = this.entries.get(id);
    if (!entry) return;
    this.post({
      t: 'schema',
      v: PROTOCOL_VERSION,
      panel: id,
      schema: entry.schema,
      values: { ...entry.binding.get() },
      readouts: { ...entry.readouts },
      snippets: { ...(entry.binding.snippets?.() ?? {}) },
      trees: { ...(entry.binding.trees?.() ?? {}) },
    });
  }

  private sendValues(id: string): void {
    const entry = this.entries.get(id);
    if (!entry) return;
    this.post({
      t: 'values',
      v: PROTOCOL_VERSION,
      panel: id,
      values: { ...entry.binding.get() },
      snippets: { ...(entry.binding.snippets?.() ?? {}) },
      trees: { ...(entry.binding.trees?.() ?? {}) },
    });
  }

  private post(m: PanelMessage): void {
    try {
      this.bus.postMessage(m);
    } catch {
      // The channel is closed — the page is tearing down mid-flush. Nothing
      // useful to do, and throwing here would be inside an unload handler.
    }
  }
}
