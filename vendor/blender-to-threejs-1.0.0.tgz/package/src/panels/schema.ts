/**
 * What a panel IS, as data.
 *
 * A torn-off panel lives in a different browser window from the scene it
 * drives. Different window means a different JavaScript realm: no shared
 * memory, no shared React tree, no passing a callback. The only thing that
 * crosses is structured-cloneable data.
 *
 * So a panel cannot be a component. It has to be a DESCRIPTION that the panel
 * window renders and a value map that travels back and forth. That constraint
 * is the whole reason this file exists, and it is worth leaning into rather
 * than fighting: a declared panel can also be serialised into a layout, diffed
 * against the last one, and printed back as source — which is what the tuners
 * on the portfolio were hand-rolling one at a time.
 *
 * Controls are deliberately few. Every one here maps to something the existing
 * tuners already do; anything richer belongs in a bespoke editor type, not in
 * the generic schema.
 */

/** A number with a range. The bread and butter of every tuner so far. */
export interface SliderControl {
  readonly kind: 'slider';
  readonly key: string;
  readonly label: string;
  readonly min: number;
  readonly max: number;
  /** Defaults to 0.01, which is what every existing tuner uses. */
  readonly step?: number;
  /**
   * Fixed decimals for the printed value. Defaults to enough to distinguish
   * one step from the next, so a 0.001 step does not display as "0.05".
   */
  readonly precision?: number;
}

/** An on/off. */
export interface ToggleControl {
  readonly kind: 'toggle';
  readonly key: string;
  readonly label: string;
}

/** One of a fixed set. */
export interface SelectControl {
  readonly kind: 'select';
  readonly key: string;
  readonly label: string;
  readonly options: readonly { readonly value: string; readonly label: string }[];
}

/**
 * A value the panel shows but cannot edit — measured off the running scene.
 *
 * These matter as much as the sliders. A coefficient means nothing on its own;
 * what tells you whether a setting is right is what resulted from it. The host
 * pushes these; the panel never sends them.
 */
export interface ReadoutControl {
  readonly kind: 'readout';
  readonly key: string;
  readonly label: string;
  /** Appended to the value, e.g. 'deg', 'mm', 'm/s'. */
  readonly unit?: string;
  readonly precision?: number;
  /**
   * Show the value as a warning above this magnitude. Used for the things that
   * mean "this setting is out of range" — reach-guard drag, clamped joints.
   */
  readonly warnAbove?: number;
}

/** Fires an action on the host. Carries no value. */
export interface ButtonControl {
  readonly kind: 'button';
  readonly key: string;
  readonly label: string;
}

/**
 * Monospace text the panel offers for copying — the tuned values printed back
 * as source. The host owns the string and refreshes it as values change.
 */
export interface SnippetControl {
  readonly kind: 'snippet';
  readonly key: string;
  readonly label: string;
}

/**
 * A rendered picture the host produces — the Shader Editor and Compositor.
 *
 * Rides the same string map as `snippet`, so adding it cost no protocol
 * change: a node graph rendered by `renderSVG` IS a string. The panel draws it
 * as an image rather than injecting the markup, which is both safer (an image
 * cannot execute script, whatever ends up in a node's parameters) and gives
 * pan and zoom for free.
 */
export interface SvgControl {
  readonly kind: 'svg';
  readonly key: string;
  readonly label: string;
}

/**
 * One row of a hierarchy — the Outliner.
 *
 * The scene graph is the one thing a web 3D app has that Blender's outliner
 * shows and nothing else does: what is actually in the scene, what it is, and
 * why that mesh you cannot find is invisible. It is a tree rather than a flat
 * list of controls, so it travels beside the values like a snippet does rather
 * than being encoded as one.
 */
export interface TreeNode {
  readonly id: string;
  readonly name: string;
  /** three's type — Mesh, Bone, Group, SkinnedMesh. Shown as Blender shows it. */
  readonly type: string;
  readonly visible: boolean;
  /** Authoritative selection shared with viewport picking and transforms. */
  readonly selected?: boolean;
  /** Triangles under this node, summed. Absent for nodes that draw nothing. */
  readonly tris?: number;
  readonly children?: readonly TreeNode[];
}

/** A hierarchy view. Data arrives in the `trees` map, keyed by this control. */
export interface TreeControl {
  readonly kind: 'tree';
  readonly key: string;
  readonly label: string;
  /** Omit eye toggles when visibility is animation-owned or read-only. */
  readonly visibility?: boolean;
}

/** A labelled divider. Purely visual grouping within one panel. */
export interface SectionControl {
  readonly kind: 'section';
  readonly label: string;
}

export type Control =
  | SliderControl
  | ToggleControl
  | SelectControl
  | ReadoutControl
  | ButtonControl
  | SnippetControl
  | SvgControl
  | TreeControl
  | SectionControl;

/** Controls that carry an editable value, i.e. everything with a key the panel can set. */
export type EditableControl = SliderControl | ToggleControl | SelectControl;

export type PanelValue = number | boolean | string;

/**
 * A panel definition. Registered on the host; rendered in the panel window.
 *
 * `id` is the address: it goes in the popup's query string and tags every
 * message on the wire, so one channel can carry every panel at once.
 */
export interface PanelSchema {
  readonly id: string;
  readonly title: string;
  readonly controls: readonly Control[];
  /** Opening size hint for the popup, CSS pixels. */
  readonly width?: number;
  readonly height?: number;
}

/** Controls that have a key, narrowed. `section` is the only one without. */
export function hasKey(
  c: Control,
): c is Exclude<Control, SectionControl> {
  return c.kind !== 'section';
}

/** Controls the PANEL may write. Readouts and snippets are host-owned. */
export function isEditable(c: Control): c is EditableControl {
  return c.kind === 'slider' || c.kind === 'toggle' || c.kind === 'select';
}

/**
 * Decimals to print a control's value with.
 *
 * Derived from the step when not stated, because the alternative is every
 * caller specifying it and getting it wrong: a 0.001 step shown at two
 * decimals makes three consecutive positions look identical, which reads as a
 * broken slider.
 */
export function precisionOf(c: Control): number {
  if ('precision' in c && typeof c.precision === 'number') return c.precision;
  if (c.kind === 'slider') {
    const step = c.step ?? 0.01;
    if (step >= 1) return 0;
    // 0.01 -> 2, 0.001 -> 3. Clamped so a pathological step cannot ask for 15.
    return Math.min(6, Math.max(0, Math.ceil(-Math.log10(step))));
  }
  return 2;
}
