/**
 * The torn-off window's side.
 *
 * Knows nothing about what it is driving. It announces itself, receives a
 * schema, renders whatever that says, and posts edits back. That ignorance is
 * the point: one panel route serves every panel in the app, and adding a new
 * one is a registration on the host rather than a new page.
 *
 * Framework-agnostic, like the host. `subscribe` hands you a plain snapshot on
 * every change, which a React binding turns into state and a DOM page reads
 * directly.
 */
import {
  PANEL_CHANNEL,
  PROTOCOL_VERSION,
  isPanelMessage,
  type PanelMessage,
} from './protocol';
import type { PanelSchema, PanelValue, TreeNode } from './schema';

export interface PanelSnapshot {
  /** Null until the host answers. Render a waiting state. */
  readonly schema: PanelSchema | null;
  readonly values: Readonly<Record<string, PanelValue>>;
  readonly readouts: Readonly<Record<string, number>>;
  readonly snippets: Readonly<Record<string, string>>;
  readonly trees: Readonly<Record<string, readonly TreeNode[]>>;
  /**
   * False when the scene window has gone away, or has not answered yet.
   *
   * Worth surfacing in the UI. A panel whose scene has closed still renders
   * its last values perfectly happily, and without this it looks live while
   * driving nothing — which reads as the controls being broken.
   */
  readonly connected: boolean;
}

/**
 * How long to wait for a host before declaring the panel orphaned.
 *
 * Long enough to cover a scene page that is still booting its WebGPU context
 * when the panel opens, short enough that a genuinely absent host is obvious
 * rather than looking like a hang.
 */
const HELLO_TIMEOUT = 4000;

/** Re-announce this often while unanswered, so a later host is found. */
const HELLO_RETRY = 1000;

export class PanelClient {
  private readonly bus: BroadcastChannel;
  private readonly id: string;
  private readonly listeners = new Set<(s: PanelSnapshot) => void>();
  private snapshot: PanelSnapshot = {
    schema: null,
    values: {},
    readouts: {},
    snippets: {},
    trees: {},
    connected: false,
  };
  private retry: ReturnType<typeof setInterval> | null = null;
  private orphanAt = 0;

  constructor(id: string, channel = PANEL_CHANNEL) {
    this.id = id;
    this.bus = new BroadcastChannel(channel);
    this.bus.onmessage = (e) => this.onMessage(e.data);
    this.orphanAt = Date.now() + HELLO_TIMEOUT;
    this.hello();
    this.retry = setInterval(() => {
      if (this.snapshot.connected) return;
      if (Date.now() > this.orphanAt) this.emit({ connected: false });
      this.hello();
    }, HELLO_RETRY);
    // Guarded for the same reason as the host: no window under SSR or in Node.
    if (typeof window !== 'undefined') {
      window.addEventListener('pagehide', this.sayGoodbye);
    }
  }

  private readonly sayGoodbye = () => {
    this.post({ t: 'goodbye', v: PROTOCOL_VERSION, panel: this.id });
  };

  get current(): PanelSnapshot {
    return this.snapshot;
  }

  /** Returns an unsubscribe. Fires immediately with the current snapshot. */
  subscribe(fn: (s: PanelSnapshot) => void): () => void {
    this.listeners.add(fn);
    fn(this.snapshot);
    return () => this.listeners.delete(fn);
  }

  /**
   * Edit a control.
   *
   * Optimistic locally so the slider tracks the pointer without a round trip,
   * but the host's echo is authoritative and will correct this if it clamps.
   */
  set(key: string, value: PanelValue): void {
    this.emit({ values: { ...this.snapshot.values, [key]: value } });
    this.post({ t: 'set', v: PROTOCOL_VERSION, panel: this.id, key, value });
  }

  press(key: string): void {
    this.post({ t: 'press', v: PROTOCOL_VERSION, panel: this.id, key });
  }

  /** Click a hierarchy row, or toggle its visibility. */
  select(key: string, node: string, visible?: boolean): void {
    this.post({ t: 'select', v: PROTOCOL_VERSION, panel: this.id, key, node, visible });
  }

  dispose(): void {
    if (typeof window !== 'undefined') {
      window.removeEventListener('pagehide', this.sayGoodbye);
    }
    if (this.retry !== null) clearInterval(this.retry);
    this.retry = null;
    this.sayGoodbye();
    this.bus.close();
    this.listeners.clear();
  }

  private hello(): void {
    this.post({ t: 'hello', v: PROTOCOL_VERSION, panel: this.id });
  }

  private onMessage(data: unknown): void {
    if (!isPanelMessage(data)) return;
    if (data.t === 'bye') {
      this.emit({ connected: false });
      this.orphanAt = Date.now() + HELLO_TIMEOUT;
      return;
    }
    if (!('panel' in data) || data.panel !== this.id) return;
    switch (data.t) {
      case 'schema':
        this.emit({
          schema: data.schema,
          values: data.values,
          readouts: data.readouts,
          snippets: data.snippets,
          trees: data.trees,
          connected: true,
        });
        break;
      case 'values':
        this.emit({
          values: data.values,
          snippets: data.snippets,
          trees: data.trees,
          connected: true,
        });
        break;
      case 'readouts':
        this.emit({ readouts: data.readouts, connected: true });
        break;
      default:
        // hello/set/press are ours going the other way.
        break;
    }
  }

  private emit(patch: Partial<PanelSnapshot>): void {
    this.snapshot = { ...this.snapshot, ...patch };
    for (const fn of this.listeners) fn(this.snapshot);
  }

  private post(m: PanelMessage): void {
    try {
      this.bus.postMessage(m);
    } catch {
      // Closed channel during teardown; nothing to do.
    }
  }
}
