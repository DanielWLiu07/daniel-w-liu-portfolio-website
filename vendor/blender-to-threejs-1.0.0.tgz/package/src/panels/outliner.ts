/**
 * Blender's Outliner, over a live three.js scene.
 *
 * This is the editor a web 3D app misses most and the one that costs least to
 * build, because the data already exists — `THREE.Scene` IS the hierarchy.
 * What is missing is a way to look at it that is not `console.log(scene)`, and
 * the questions it answers are the ones that actually come up: what is in this
 * scene, what is that object really, and why can I not see the mesh I know I
 * loaded.
 *
 * Walking is deliberately not per-frame. A scene graph changes when something
 * is added or removed, which is rare, whereas a walk allocates a node per
 * object and a 60Hz walk of a rigged character is real garbage. Callers push
 * on load and after they change something.
 *
 * Two Blender behaviours worth keeping, because they are what make an outliner
 * useful rather than decorative:
 *
 *   - Bones are shown, but collapsed by default. A rigged character is 20 bones
 *     against 5 meshes, and expanding it by default buries everything else.
 *   - The triangle count is summed up the tree, so a collapsed group still
 *     tells you what it costs. That is the number you are usually hunting.
 */
import type { Object3D } from 'three';

import type { TreeNode } from './schema';

export interface OutlineOptions {
  /**
   * Skip subtrees under these types. Defaults to none.
   *
   * `Bone` is the usual candidate: a skeleton is a deep tree of objects that
   * draw nothing, and including it makes the outliner mostly bones.
   */
  readonly collapse?: readonly string[];
  /** Stop descending past this depth. Guards against a cyclic or absurd graph. */
  readonly maxDepth?: number;
  /** Skip objects whose name starts with this. Editor helpers usually should. */
  readonly hide?: (o: Object3D) => boolean;
}

/** Triangles a single object draws, or 0. Does not include its children. */
function trisOf(o: Object3D): number {
  const g = (o as { geometry?: { index?: { count: number }; attributes?: { position?: { count: number } } } })
    .geometry;
  if (!g) return 0;
  if (g.index) return g.index.count / 3;
  const pos = g.attributes?.position;
  return pos ? pos.count / 3 : 0;
}

/**
 * A stable id for an object across walks.
 *
 * three's `uuid` is stable for the object's lifetime, which is what a panel
 * needs: the panel sends an id back and the host looks it up. Names are not
 * unique and indices shift when anything is added.
 */
function idOf(o: Object3D): string {
  return o.uuid;
}

/**
 * What to call an object that was never named.
 *
 * Unnamed is the COMMON case in a web scene — anything built in JSX or by a
 * loader that dropped names — and an outliner full of "Mesh, Mesh, Mesh" is
 * not worth opening. Blender never has this problem because a Blender object
 * always has a name, so it is not a behaviour to copy but a gap to fill.
 *
 * The material's name is the best available substitute: it is what the object
 * looks like, which is how you recognise a row against the viewport. Falls
 * back to a short uuid so two anonymous rows are still distinguishable.
 */
function nameOf(o: Object3D): string {
  if (o.name) return o.name;
  const mat = (o as { material?: { name?: string } | { name?: string }[] })
    .material;
  const first = Array.isArray(mat) ? mat[0] : mat;
  if (first?.name) return `<${first.name}>`;
  return `<${o.type} ${o.uuid.slice(0, 4)}>`;
}

/**
 * How Blender labels the thing.
 *
 * three's type names are close but not identical, and the outliner is read at a
 * glance — matching Blender's vocabulary is the difference between recognising
 * a row and parsing it.
 */
function labelType(o: Object3D): string {
  switch (o.type) {
    case 'SkinnedMesh':
      return 'Mesh (skinned)';
    case 'Group':
      return 'Collection';
    case 'Object3D':
      return 'Empty';
    case 'PerspectiveCamera':
    case 'OrthographicCamera':
      return 'Camera';
    case 'DirectionalLight':
    case 'PointLight':
    case 'SpotLight':
    case 'AmbientLight':
    case 'HemisphereLight':
      return 'Light';
    default:
      return o.type;
  }
}

/**
 * Walk a scene into a serialisable tree.
 *
 * Returns the ROOT'S CHILDREN rather than the root itself: a scene's own node
 * carries no information and costs a level of indentation on every row.
 */
export function outline(
  root: Object3D,
  options: OutlineOptions = {},
): TreeNode[] {
  const collapse = new Set(options.collapse ?? []);
  const maxDepth = options.maxDepth ?? 24;
  const hide = options.hide;

  const walk = (o: Object3D, depth: number): TreeNode => {
    const own = trisOf(o);
    let total = own;
    let children: TreeNode[] | undefined;

    if (depth < maxDepth && !collapse.has(o.type) && o.children.length > 0) {
      const kids: TreeNode[] = [];
      for (const c of o.children) {
        if (hide?.(c)) continue;
        const node = walk(c, depth + 1);
        total += node.tris ?? 0;
        kids.push(node);
      }
      if (kids.length) children = kids;
    } else if (o.children.length > 0) {
      // Collapsed, but its cost still belongs to the row above — otherwise a
      // skeleton's meshes vanish from the totals and the numbers stop adding up.
      const sum = (n: Object3D): number =>
        trisOf(n) + n.children.reduce((a, c) => a + sum(c), 0);
      total = sum(o);
    }

    return {
      id: idOf(o),
      name: nameOf(o),
      type: labelType(o),
      visible: o.visible,
      ...(total > 0 ? { tris: Math.round(total) } : {}),
      ...(children ? { children } : {}),
    };
  };

  const out: TreeNode[] = [];
  for (const c of root.children) {
    if (hide?.(c)) continue;
    out.push(walk(c, 0));
  }
  return out;
}

/**
 * Find an object by the id `outline` gave it.
 *
 * The counterpart of the walk: a panel sends an id back and the host has to
 * turn it into an object. Linear, because a scene small enough to outline is
 * small enough to search and an index would need invalidating on every change.
 */
export function findById(root: Object3D, id: string): Object3D | null {
  let found: Object3D | null = null;
  root.traverse((o) => {
    if (!found && idOf(o) === id) found = o;
  });
  return found;
}
