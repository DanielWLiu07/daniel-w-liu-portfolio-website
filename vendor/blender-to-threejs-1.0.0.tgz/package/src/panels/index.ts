/**
 * Panels: drive a scene from a window on another monitor.
 *
 * The scene page stays what it is — a full-bleed 3D viewport with nothing
 * layered over it. Controls live in separate browser windows you tear off and
 * park where you like, which on a two-monitor desk is the difference between
 * tuning a gait and squinting past a floating panel at the thing you are
 * tuning.
 *
 * Three pieces:
 *   schema   what a panel IS, as data — because a different window is a
 *            different JS realm and only data crosses
 *   host     the scene side: owns the values, answers panels, pushes readouts
 *   client   the panel side: renders a schema, posts edits back
 *
 * The host is authoritative throughout. Panels send intent and wait for the
 * echo, so two panels on one control cannot diverge.
 */
export { PanelHost, type PanelBinding, type PanelHostOptions } from './host';
export { PanelClient, type PanelSnapshot } from './client';
export { findById, outline, type OutlineOptions } from './outliner';
export {
  hasKey,
  isEditable,
  precisionOf,
  type ButtonControl,
  type Control,
  type EditableControl,
  type PanelSchema,
  type PanelValue,
  type ReadoutControl,
  type SectionControl,
  type SelectControl,
  type SliderControl,
  type SnippetControl,
  type SvgControl,
  type ToggleControl,
  type TreeControl,
  type TreeNode,
} from './schema';
export {
  listScreens,
  placeOn,
  requestScreens,
  screensSupported,
  type ScreenInfo,
} from './screens';
export { PANEL_CHANNEL, PROTOCOL_VERSION } from './protocol';
