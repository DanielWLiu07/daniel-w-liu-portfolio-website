/**
 * The wire between the scene window and its torn-off panels.
 *
 * Transport is BroadcastChannel rather than the more obvious `window.opener`
 * postMessage, for three reasons that each bit in practice:
 *
 *   1. `opener` is a single link. Two panels driving the same scene, or a panel
 *      that should keep working after you close and reopen another, both need a
 *      bus rather than a wire.
 *   2. `opener` goes null the moment the scene page navigates or is reloaded —
 *      which is constantly, during development. A channel is re-joined by name,
 *      so a reloaded scene finds its panels again without them being reopened.
 *   3. A panel opened by hand (paste the URL onto the second monitor) has no
 *      opener at all, and that is a legitimate way to use this.
 *
 * The cost is that BroadcastChannel is same-origin and same-browser only. Both
 * are fine here: this is a development tool for driving a scene on the next
 * monitor, not a remote control.
 *
 * Message flow, deliberately simple and idempotent:
 *
 *   panel  -> hello         "I am up, tell me everything"
 *   host   -> schema        definition + current values + snippets
 *   panel  -> set           one control changed
 *   host   -> values        authoritative values, echoed to ALL panels
 *   host   -> readouts      measured values, pushed on a throttle
 *   panel  -> press         a button was clicked
 *   host   -> bye           the scene is going away
 *   panel  -> goodbye       this panel is closing
 *
 * The host is authoritative. A panel never assumes its own edit took: it sends
 * `set` and waits for the `values` echo. That is what keeps two panels on the
 * same control from fighting, and it means a rejected or clamped value shows up
 * in the panel rather than silently diverging.
 */
import type { PanelSchema, PanelValue, TreeNode } from './schema';

/** Channel name. One bus for every panel; messages carry their own panel id. */
export const PANEL_CHANNEL = 'b2t-panels';

/** Bumped when the message shape changes; a mismatched peer is ignored. */
export const PROTOCOL_VERSION = 1;

export interface HelloMessage {
  readonly t: 'hello';
  readonly v: number;
  readonly panel: string;
}

export interface SchemaMessage {
  readonly t: 'schema';
  readonly v: number;
  readonly panel: string;
  readonly schema: PanelSchema;
  readonly values: Readonly<Record<string, PanelValue>>;
  readonly readouts: Readonly<Record<string, number>>;
  readonly snippets: Readonly<Record<string, string>>;
  readonly trees: Readonly<Record<string, readonly TreeNode[]>>;
}

export interface SetMessage {
  readonly t: 'set';
  readonly v: number;
  readonly panel: string;
  readonly key: string;
  readonly value: PanelValue;
}

export interface ValuesMessage {
  readonly t: 'values';
  readonly v: number;
  readonly panel: string;
  readonly values: Readonly<Record<string, PanelValue>>;
  readonly snippets: Readonly<Record<string, string>>;
  readonly trees: Readonly<Record<string, readonly TreeNode[]>>;
}

export interface ReadoutsMessage {
  readonly t: 'readouts';
  readonly v: number;
  readonly panel: string;
  readonly readouts: Readonly<Record<string, number>>;
}

/**
 * A row in a hierarchy was clicked, or its visibility toggled.
 *
 * Separate from `set` because the target is a scene object rather than a
 * declared control: the host cannot validate it against the schema and must
 * look it up in the live graph instead.
 */
export interface SelectMessage {
  readonly t: 'select';
  readonly v: number;
  readonly panel: string;
  readonly key: string;
  readonly node: string;
  /** Absent for a plain selection; present to show or hide the node. */
  readonly visible?: boolean;
}

export interface PressMessage {
  readonly t: 'press';
  readonly v: number;
  readonly panel: string;
  readonly key: string;
}

/** The scene window is unloading. Panels grey out rather than lying. */
export interface ByeMessage {
  readonly t: 'bye';
  readonly v: number;
}

export interface GoodbyeMessage {
  readonly t: 'goodbye';
  readonly v: number;
  readonly panel: string;
}

export type PanelMessage =
  | HelloMessage
  | SchemaMessage
  | SetMessage
  | ValuesMessage
  | ReadoutsMessage
  | PressMessage
  | SelectMessage
  | ByeMessage
  | GoodbyeMessage;

/**
 * Is this something we sent, at a version we understand?
 *
 * BroadcastChannel is shared by every tab on the origin, so a message from an
 * unrelated feature — or from a half-reloaded older build during development —
 * will arrive here. Checking rather than assuming is the difference between
 * ignoring it and throwing inside an event handler.
 */
export function isPanelMessage(data: unknown): data is PanelMessage {
  if (typeof data !== 'object' || data === null) return false;
  const m = data as { t?: unknown; v?: unknown };
  return typeof m.t === 'string' && m.v === PROTOCOL_VERSION;
}
