/**
 * Measuring an imported prop before you build on it.
 *
 * A glTF export bakes world transforms into vertices, so a prop authored at an angle in Blender arrives
 * rotated in its own plane with no transform left to read it off. Every bounding box is then inflated by
 * that rotation: a page sized from one overhangs the leaf it sits on, and a hinge built on a bbox edge
 * turns on a skewed axis. Measure the angle, take it out, and the box means what it says again.
 *
 * The second measurement is the surface a prop actually rests on. Modelled assemblies are rarely parallel
 * slabs (a folder rests slightly ajar, a lid sits proud at its hinge), so the face that receives a stacked
 * object is a shallow wedge. Fitting it from the extreme sample in each slice survives that; thresholding
 * on the coordinate does not, because the far end of a wedge can sit entirely past the near end's face.
 *
 * Pure geometry: no materials, no scene graph, nothing from the graph or compositor subsystems.
 */
import * as THREE from 'three';

export interface BakedSpinOptions {
  /** vertices to sample; the angle is stable well below the full count (default 800) */
  samples?: number;
  /** coarse steps over the quarter turn (default 180, i.e. half a degree) */
  coarse?: number;
  /** refinement steps either side of the coarse winner (default 50, i.e. 0.01 degree) */
  refine?: number;
}

/** the two in-plane axes for a piece whose flat direction is `flat` */
function planeAxes(flat: 'x' | 'y' | 'z'): ['x' | 'y' | 'z', 'x' | 'y' | 'z'] {
  if (flat === 'z') return ['x', 'y'];
  if (flat === 'y') return ['z', 'x'];
  return ['y', 'z'];
}

/**
 * The in-plane rotation baked into a flat piece: the angle whose bounding rectangle is tightest, in
 * [0, PI/2). Rotate the geometry by -angle about `flat` to undo it.
 *
 * Only meaningful for a piece with a rectangular footprint (a leaf, a panel, a card, a sheet). Measure it
 * once off the largest flat piece of an assembly and apply the same angle to every piece, so they stay
 * registered to each other.
 */
export function bakedSpin(geometry: THREE.BufferGeometry, flat: 'x' | 'y' | 'z' = 'z', opts: BakedSpinOptions = {}): number {
  const pos = geometry.getAttribute('position') as THREE.BufferAttribute;
  const [ax, ay] = planeAxes(flat);
  const get = (i: number, a: 'x' | 'y' | 'z') => (a === 'x' ? pos.getX(i) : a === 'y' ? pos.getY(i) : pos.getZ(i));
  const step = Math.max(1, Math.floor(pos.count / (opts.samples ?? 800)));
  const us: number[] = [];
  const vs: number[] = [];
  for (let i = 0; i < pos.count; i += step) {
    us.push(get(i, ax));
    vs.push(get(i, ay));
  }
  const area = (t: number) => {
    const c = Math.cos(t);
    const s = Math.sin(t);
    let u0 = Infinity;
    let u1 = -Infinity;
    let v0 = Infinity;
    let v1 = -Infinity;
    for (let i = 0; i < us.length; i++) {
      const u = us[i] * c + vs[i] * s;
      const v = -us[i] * s + vs[i] * c;
      if (u < u0) u0 = u;
      if (u > u1) u1 = u;
      if (v < v0) v0 = v;
      if (v > v1) v1 = v;
    }
    return (u1 - u0) * (v1 - v0);
  };
  const coarse = opts.coarse ?? 180;
  const refine = opts.refine ?? 50;
  let best = 0;
  let bestArea = Infinity;
  for (let k = 0; k < coarse; k++) {
    const t = (k * Math.PI) / (2 * coarse);
    const a = area(t);
    if (a < bestArea) {
      bestArea = a;
      best = t;
    }
  }
  const span = Math.PI / (2 * coarse);
  let refined = best;
  for (let k = -refine; k <= refine; k++) {
    const t = best + (k * span) / refine;
    const a = area(t);
    if (a < bestArea) {
      bestArea = a;
      refined = t;
    }
  }
  return refined;
}

/** Take a baked spin out of every piece of an assembly, in place, and refresh their bounding boxes. */
export function unbakeSpin(geometries: THREE.BufferGeometry[], angle: number, flat: 'x' | 'y' | 'z' = 'z'): void {
  for (const g of geometries) {
    if (flat === 'z') g.rotateZ(-angle);
    else if (flat === 'y') g.rotateY(-angle);
    else g.rotateX(-angle);
    g.computeBoundingBox();
  }
}

/** a face fitted as `at = slope * along + offset` */
export interface ContactPlane {
  slope: number;
  offset: number;
}

export interface ContactPlaneOptions {
  /** the axis the face is measured along (default 'x') */
  along?: 'x' | 'y' | 'z';
  /** the axis the face is measured on (default 'z') */
  at?: 'x' | 'y' | 'z';
  /** which side of the slab: 'min' for the low face, 'max' for the high one (default 'min') */
  side?: 'min' | 'max';
  /** slices along `along` (default 24) */
  bins?: number;
}

/**
 * Fit the plane of one face of a slab, as `at = slope * along + offset`.
 *
 * Takes the extreme sample in each slice rather than every vertex past a threshold, so a wedge (or a lip at
 * one edge) is fitted rather than discarded. Use it to lay one prop on another: an object placed on
 * `planeAt(plane, x)` follows the face it rests on instead of floating at one end and sinking at the other.
 */
export function contactPlane(geometry: THREE.BufferGeometry, opts: ContactPlaneOptions = {}): ContactPlane {
  const along = opts.along ?? 'x';
  const at = opts.at ?? 'z';
  const side = opts.side ?? 'min';
  const bins = opts.bins ?? 24;
  const pos = geometry.getAttribute('position') as THREE.BufferAttribute;
  const get = (i: number, a: 'x' | 'y' | 'z') => (a === 'x' ? pos.getX(i) : a === 'y' ? pos.getY(i) : pos.getZ(i));
  let lo = Infinity;
  let hi = -Infinity;
  for (let i = 0; i < pos.count; i++) {
    const u = get(i, along);
    if (u < lo) lo = u;
    if (u > hi) hi = u;
  }
  const w = hi - lo;
  if (!(w > 0)) return { slope: 0, offset: 0 };
  const edge = new Array<number>(bins).fill(side === 'min' ? Infinity : -Infinity);
  // the sample's own coordinate, not the slice's midpoint: a midpoint biases the slope wherever the
  // extreme sample sits off centre in its slice
  const edgeAt = new Array<number>(bins).fill(0);
  for (let i = 0; i < pos.count; i++) {
    const u = get(i, along);
    const b = Math.min(bins - 1, Math.max(0, Math.floor(((u - lo) / w) * bins)));
    const v = get(i, at);
    if (side === 'min' ? v < edge[b] : v > edge[b]) {
      edge[b] = v;
      edgeAt[b] = u;
    }
  }
  let n = 0;
  let su = 0;
  let sv = 0;
  let suu = 0;
  let suv = 0;
  for (let b = 0; b < bins; b++) {
    if (!isFinite(edge[b])) continue;
    const u = edgeAt[b];
    n++;
    su += u;
    sv += edge[b];
    suu += u * u;
    suv += u * edge[b];
  }
  if (n < 3) return { slope: 0, offset: n ? sv / n : 0 };
  const det = n * suu - su * su;
  const slope = Math.abs(det) < 1e-12 ? 0 : (n * suv - su * sv) / det;
  return { slope, offset: (sv - slope * su) / n };
}

/** the fitted face's coordinate at a position along its axis */
export function planeAt(plane: ContactPlane, along: number): number {
  return plane.slope * along + plane.offset;
}

/** the rotation that lays a flat object on a fitted face (about the axis perpendicular to both) */
export function planeTilt(plane: ContactPlane): number {
  return -Math.atan(plane.slope);
}
