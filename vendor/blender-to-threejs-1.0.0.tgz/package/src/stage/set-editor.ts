/**
 * In-page set dressing: move, rotate and scale named objects with three's
 * TransformControls, then copy the layout out as JSON and bake it into code.
 * The counterpart of Blender's N-panel for a web scene: numbers, not guesses.
 *
 * Usage
 *   const ed = new SetEditor(camera, renderer.domElement, scene)
 *   ed.add('dealer', dealerGroup)                       // register what may move
 *   ed.add('table', tableMesh, { modes: ['translate', 'rotate'] })
 *   ...
 *   ed.dispose()
 *
 * Keys (while the editor exists): 1..9 select the nth object, Tab cycles,
 * w / e / r = translate / rotate / scale, x/y/z toggle an axis constraint off,
 * Esc deselects, Shift snaps, c copies the layout JSON to the clipboard and
 * logs it (exported from the package as StageLayout). `applyLayout(objects, layout)` is the production side: apply the
 * baked JSON at load with no editor around.
 *
 * Framework-agnostic: react-three-fiber users pass `state.camera`,
 * `state.gl.domElement`, `state.scene` from useThree.
 */
import * as THREE from 'three';
import { TransformControls } from 'three/addons/controls/TransformControls.js';

export type TransformMode = 'translate' | 'rotate' | 'scale';

export interface LayoutEntry {
  /** position xyz */
  p: [number, number, number];
  /** rotation euler xyz in radians (order XYZ unless the object says otherwise) */
  r: [number, number, number];
  /** scale xyz */
  s: [number, number, number];
}
export type Layout = Record<string, LayoutEntry>;

export interface SetEditorEntryOptions {
  /** allowed modes; default all three */
  modes?: TransformMode[];
  /** lock these axes for translate (e.g. ['y'] keeps a table on the floor) */
  lockTranslate?: ('x' | 'y' | 'z')[];
}

interface Entry extends SetEditorEntryOptions {
  name: string;
  object: THREE.Object3D;
}

const round = (v: number, d = 3): number => Math.round(v * 10 ** d) / 10 ** d;

export function readTransform(o: THREE.Object3D): LayoutEntry {
  return {
    p: [round(o.position.x), round(o.position.y), round(o.position.z)],
    r: [round(o.rotation.x, 4), round(o.rotation.y, 4), round(o.rotation.z, 4)],
    s: [round(o.scale.x), round(o.scale.y), round(o.scale.z)],
  };
}

export function writeTransform(o: THREE.Object3D, e: LayoutEntry): void {
  o.position.set(e.p[0], e.p[1], e.p[2]);
  o.rotation.set(e.r[0], e.r[1], e.r[2]);
  o.scale.set(e.s[0], e.s[1], e.s[2]);
}

/** Production side: apply a baked layout to named objects. Missing names are ignored. */
export function applyLayout(objects: Record<string, THREE.Object3D | null | undefined>, layout: Layout): void {
  for (const [name, e] of Object.entries(layout)) {
    const o = objects[name];
    if (o) writeTransform(o, e);
  }
}

export class SetEditor {
  readonly controls: TransformControls;
  private readonly entries: Entry[] = [];
  private selected: Entry | null = null;
  private readonly listeners = new Set<(layout: Layout, changed: string | null) => void>();
  private readonly helper: THREE.Object3D;
  private readonly onKey = (ev: KeyboardEvent) => this.key(ev);
  private readonly onKeyUp = (ev: KeyboardEvent) => {
    if (ev.key === 'Shift') {
      this.controls.setTranslationSnap(null);
      this.controls.setRotationSnap(null);
      this.controls.setScaleSnap(null);
    }
  };
  /** true while a handle is being dragged: pause orbit/scroll controls on this */
  dragging = false;

  constructor(
    readonly camera: THREE.Camera,
    readonly domElement: HTMLElement,
    readonly scene: THREE.Scene,
  ) {
    this.controls = new TransformControls(camera, domElement);
    this.helper = this.controls.getHelper();
    // drawn on top of any compositor output, and never in its position pass
    this.helper.userData.compOverlay = true;
    this.helper.userData.compNoPosition = true;
    scene.add(this.helper);
    this.controls.addEventListener('dragging-changed', (e) => {
      this.dragging = Boolean((e as unknown as { value: boolean }).value);
    });
    this.controls.addEventListener('objectChange', () => this.emit(this.selected?.name ?? null));
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKeyUp);
  }

  /** register an object; returns it for chaining */
  add<T extends THREE.Object3D>(name: string, object: T, opts: SetEditorEntryOptions = {}): T {
    this.remove(name);
    this.entries.push({ name, object, ...opts });
    return object;
  }

  remove(name: string): void {
    const i = this.entries.findIndex((e) => e.name === name);
    if (i < 0) return;
    if (this.selected === this.entries[i]) this.select(null);
    this.entries.splice(i, 1);
  }

  names(): string[] {
    return this.entries.map((e) => e.name);
  }

  select(name: string | null): void {
    const e = name ? (this.entries.find((x) => x.name === name) ?? null) : null;
    this.selected = e;
    if (!e) {
      this.controls.detach();
      return;
    }
    this.controls.attach(e.object);
    if (e.modes && !e.modes.includes(this.controls.mode)) this.setMode(e.modes[0]);
    this.applyLocks();
  }

  selectedName(): string | null {
    return this.selected?.name ?? null;
  }

  setMode(mode: TransformMode): void {
    if (this.selected?.modes && !this.selected.modes.includes(mode)) return;
    this.controls.setMode(mode);
    this.applyLocks();
  }

  private applyLocks(): void {
    const lock = this.controls.mode === 'translate' ? (this.selected?.lockTranslate ?? []) : [];
    this.controls.showX = !lock.includes('x');
    this.controls.showY = !lock.includes('y');
    this.controls.showZ = !lock.includes('z');
  }

  /** the current transforms of every registered object */
  layout(): Layout {
    const out: Layout = {};
    for (const e of this.entries) out[e.name] = readTransform(e.object);
    return out;
  }

  /** apply a layout to the registered objects (missing names ignored) */
  apply(layout: Layout): void {
    const map: Record<string, THREE.Object3D> = {};
    for (const e of this.entries) map[e.name] = e.object;
    applyLayout(map, layout);
    this.emit(null);
  }

  toJSON(): string {
    return JSON.stringify(this.layout(), null, 2);
  }

  /** copy the layout JSON to the clipboard (and log it) */
  async copy(): Promise<string> {
    const json = this.toJSON();
    console.log('[set-editor] layout\n' + json);
    try {
      await navigator.clipboard.writeText(json);
    } catch {
      /* clipboard may be unavailable without a user gesture */
    }
    return json;
  }

  onChange(cb: (layout: Layout, changed: string | null) => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private emit(changed: string | null): void {
    const l = this.layout();
    for (const cb of this.listeners) cb(l, changed);
  }

  private key(ev: KeyboardEvent): void {
    const t = ev.target as HTMLElement | null;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    const k = ev.key;
    if (k >= '1' && k <= '9') {
      const e = this.entries[Number(k) - 1];
      if (e) this.select(e.name);
    } else if (k === 'Tab') {
      ev.preventDefault();
      if (!this.entries.length) return;
      const i = this.selected ? this.entries.indexOf(this.selected) : -1;
      this.select(this.entries[(i + 1) % this.entries.length].name);
    // Blender's g / s / r alongside the three.js w / e / r. Both, because this package's whole premise is
    // that the person driving it came from Blender, and r means SCALE in one of these and ROTATE in the
    // other - which is exactly the kind of collision that has to be spelled out rather than picked.
    } else if (k === 'w' || k === 'g') this.setMode('translate');
    else if (k === 'e') this.setMode('rotate');
    else if (k === 'r') this.setMode('scale');
    else if (k === 's') this.setMode('scale');
    else if (k === 'Escape') this.select(null);
    else if (k === 'c') void this.copy();
    else if (k === 'Shift') {
      this.controls.setTranslationSnap(0.1);
      this.controls.setRotationSnap(THREE.MathUtils.degToRad(15));
      this.controls.setScaleSnap(0.1);
    }
    if (k === 'x' || k === 'y' || k === 'z') {
      const prop = `show${k.toUpperCase()}` as 'showX' | 'showY' | 'showZ';
      this.controls[prop] = !this.controls[prop];
    }
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKeyUp);
    this.controls.detach();
    this.scene.remove(this.helper);
    this.controls.dispose();
    this.listeners.clear();
  }
}
