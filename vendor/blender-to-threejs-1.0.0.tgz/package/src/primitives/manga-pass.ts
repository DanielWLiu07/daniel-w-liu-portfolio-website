/**
 * Manga ink post-process (fidelity: approximate, engine-side).
 *
 * Screen-space stylisation, not a material graph. Materials underneath stay
 * meaningful (flat palette colours, real shading), and this pass turns the
 * rendered tone into a printed page: four tone bands (paper / halftone dots /
 * crosshatch / solid ink), sobel ink outlines, and paper grain.
 *
 * Extension over the original single-ink pass (pomme, GLSL): spot colour. The
 * scene colour is quantised to a small ink palette (default black, poker red,
 * felt green, gold). Where the nearest ink is black, the region prints as ink
 * on paper. Where it is a colour, the region prints as a flat spot fill in that
 * ink with black halftone/hatch shading on top, the way a two-ink lithograph
 * does. Tone for coloured regions is measured relative to the ink's own
 * luminance so a dark green felt still gets highlights and shadows.
 *
 * Materials should emit exact palette colours (times shading) so the quantise
 * step is exact rather than nearest-match. Anything not in the palette prints
 * black.
 *
 * Every knob is a uniform: grit (heavier blacks, hatch, grain), spot (0 = full
 * mono, 1 = full spot colour), collapse (0 = normal, 1 = every pixel ink, the
 * hook for a same-shader page transition), and the palette itself.
 */
import { Camera, Color, Scene } from 'three';
import { RenderPipeline, type Renderer } from 'three/webgpu';
import {
  Fn,
  abs,
  clamp,
  cos,
  dot,
  float,
  floor,
  fract,
  length,
  max,
  min,
  mix,
  pass,
  screenCoordinate,
  screenSize,
  screenUV,
  select,
  sin,
  smoothstep,
  sqrt,
  step,
  uniform,
  vec2,
  vec3,
  vec4,
} from 'three/tsl';
import { TSLNode } from './eevee-lighting';

export interface MangaPalette {
  /** Ink colours. Index 0 must be the black ink; the rest are spot colours. */
  inks: readonly [number, number, number][];
  paper: [number, number, number];
}

/** Cream paper, black ink, poker red, felt green, gold accent. */
export const CASINO_PALETTE: MangaPalette = {
  inks: [
    [0.07, 0.07, 0.07],
    [0.72, 0.1, 0.12],
    [0.1, 0.42, 0.24],
    [0.82, 0.62, 0.2],
  ],
  paper: [0.96, 0.94, 0.88],
};

/** Pomme's original look: one black ink on white paper. */
export const MONO_PALETTE: MangaPalette = {
  inks: [[0.07, 0.07, 0.07]],
  paper: [0.96, 0.96, 0.96],
};

export interface MangaPassOptions {
  palette?: MangaPalette;
  /** 0..1, heavier blacks / crosshatch / grain. */
  grit?: number;
  /** 0..1, how much spot colour survives (0 prints everything in black ink). */
  spot?: number;
  /** 0..1, collapse every pixel to ink (page transition hook). */
  collapse?: number;
  /** Halftone cell size in pixels. */
  dotScale?: number;
  /** Hatch line spacing in pixels. */
  hatchScale?: number;
  /** Impact frame: 0 normal, 1 gritty mono, 2 inverted two-tone poster. */
  impact?: number;
  /** 0..1 afterimage veil (paper-white) decaying after impact frames. */
  after?: number;
}

/** A TSL uniform node; set `.value` from the app to drive the pass live. */
export type MangaUniform<T> = TSLNode & { value: T };

export interface MangaUniforms {
  grit: MangaUniform<number>;
  spot: MangaUniform<number>;
  collapse: MangaUniform<number>;
  dotScale: MangaUniform<number>;
  hatchScale: MangaUniform<number>;
  impact: MangaUniform<number>;
  after: MangaUniform<number>;
  paper: MangaUniform<Color>;
  inks: MangaUniform<Color>[];
}

const luma = (c: TSLNode) => dot(c, vec3(0.299, 0.587, 0.114));

// 2D hash, same constants as the GLSL original so grain looks identical.
const hash2 = (p: TSLNode) =>
  fract(sin(dot(p, vec2(127.1, 311.7))).mul(43758.5453123));

/**
 * Rotated halftone dot field: 1 inside a dot, 0 in the gaps. Dot radius grows
 * with `amt` (high amt = bigger dots = darker fill).
 */
const halftone = (px: TSLNode, scale: TSLNode, amt: TSLNode) => {
  const a = float(0.7853981634); // 45deg screen
  const c = cos(a);
  const s = sin(a);
  const r = vec2(px.x.mul(c).sub(px.y.mul(s)), px.x.mul(s).add(px.y.mul(c))).div(scale);
  const cell = fract(r).sub(0.5);
  const d = length(cell);
  const rad = amt.mul(0.72);
  return float(1).sub(smoothstep(rad.sub(0.08), rad.add(0.08), d));
};

/** Diagonal crosshatch line coverage, dir 0 = one diagonal, 1 = the other. */
const hatch = (px: TSLNode, scale: TSLNode, dir: TSLNode) => {
  const v = mix(px.x.add(px.y), px.x.sub(px.y), dir).div(scale);
  const f = abs(fract(v).sub(0.5)).mul(2);
  return smoothstep(0.55, 0.85, f);
};

/**
 * Build the manga output node over a scene texture node (from `pass(...)`).
 * Returns the vec4 output node plus the live uniforms.
 */
export function mangaNode(
  sceneTex: TSLNode,
  opts: MangaPassOptions = {},
): { node: TSLNode; uniforms: MangaUniforms } {
  const palette = opts.palette ?? CASINO_PALETTE;
  const uniforms: MangaUniforms = {
    grit: uniform(opts.grit ?? 0.35),
    spot: uniform(opts.spot ?? 1),
    collapse: uniform(opts.collapse ?? 0),
    dotScale: uniform(opts.dotScale ?? 4),
    hatchScale: uniform(opts.hatchScale ?? 3.4),
    impact: uniform(opts.impact ?? 0),
    after: uniform(opts.after ?? 0),
    paper: uniform(new Color(...palette.paper)),
    inks: palette.inks.map((c) => uniform(new Color(...c))),
  };

  const node = Fn(() => {
    const uv = screenUV;
    const px = screenCoordinate.xy;
    const texel = vec2(1).div(screenSize);
    // impact frames (pomme's sakuga kit): frame 2 is an inverted two-tone
    // poster, frame 1 is gritty mono manga; both drop spot colour
    const impactOn = step(0.5, uniforms.impact);
    const inverted = step(1.5, uniforms.impact);
    const grit = max(uniforms.grit, impactOn.mul(0.8));

    const centre = sceneTex.sample(uv);
    const c = centre.rgb;
    const a = centre.a;

    // sobel on luminance, plus the alpha silhouette so the cutout is outlined
    const L = (o: TSLNode) => luma(sceneTex.sample(uv.add(o.mul(texel))).rgb);
    const A = (o: TSLNode) => sceneTex.sample(uv.add(o.mul(texel))).a;
    const tl = L(vec2(-1, 1)), t = L(vec2(0, 1)), tr = L(vec2(1, 1));
    const l = L(vec2(-1, 0)), r = L(vec2(1, 0));
    const bl = L(vec2(-1, -1)), b = L(vec2(0, -1)), br = L(vec2(1, -1));
    const gx = tr.add(r.mul(2)).add(br).sub(tl).sub(l.mul(2)).sub(bl);
    const gy = tl.add(t.mul(2)).add(tr).sub(bl).sub(b.mul(2)).sub(br);
    let edge = clamp(sqrt(gx.mul(gx).add(gy.mul(gy))).mul(float(1.6).add(grit)), 0, 1);
    const aE = abs(A(vec2(1, 0)).sub(A(vec2(-1, 0)))).add(abs(A(vec2(0, 1)).sub(A(vec2(0, -1)))));
    edge = max(edge, smoothstep(0.1, 0.4, aE));

    // nearest ink by CHROMATICITY, not RGB distance: a shaded paper (cream x
    // 0.3) is nearer to the green ink than to black in RGB and would print
    // green. Compare hue directions (colour / max channel) and gate on
    // saturation so grey and cream regions always print in black ink.
    const black = uniforms.inks[0];
    const cMax = max(c.r, max(c.g, c.b));
    const cMin = min(c.r, min(c.g, c.b));
    const chroma = c.div(max(cMax, 1e-4));
    const sat = cMax.sub(cMin).div(max(cMax, 1e-4));
    let ink: TSLNode = black as TSLNode;
    let best: TSLNode = float(10);
    for (let i = 1; i < uniforms.inks.length; i++) {
      const cand = uniforms.inks[i];
      const candMax = max(cand.r, max(cand.g, cand.b));
      const d = length(chroma.sub(cand.div(max(candMax, 1e-4))));
      const closer = step(d, best);
      ink = mix(ink, cand, closer);
      best = min(best, d);
    }
    // spot region: saturated enough to carry a coloured ink, and the nearest
    // ink chroma is a real match. Fade by the spot knob.
    const isSpot: TSLNode = smoothstep(0.18, 0.32, sat)
      .mul(step(best, 0.55))
      .mul(uniforms.spot)
      .mul(float(1).sub(impactOn));
    ink = mix(black as TSLNode, ink, isSpot) as TSLNode;
    const inkLum = max(luma(ink), 0.05);

    // tone: black regions use scene luminance; spot regions use luminance
    // relative to their own ink so flat colour reads as the paper level.
    const Lc = luma(c);
    const Lraw = mix(Lc, min(Lc.div(inkLum), 1), isSpot);
    const Lg = clamp(Lraw.mul(1.15).add(0.05), 0, 1);

    const dots = halftone(px, uniforms.dotScale, clamp(float(0.62).sub(Lg).mul(2.4), 0, 1));
    const hatchA = hatch(px, uniforms.hatchScale, float(0));
    const hatchB = hatch(px, uniforms.hatchScale.mul(1.18), float(1));
    const shade = mix(hatchA, max(hatchA, hatchB), grit);

    // 1 = paper (or spot fill), 0 = ink
    const highlight = float(1);
    const mid = float(1).sub(dots.mul(0.9));
    const shadow = mix(0.5, 0.12, shade);
    const core = mix(0.12, 0.03, grit);
    let tone = select(Lg.greaterThan(0.72), highlight,
      select(Lg.greaterThan(0.42), mid,
        select(Lg.greaterThan(0.2), shadow, core)));
    tone = mix(tone, float(0), uniforms.collapse);

    // spot regions fill with their ink where black regions show paper
    const fill = mix(uniforms.paper, ink, isSpot);
    let col: TSLNode = mix(black, fill, tone);
    col = mix(col, black, edge);

    // paper tooth: coarse + fine grain, biased into the midtones
    const g1 = hash2(floor(px.div(2))).sub(0.5);
    const g2 = hash2(px.add(vec2(3.1, 7.7))).sub(0.5);
    const grain = g1.mul(0.07).add(g2.mul(0.03)).mul(float(0.6).add(grit));
    const midBias = float(1).sub(abs(tone.sub(0.5)).mul(2));
    col = col.add(grain.mul(float(0.45).add(midBias.mul(0.55))));

    // transparent scene pixels stay paper so a cutout canvas composites
    col = mix(uniforms.paper, col, max(a, edge));

    // afterimage: paper-white veil lingering after the impact frames
    col = mix(col, vec3(0.97, 0.95, 0.9), uniforms.after);
    // inverted flash frame: stark flat two-tone, dark scene prints white
    const lumScene = mix(luma(uniforms.paper), Lc, a);
    const two = float(1).sub(smoothstep(0.58, 0.66, lumScene));
    col = mix(col, vec3(two, two, two), inverted);
    return vec4(col as TSLNode, float(1));
  })();

  return { node, uniforms };
}

/**
 * Convenience: a RenderPipeline rendering `scene` through the manga pass.
 * Call `post.render()` instead of `renderer.render(scene, camera)`.
 */
export function createMangaPost(
  renderer: Renderer,
  scene: Scene,
  camera: Camera,
  opts: MangaPassOptions = {},
): { post: RenderPipeline; uniforms: MangaUniforms; scenePass: TSLNode } {
  const scenePass = pass(scene, camera);
  const { node, uniforms } = mangaNode(scenePass.getTextureNode('output'), opts);
  const post = new RenderPipeline(renderer);
  post.outputNode = node;
  return { post, uniforms, scenePass };
}
