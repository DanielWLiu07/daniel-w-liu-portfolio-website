/**
 * Deterministic Blender node math, ported exactly (fidelity: exact).
 *
 * These are the pieces of the sketch node graph whose inputs are per-material
 * CONSTANTS in Blender (sockets with fixed values, not per-pixel signals), so we
 * evaluate them in TS at material-build time and feed the results to the GPU as
 * uniforms. Same math, computed once — never eyeballed.
 */

/** Blender MixRGB "Overlay" (per channel), clamped — spec section 6.2. */
export function overlay(a: number, b: number): number {
  const v = a < 0.5 ? 2 * a * b : 1 - 2 * (1 - a) * (1 - b);
  return Math.min(1, Math.max(0, v));
}

/**
 * The "Float Curve" that maps Bands Sharpness -> sh (spec section 6.3).
 * Points (0,0), (0.731,0.224), (1,1), AUTO bezier — measured fit: sh = 0.573 * x^3.
 */
export function bandsSharpnessCurve(x: number): number {
  return 0.573 * x * x * x;
}

/** One "Custom Map Range" band row from the spec table (section 6.4). */
export interface BandParams {
  sf: number;
  min: number;
  max: number;
  minOff: number;
  maxOff: number;
}

/** The three hatch bands, node-for-node from the Blender dump (spec section 6.4). */
export const SKETCH_BANDS: readonly BandParams[] = [
  { sf: 10, min: -2.19, max: 2.01, minOff: -17.63, maxOff: -5.18 },
  { sf: 10, min: -0.52, max: 2.42, minOff: -7.87, maxOff: -9.53 },
  { sf: 20, min: -0.62, max: 4.56, minOff: 4.77, maxOff: 0.82 },
] as const;

/** Resolved per-band range: band = clamp(toMin + shade * (toMax - toMin), 0, 1). */
export interface BandRange {
  toMin: number;
  toMax: number;
}

/**
 * Resolve the band ranges for a given Bands Sharpness (spec section 6.4):
 *   sh    = floatCurve(sharpness)
 *   scaler = 1 + sh * (SF - 1)
 *   toMin  = Min * scaler + sh * MinOff
 *   toMax  = Max * scaler + sh * MaxOff
 */
export function resolveBands(sharpness: number, bands: readonly BandParams[] = SKETCH_BANDS): BandRange[] {
  const sh = bandsSharpnessCurve(sharpness);
  return bands.map((b) => ({
    toMin: b.min * (1 + sh * (b.sf - 1)) + sh * b.minOff,
    toMax: b.max * (1 + sh * (b.sf - 1)) + sh * b.maxOff,
  }));
}

/**
 * Hatch pixel scale (spec section 9): pixelScale = mix(908.9, 73.4, (scale - 1) / 99).
 * Blender scene uses scale = 86.63 -> ~186.
 */
export function hatchPixelScale(scale: number): number {
  const t = (scale - 1) / 99;
  return 908.9 + (73.4 - 908.9) * t;
}
