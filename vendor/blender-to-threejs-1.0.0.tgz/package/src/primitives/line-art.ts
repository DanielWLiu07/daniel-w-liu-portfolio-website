/**
 * lineArt — Blender's Grease Pencil Line Art, as geometry (fidelity: approximate).
 *
 * Line Art is not a post effect and a sobel is not a port of it. It is a
 * GEOMETRIC tracer: it walks the mesh, decides per EDGE whether that edge is a
 * contour, a crease, an intersection or a marked edge, and emits strokes. That
 * distinction shows up immediately on hard-surface models, where a panel line
 * between two nearly-coplanar faces is a crease Blender draws and a depth sobel
 * cannot see, while a hatched surface makes a colour sobel fire on every stroke.
 *
 * What this implements, against the modifier's own switches:
 *   contour       yes, on the GPU (see the silhouette note below)
 *   crease        yes, `crease_threshold` in radians, Blender's own convention
 *   edge marks    yes, if the caller supplies marked edges
 *   intersection  NO. Mesh-mesh intersection needs a BVH and a clipper; a scene
 *                 that needs it should say so rather than get a silent near-miss.
 *
 * WELDING IS NOT OPTIONAL. glTF splits a vertex wherever a normal or a UV
 * breaks, so a cube arrives with 24 vertices and no edge in it is shared by two
 * faces. Matching edges by INDEX therefore finds no creases at all and classes
 * every edge as a boundary, which draws the entire wireframe. Edges are matched
 * by quantised POSITION instead.
 *
 * The silhouette test is deferred to the shader rather than recomputed on the
 * CPU each frame. A contour edge is one whose two adjacent faces disagree about
 * whether they face the viewer, so carrying both face normals per segment lets
 * the vertex stage decide, and the set stays correct while the object turns
 * without a rebuild. `lineArtSegments` is the CPU path for a fixed camera.
 */
import { BufferGeometry, Vector3 } from 'three';

export interface LineArtOptions {
  /**
   * Blender's "Crease Threshold", in RADIANS, and in Blender's sense: the angle
   * BETWEEN the two faces, where 180 degrees is flat. An edge is a crease when
   * that angle is smaller than the threshold. Blender's default is 140 degrees
   * (2.443461 rad), which makes anything more than 40 degrees off flat a crease.
   */
  creaseThreshold?: number;
  /** draw edges with only one adjacent face (open boundaries) */
  boundary?: boolean;
  /** draw creases */
  crease?: boolean;
  /**
   * Positions are quantised to this before edges are matched, to weld the splits
   * a glTF export introduces. Too coarse merges distinct surfaces; too fine
   * fails to weld at all. 1e-4 of a scene unit is a tenth of a millimetre at
   * metre scale.
   */
  weld?: number;
}

export interface LineArtEdges {
  /** two endpoints per edge, 6 floats */
  positions: Float32Array;
  /** the two adjacent face normals per edge, 6 floats; a boundary repeats its one */
  faceNormals: Float32Array;
  /** 1 where the edge is drawn unconditionally (crease or boundary), 0 where it is a silhouette candidate */
  always: Uint8Array;
  count: number;
  stats: { triangles: number; welded: number; boundary: number; crease: number; candidate: number };
}

const KEY_SCALE = (weld: number) => 1 / weld;

/**
 * Classify every edge of a set of geometries.
 *
 * The geometries are read in their OWN coordinates and nothing is transformed,
 * so bake world matrices in first if the parts sit under different transforms.
 * Face normals are computed from the winding rather than read from the normal
 * attribute: Line Art works off the surface, and a smoothed normal attribute
 * would report a crease as flat.
 */
export function lineArtEdges(
  geometries: readonly BufferGeometry[],
  opts: LineArtOptions = {},
): LineArtEdges {
  const creaseThreshold = opts.creaseThreshold ?? (140 * Math.PI) / 180;
  const wantBoundary = opts.boundary ?? true;
  const wantCrease = opts.crease ?? true;
  const weld = opts.weld ?? 1e-4;
  const s = KEY_SCALE(weld);

  // An edge is a crease when the angle BETWEEN the faces is under the
  // threshold. That angle is PI - acos(n1 . n2), so the test on the dot product
  // is n1 . n2 < cos(PI - threshold). At Blender's 140 degrees that is 0.766.
  const dotLimit = Math.cos(Math.PI - creaseThreshold);

  interface Edge {
    a: number;
    b: number;
    n: number[];
  }
  const edges = new Map<string, Edge>();
  const vertKey = new Map<string, number>();
  const verts: number[] = [];
  let triangles = 0;

  const keyOf = (x: number, y: number, z: number) =>
    `${Math.round(x * s)},${Math.round(y * s)},${Math.round(z * s)}`;

  const idOf = (x: number, y: number, z: number): number => {
    const k = keyOf(x, y, z);
    const hit = vertKey.get(k);
    if (hit !== undefined) return hit;
    const id = verts.length / 3;
    vertKey.set(k, id);
    verts.push(x, y, z);
    return id;
  };

  const nrm = new Vector3();
  const e1 = new Vector3();
  const e2 = new Vector3();
  const pa = new Vector3();
  const pb = new Vector3();
  const pc = new Vector3();

  for (const g of geometries) {
    const pos = g.getAttribute('position');
    if (!pos) continue;
    const index = g.getIndex();
    const triCount = index ? index.count / 3 : pos.count / 3;
    for (let t = 0; t < triCount; t++) {
      const i0 = index ? index.getX(t * 3) : t * 3;
      const i1 = index ? index.getX(t * 3 + 1) : t * 3 + 1;
      const i2 = index ? index.getX(t * 3 + 2) : t * 3 + 2;
      pa.fromBufferAttribute(pos, i0);
      pb.fromBufferAttribute(pos, i1);
      pc.fromBufferAttribute(pos, i2);
      e1.subVectors(pb, pa);
      e2.subVectors(pc, pa);
      nrm.crossVectors(e1, e2);
      const len = nrm.length();
      if (len < 1e-12) continue; // degenerate triangle contributes no normal
      nrm.divideScalar(len);
      triangles++;
      const va = idOf(pa.x, pa.y, pa.z);
      const vb = idOf(pb.x, pb.y, pb.z);
      const vc = idOf(pc.x, pc.y, pc.z);
      const pairs: [number, number][] = [
        [va, vb],
        [vb, vc],
        [vc, va],
      ];
      for (const [u, v] of pairs) {
        if (u === v) continue;
        const lo = Math.min(u, v);
        const hi = Math.max(u, v);
        const k = `${lo}_${hi}`;
        const e = edges.get(k);
        if (e) {
          // a third face on one edge is non-manifold; keep the first two, which
          // is what a tracer has to do to answer at all
          if (e.n.length < 6) e.n.push(nrm.x, nrm.y, nrm.z);
        } else {
          edges.set(k, { a: lo, b: hi, n: [nrm.x, nrm.y, nrm.z] });
        }
      }
    }
  }

  const outPos: number[] = [];
  const outN: number[] = [];
  const outAlways: number[] = [];
  let nBoundary = 0;
  let nCrease = 0;
  let nCandidate = 0;

  for (const e of edges.values()) {
    const single = e.n.length === 3;
    const n1x = e.n[0];
    const n1y = e.n[1];
    const n1z = e.n[2];
    const n2x = single ? n1x : e.n[3];
    const n2y = single ? n1y : e.n[4];
    const n2z = single ? n1z : e.n[5];

    let always = 0;
    if (single) {
      if (!wantBoundary) continue;
      always = 1;
      nBoundary++;
    } else {
      const d = n1x * n2x + n1y * n2y + n1z * n2z;
      if (d < dotLimit) {
        if (!wantCrease) continue;
        always = 1;
        nCrease++;
      } else {
        nCandidate++;
      }
    }
    outPos.push(
      verts[e.a * 3],
      verts[e.a * 3 + 1],
      verts[e.a * 3 + 2],
      verts[e.b * 3],
      verts[e.b * 3 + 1],
      verts[e.b * 3 + 2],
    );
    outN.push(n1x, n1y, n1z, n2x, n2y, n2z);
    outAlways.push(always);
  }

  return {
    positions: new Float32Array(outPos),
    faceNormals: new Float32Array(outN),
    always: Uint8Array.from(outAlways),
    count: outAlways.length,
    stats: {
      triangles,
      welded: verts.length / 3,
      boundary: nBoundary,
      crease: nCrease,
      candidate: nCandidate,
    },
  };
}

/**
 * The segments to draw from a given eye position: every crease and boundary,
 * plus the contour edges the viewpoint creates.
 *
 * An edge is a contour when its two faces disagree about facing the eye. Tested
 * per edge at its own midpoint rather than against one global view direction,
 * because the camera here is a metre from a subject a metre across and a single
 * direction is wrong by tens of degrees at the wings.
 *
 * Returns a flat [x,y,z, x,y,z, ...] pair per segment, which is the layout
 * LineSegmentsGeometry.setPositions wants.
 */
export function lineArtSegments(
  edges: LineArtEdges,
  eye: Vector3,
  opts: { contour?: boolean } = {},
): Float32Array {
  const wantContour = opts.contour ?? true;
  const out: number[] = [];
  for (let i = 0; i < edges.count; i++) {
    const p = i * 6;
    let draw = edges.always[i] === 1;
    if (!draw && wantContour) {
      const mx = (edges.positions[p] + edges.positions[p + 3]) / 2;
      const my = (edges.positions[p + 1] + edges.positions[p + 4]) / 2;
      const mz = (edges.positions[p + 2] + edges.positions[p + 5]) / 2;
      const vx = eye.x - mx;
      const vy = eye.y - my;
      const vz = eye.z - mz;
      const d1 = edges.faceNormals[p] * vx + edges.faceNormals[p + 1] * vy + edges.faceNormals[p + 2] * vz;
      const d2 =
        edges.faceNormals[p + 3] * vx + edges.faceNormals[p + 4] * vy + edges.faceNormals[p + 5] * vz;
      draw = d1 * d2 < 0;
    }
    if (!draw) continue;
    out.push(
      edges.positions[p],
      edges.positions[p + 1],
      edges.positions[p + 2],
      edges.positions[p + 3],
      edges.positions[p + 4],
      edges.positions[p + 5],
    );
  }
  return new Float32Array(out);
}

/** Blender's Line Art default, in radians, so callers do not retype 140 degrees. */
export const BLENDER_CREASE_THRESHOLD = (140 * Math.PI) / 180;
