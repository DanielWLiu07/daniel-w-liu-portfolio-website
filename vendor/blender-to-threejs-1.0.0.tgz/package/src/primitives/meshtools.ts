/**
 * GLB cleanup helpers, ported from pomme's meshtools.js: Taubin/Laplacian
 * smoothing, weld by position, bake an atlas texture to vertex colours. Pomme
 * runs bake -> weld -> laplacianSmooth(120, 0.6) -> computeVertexNormals on
 * the hero apple before the painterly material; the smoothing melts sculpted
 * facet creases so the cel bands read as painted blobs, not polygons.
 */
import * as THREE from 'three';



// Taubin smoothing (lambda/mu) on an indexed geometry.
export function taubinSmooth(geo: THREE.BufferGeometry, iterations = 10, lambda = 0.5, mu = -0.53): void {
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const idx = geo.index;
  if (!idx) throw new Error('[meshtools] taubinSmooth needs an indexed geometry (weld first)');
  const n = pos.count;
  const nbr: number[][] = new Array(n);
  for (let i = 0; i < n; i++) nbr[i] = [];
  const addEdge = (a: number, b: number) => { nbr[a].push(b); nbr[b].push(a); };
  for (let t = 0; t < idx.count; t += 3) {
    const a = idx.getX(t), b = idx.getX(t + 1), c = idx.getX(t + 2);
    addEdge(a, b); addEdge(b, c); addEdge(c, a);
  }
  const P = new Float32Array(pos.array as ArrayLike<number>);
  const Q = new Float32Array(n * 3);
  const step = (src: Float32Array, dst: Float32Array, k: number) => {
    for (let i = 0; i < n; i++) {
      const nb = nbr[i];
      if (!nb.length) {
        dst[i * 3] = src[i * 3]; dst[i * 3 + 1] = src[i * 3 + 1];
        dst[i * 3 + 2] = src[i * 3 + 2];
        continue;
      }
      let ax = 0, ay = 0, az = 0;
      for (let j = 0; j < nb.length; j++) {
        const v = nb[j] * 3;
        ax += src[v]; ay += src[v + 1]; az += src[v + 2];
      }
      const inv = 1 / nb.length, o = i * 3;
      dst[o] = src[o] + k * (ax * inv - src[o]);
      dst[o + 1] = src[o + 1] + k * (ay * inv - src[o + 1]);
      dst[o + 2] = src[o + 2] + k * (az * inv - src[o + 2]);
    }
  };
  for (let it = 0; it < iterations; it++) {
    step(P, Q, lambda);
    step(Q, P, mu);
  }
  (pos.array as Float32Array).set(P);
  pos.needsUpdate = true;
}

// Heavy Laplacian smoothing + rescale-to-original-bounds: melts large
// sculpted facet creases (Taubin is shape-preserving and can't).
export function laplacianSmooth(geo: THREE.BufferGeometry, iterations = 150, lambda = 0.7): void {
  const pos = geo.attributes.position as THREE.BufferAttribute;
  geo.computeBoundingBox();
  const before = geo.boundingBox!.clone();
  taubinSmooth(geo, iterations, lambda, 0);   // mu=0 -> pure Laplacian
  geo.computeBoundingBox();
  const after = geo.boundingBox!;
  const cb = before.getCenter(new THREE.Vector3());
  const ca = after.getCenter(new THREE.Vector3());
  const sb = before.getSize(new THREE.Vector3());
  const sa = after.getSize(new THREE.Vector3());
  const s = Math.max(sb.x / Math.max(sa.x, 1e-9),
                     sb.y / Math.max(sa.y, 1e-9),
                     sb.z / Math.max(sa.z, 1e-9));
  for (let i = 0; i < pos.count; i++) {
    pos.setXYZ(i,
      (pos.getX(i) - ca.x) * s + cb.x,
      (pos.getY(i) - ca.y) * s + cb.y,
      (pos.getZ(i) - ca.z) * s + cb.z);
  }
  pos.needsUpdate = true;
}

// Bake the material's atlas texture to per-vertex colors and drop the map.
export function bakeMapToVertexColors(mesh: THREE.Mesh): void {
  const mat = mesh.material as THREE.MeshStandardMaterial;
  const img = mat && mat.map && (mat.map.image as HTMLImageElement | ImageBitmap | undefined);
  const uv = mesh.geometry.attributes.uv as THREE.BufferAttribute | undefined;
  if (!img || !uv) return;
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(img as CanvasImageSource, 0, 0);
  const data = ctx.getImageData(0, 0, c.width, c.height).data;
  const pos = mesh.geometry.attributes.position as THREE.BufferAttribute;
  const col = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    let u = uv.getX(i) % 1; if (u < 0) u += 1;
    let v = uv.getY(i) % 1; if (v < 0) v += 1;
    const x = Math.min(c.width - 1, Math.round(u * (c.width - 1)));
    const flip = mat.map!.flipY;   // glTF ships flipY=false
    const y = Math.min(c.height - 1,
      Math.round((flip ? 1 - v : v) * (c.height - 1)));
    const k = (y * c.width + x) * 4;
    col[i * 3] = Math.pow(data[k] / 255, 2.2);        // sRGB -> linear
    col[i * 3 + 1] = Math.pow(data[k + 1] / 255, 2.2);
    col[i * 3 + 2] = Math.pow(data[k + 2] / 255, 2.2);
  }
  mesh.geometry.setAttribute('color', new THREE.BufferAttribute(col, 3));
  mat.map = null;
  mat.vertexColors = true;
  mat.needsUpdate = true;
}

// Weld by position into an indexed geometry (position + color only,
// colors averaged across duplicates).
export function weldPositionColor(geo: THREE.BufferGeometry): THREE.BufferGeometry {
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const col = geo.attributes.color as THREE.BufferAttribute | undefined;
  const idx = geo.index;
  const n = idx ? idx.count : pos.count;
  const seen = new Map<string, number>();
  const P: number[] = [], C: number[] = [], counts: number[] = [], I: number[] = [];
  const key = (i: number) => pos.getX(i).toPrecision(6) + ',' +
    pos.getY(i).toPrecision(6) + ',' + pos.getZ(i).toPrecision(6);
  for (let k = 0; k < n; k++) {
    const i = idx ? idx.getX(k) : k;
    const s = key(i);
    let j = seen.get(s);
    if (j === undefined) {
      j = P.length / 3;
      seen.set(s, j);
      P.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      C.push(col ? col.getX(i) : 1, col ? col.getY(i) : 1, col ? col.getZ(i) : 1);
      counts.push(1);
    } else {
      if (col) {
        C[j * 3] += col.getX(i); C[j * 3 + 1] += col.getY(i);
        C[j * 3 + 2] += col.getZ(i);
      }
      counts[j]++;
    }
    I.push(j);
  }
  for (let j = 0; j < counts.length; j++) {
    C[j * 3] /= counts[j]; C[j * 3 + 1] /= counts[j]; C[j * 3 + 2] /= counts[j];
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(C, 3));
  g.setIndex(I);
  return g;
}

/**
 * Flip triangles whose face normal points into the object (dot with the
 * direction from the mesh centre is negative). AI-generated / sculpted meshes
 * often carry a strip of inside-out faces (the pomme apple has one across its
 * lower left); with smooth vertex normals it renders as a dark crease and casts
 * a spike of shadow. Only right for closed, roughly star-shaped meshes.
 * Returns the number of triangles flipped.
 */
export function flipInwardFaces(geo: THREE.BufferGeometry): number {
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const idx = geo.index;
  if (!idx) throw new Error('[meshtools] flipInwardFaces needs an indexed geometry');
  geo.computeBoundingBox();
  const c = geo.boundingBox!.getCenter(new THREE.Vector3());
  const a = new THREE.Vector3(), b = new THREE.Vector3(), d = new THREE.Vector3();
  const ab = new THREE.Vector3(), ac = new THREE.Vector3(), n = new THREE.Vector3(), out = new THREE.Vector3();
  let flipped = 0;
  for (let t = 0; t < idx.count; t += 3) {
    const i0 = idx.getX(t), i1 = idx.getX(t + 1), i2 = idx.getX(t + 2);
    a.fromBufferAttribute(pos, i0);
    b.fromBufferAttribute(pos, i1);
    d.fromBufferAttribute(pos, i2);
    ab.subVectors(b, a);
    ac.subVectors(d, a);
    n.crossVectors(ab, ac);
    out.copy(a).add(b).add(d).multiplyScalar(1 / 3).sub(c);
    if (n.dot(out) < 0) {
      idx.setX(t + 1, i2);
      idx.setX(t + 2, i1);
      flipped++;
    }
  }
  idx.needsUpdate = true;
  return flipped;
}
