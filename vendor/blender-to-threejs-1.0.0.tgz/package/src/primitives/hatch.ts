/**
 * Hatch primitives — screen-space hatch UV + the multiply-from-white composite
 * (fidelity: exact — node-for-node from the Blender graph).
 */
import { Texture } from 'three';
import { TSLNode } from './eevee-lighting';
import { clamp, fract, oneMinus, screenUV, texture, vec2 } from 'three/tsl';

/**
 * Screen-space hatch UV (spec section 9): Blender "Window" texture coordinates
 * scaled by renderResolution / pixelScale. `pixelScale` comes from
 * hatchPixelScale() in blender-math.ts (a uniform so hatch density is tunable).
 */
export function hatchUV(resolution: [number, number], pixelScale: TSLNode): TSLNode {
  return fract(screenUV.mul(vec2(resolution[0], resolution[1])).div(pixelScale));
}

export interface HatchLayers {
  /** chaotic.png RGB — three hatch densities in R/G/B. */
  tex: TSLNode;
  r: TSLNode;
  g: TSLNode;
  b: TSLNode;
}

/** Sample the chaotic sheet once; layers live in R/G/B (spec section 6.5 / 8). */
export function sampleHatch(chaotic: Texture, uvNode: TSLNode): HatchLayers {
  const tex = texture(chaotic, uvNode);
  return { tex, r: tex.r, g: tex.g, b: tex.b };
}

/**
 * MULTIPLY-from-white composite (spec section 6.5):
 *   mask0 = lerp(1, texR, ink0)
 *   mask1 = mask0 * lerp(1, texG, ink1)
 *   mask2 = mask1 * lerp(1, texB, ink2)
 * where ink_n = 1 - band_n and band_n = clamp(toMin_n + shade*(toMax_n - toMin_n), 0, 1).
 *
 * `bandRanges` are [toMin, toMax] uniform pairs (resolved from Bands Sharpness in TS).
 * Returns mask2: 1 = paper, 0 = full ink.
 */
export function hatchComposite(
  shade: TSLNode,
  layers: HatchLayers,
  bandRanges: readonly { toMin: TSLNode; toMax: TSLNode }[],
): TSLNode {
  const chans = [layers.r, layers.g, layers.b];
  let mask: TSLNode | null = null;
  bandRanges.forEach((range, i) => {
    const band = clamp(range.toMin.add(shade.mul(range.toMax.sub(range.toMin))), 0.0, 1.0);
    const ink = oneMinus(band);
    const layer = oneMinus(ink.mul(oneMinus(chans[i]))); // lerp(1, tex, ink)
    mask = mask === null ? layer : mask.mul(layer);
  });
  return mask;
}
