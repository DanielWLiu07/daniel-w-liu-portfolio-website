/**
 * AO primitive + strategy picker (fidelity: approximate).
 *
 * Blender's gray crevices come from EEVEE screen-space GTAO at scene distance 0.20
 * (spec section 7). Live GTAO is expensive on the web, so AO is a strategy enum:
 *
 *  - 'uv'        UV-baked AO texture (NoColorSpace), geometry-attached — the default.
 *                Safe under rigid animation; zero ghosting.
 *  - 'screen'    screen-space bake sampled by screenUV — exact for LOCKED hero shots
 *                only; ghosts the moment anything moves (GOTCHAS: ao ghosting).
 *  - 'live-gtao' true live GTAO — the high-fidelity opt-in for deforming meshes.
 *  - 'none'      AO disabled (ao = 1 everywhere).
 *
 * 'screen' and 'live-gtao' are not implemented in this seed; requesting them
 * degrades honestly (console.warn + nearest implemented fallback) rather than
 * silently pretending.
 */
import { Texture } from 'three';
import { TSLNode } from './eevee-lighting';
import { clamp, float, oneMinus, texture, uv } from 'three/tsl';

export type AOStrategy = 'uv' | 'screen' | 'live-gtao' | 'none';

export interface AOContext {
  /** Whole-object motion (translate/rotate/scale). */
  animated: boolean;
  /** Skeletal/morph deformation (rest-pose bakes go stale). */
  deforming: boolean;
  /** Camera orbits/moves (screen-space bakes break). */
  cameraMoves: boolean;
}

/**
 * pickAOStrategy — the decision tree from the brief (4c/4d), baked into a rule:
 * deforming -> live GTAO; rigid animation or a moving camera -> UV bake;
 * fully locked hero shot -> screen-space bake (pixel-exact for that one view).
 */
export function pickAOStrategy(ctx: AOContext): AOStrategy {
  if (ctx.deforming) return 'live-gtao';
  if (ctx.animated || ctx.cameraMoves) return 'uv';
  return 'screen';
}

export interface AONodeOptions {
  strategy: AOStrategy;
  /** UV-baked AO map (REQUIRED for 'uv'; must be NoColorSpace). */
  aoMap?: Texture;
}

/** Resolve the raw AO signal node (1 = fully open) for a strategy. */
export function aoNode(opts: AONodeOptions): TSLNode {
  let strategy = opts.strategy;
  if (strategy === 'screen' || strategy === 'live-gtao') {
    const fallback: AOStrategy = opts.aoMap ? 'uv' : 'none';
    console.warn(`[ao] strategy '${strategy}' not implemented yet — degrading to '${fallback}'.`);
    strategy = fallback;
  }
  if (strategy === 'uv') {
    if (!opts.aoMap) {
      console.warn(`[ao] strategy 'uv' requested without an aoMap — degrading to 'none'.`);
      return float(1.0);
    }
    return texture(opts.aoMap, uv()).r;
  }
  return float(1.0);
}

/**
 * aoDarken (spec section 6.6): remap the AO signal through the graph's map-range
 * and scale by AO Amount:  aoDarken = (1 - clamp((ao - 0.6556)/0.3444, 0, 1)) * amount.
 * The caller mixes ink toward black by this factor.
 */
export function aoDarken(ao: TSLNode, amount: TSLNode): TSLNode {
  return oneMinus(clamp(ao.sub(0.6556).div(0.3444), 0.0, 1.0)).mul(amount);
}
