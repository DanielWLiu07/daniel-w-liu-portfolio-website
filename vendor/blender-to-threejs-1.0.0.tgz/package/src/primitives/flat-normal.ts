/**
 * flatShadeNormal — reconstruct FLAT face normals from screen derivatives
 * (fidelity: exact for flat-shaded meshes).
 *
 * Spec section 5 gotcha: suzanne.glb carries SMOOTH vertex normals, but
 * Suzanne.001 is flat-shaded in Blender (all 500 faces). Rather than exporting a
 * second, split-vertex mesh, rebuild the face normal per fragment:
 *
 *   flatN = normalize(cross(dFdx(positionWorld), dFdy(positionWorld)))
 *
 * oriented into the smooth-normal hemisphere (derivative winding can flip), then
 * blended with the smooth normal by a `flatShade` factor (1 = flat, 0 = smooth).
 */
import { TSLNode } from './eevee-lighting';
import { cross, dFdx, dFdy, dot, mix, normalWorld, normalize, positionWorld, sign } from 'three/tsl';

export function flatShadeNormal(flatShade: TSLNode): TSLNode {
  const flatN = normalize(cross(dFdx(positionWorld), dFdy(positionWorld)));
  const oriented = flatN.mul(sign(dot(flatN, normalWorld)));
  return normalize(mix(normalWorld, oriented, flatShade));
}
