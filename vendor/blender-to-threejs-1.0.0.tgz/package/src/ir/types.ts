/**
 * IR schema for Blender material node graphs, as emitted by
 * tools/export_material_nodes.py. This is the shared scene-IR the whole
 * pipeline (transpiler, diff, pipeline nodes) operates on.
 */

export type SocketValue = number | boolean | string | number[];

export interface IRSocket {
  name: string;
  identifier: string;
  type: string; // VALUE | VECTOR | RGBA | SHADER | ...
  default?: SocketValue;
}

export interface IRImageRef {
  name: string;
  filepath: string;
  source: string;
  colorspace: string; // 'sRGB' | 'Non-Color' | ...
  size: number[];
}

export interface IRColorRamp {
  interpolation: string;
  color_mode: string;
  elements: { position: number; color: number[] }[];
}

export interface IRCurveMapping {
  extend: string;
  clip: [number, number, number, number];
  curves: { x: number; y: number; handle: string }[][];
}

export interface IRNode {
  type: string; // bl_idname, e.g. 'ShaderNodeMath'
  inputs: IRSocket[];
  outputs: IRSocket[];
  props: Record<string, SocketValue | IRImageRef | IRColorRamp | IRCurveMapping | undefined> & {
    image?: IRImageRef;
    color_ramp?: IRColorRamp;
    curve_mapping?: IRCurveMapping;
  };
  /** Group instances point at the tree they instantiate. */
  node_tree?: string;
}

export interface IRLink {
  from: [nodeName: string, socketIdentifier: string];
  to: [nodeName: string, socketIdentifier: string];
}

export interface IRTree {
  nodes: Record<string, IRNode>;
  links: IRLink[];
}

export interface IRGraph {
  blend: string;
  blender_version: string;
  object: string;
  /** material name -> root tree name */
  materials: Record<string, string>;
  trees: Record<string, IRTree>;
}
