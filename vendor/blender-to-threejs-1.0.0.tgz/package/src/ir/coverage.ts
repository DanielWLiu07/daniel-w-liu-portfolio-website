/**
 * Node coverage classification — the fidelity-tag foundation (brief section 2).
 *
 * Every Blender node type the IR can contain is classified up front:
 *   exact        deterministic 1:1 TSL transpile — one right answer
 *   approximate  maps onto an EEVEE-faithful primitive (calibrated, tagged)
 *   structural   graph plumbing, no math of its own
 *   unsupported  no faithful equivalent yet — bake or reimplement, and SAY SO
 *
 * Honest degradation beats silent breakage: anything not listed here reports
 * as unsupported instead of being guessed at.
 */
import type { IRGraph } from './types';

export type Fidelity = 'exact' | 'approximate' | 'structural' | 'unsupported';

export const NODE_CLASSES: Record<string, { fidelity: Fidelity; via?: string }> = {
  // --- deterministic 1:1 TSL ---
  ShaderNodeMath: { fidelity: 'exact' },
  ShaderNodeVectorMath: { fidelity: 'exact' },
  ShaderNodeMix: { fidelity: 'exact' },
  ShaderNodeMapRange: { fidelity: 'exact' },
  ShaderNodeInvert: { fidelity: 'exact' },
  ShaderNodeCombineXYZ: { fidelity: 'exact' },
  ShaderNodeSeparateXYZ: { fidelity: 'exact' },
  ShaderNodeSeparateColor: { fidelity: 'exact' },
  ShaderNodeCombineColor: { fidelity: 'exact' },
  ShaderNodeValToRGB: { fidelity: 'exact', via: 'color-ramp LUT' },
  ShaderNodeFloatCurve: { fidelity: 'exact', via: 'curve eval' },
  ShaderNodeRGBCurve: { fidelity: 'exact', via: 'curve eval' },
  ShaderNodeTexImage: { fidelity: 'exact', via: 'texture()' },
  ShaderNodeTexCoord: { fidelity: 'exact', via: 'uv() / window() / generated(min,max) / position()' },
  ShaderNodeMapping: { fidelity: 'exact', via: 'mapping() folds constants; mappingDynamic() takes driven location/rotation/scale' },
  ShaderNodeHueSaturation: { fidelity: 'exact' },
  ShaderNodeGamma: { fidelity: 'exact' },
  ShaderNodeBrightContrast: { fidelity: 'exact' },
  ShaderNodeValue: { fidelity: 'exact' },
  ShaderNodeRGB: { fidelity: 'exact' },
  ShaderNodeFresnel: { fidelity: 'exact' },
  ShaderNodeLayerWeight: { fidelity: 'exact' },
  ShaderNodeBump: { fidelity: 'exact' },
  ShaderNodeNormalMap: { fidelity: 'exact' },

  // --- approximate: engine behavior mapped onto our primitives ---
  ShaderNodeBsdfPrincipled: { fidelity: 'approximate', via: 'eeveeLighting primitive' },
  ShaderNodeBsdfDiffuse: { fidelity: 'approximate', via: 'lambert against a stated light set (sun and point, measured falloff), no closure' },
  ShaderNodeShaderToRGB: { fidelity: 'approximate', via: 'eeveeLighting primitive (EEVEE-only node)' },
  ShaderNodeAmbientOcclusion: { fidelity: 'approximate', via: 'ao primitive (strategy enum)' },
  ShaderNodeTexNoise: { fidelity: 'approximate', via: 'port-hash mismatch: bake or reimplement hash' },
  ShaderNodeTexVoronoi: { fidelity: 'exact', via: 'Distance and F1 Color, both pinned against Cycles' },
  // verified against Cycles over 7 cases (bands x/y/diagonal, rings z/spherical,
  // distorted, phase-offset); the distortion path rides the noise we already pin
  ShaderNodeTexWave: { fidelity: 'exact' },
  ShaderNodeBsdfTransparent: { fidelity: 'approximate', via: 'alpha path' },
  ShaderNodeMixShader: { fidelity: 'approximate', via: 'closure mix -> color/alpha mix after ShaderToRGB' },
  ShaderNodeEmission: { fidelity: 'approximate', via: 'colorNode add' },

  // --- structural plumbing ---
  NodeGroupInput: { fidelity: 'structural' },
  NodeGroupOutput: { fidelity: 'structural' },
  NodeReroute: { fidelity: 'structural' },
  NodeFrame: { fidelity: 'structural' },
  ShaderNodeGroup: { fidelity: 'structural', via: 'inline expansion' },
  ShaderNodeOutputMaterial: { fidelity: 'structural', via: 'material root' },
};

export interface CoverageRow {
  type: string;
  count: number;
  fidelity: Fidelity;
  via?: string;
}

export function coverageReport(graph: IRGraph): CoverageRow[] {
  const counts = new Map<string, number>();
  for (const tree of Object.values(graph.trees)) {
    for (const node of Object.values(tree.nodes)) {
      counts.set(node.type, (counts.get(node.type) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .map(([type, count]) => {
      const cls = NODE_CLASSES[type];
      return {
        type,
        count,
        fidelity: cls?.fidelity ?? ('unsupported' as const),
        via: cls?.via,
      };
    })
    .sort((a, b) => b.count - a.count);
}

export function coverageSummary(rows: CoverageRow[]) {
  const total = rows.reduce((s, r) => s + r.count, 0);
  const by = (f: Fidelity) => rows.filter((r) => r.fidelity === f).reduce((s, r) => s + r.count, 0);
  return {
    total,
    exact: by('exact'),
    approximate: by('approximate'),
    structural: by('structural'),
    unsupported: by('unsupported'),
  };
}
