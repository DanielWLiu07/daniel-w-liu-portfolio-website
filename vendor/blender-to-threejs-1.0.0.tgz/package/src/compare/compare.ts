/**
 * Compare harness UI — the "honest report" surface.
 *
 *  - Reference overlay: blender_ref_raw.png (compositor OFF — same stage as the
 *    live render) with an opacity slider for A/B eyeballing.
 *  - Measure: reads back the WebGL/WebGPU canvas, downsamples both images to a
 *    common grid and computes mean-absolute-error overall + per region
 *    (6x4 grid). Numbers, not vibes.
 *  - Fidelity table: the IR coverage report (exact / approximate / structural)
 *    rendered from the actual exported node graph.
 *
 * The DOM paper overlay is never part of the measurement: drawImage() captures
 * only the GL canvas, and the raw reference has no compositor either — the
 * comparison is raw-vs-raw by construction.
 */
import graph from '../ir/sketch-graph.json';
import { coverageReport, coverageSummary } from '../ir/coverage';
import type { IRGraph } from '../ir/types';

export interface CompareOptions {
  /** The renderer's canvas element. */
  canvas: HTMLCanvasElement;
  /** Await one fresh render before capture (WebGPU renders async). */
  renderOnce: () => Promise<void>;
  /** Blender render resolution, for the capture aspect. */
  resolution: [number, number];
  refSrc?: string;
}

const GRID_COLS = 6;
const GRID_ROWS = 4;
const CAP_W = 330; // 1980/6 — plenty for region statistics
const CAP_H = 180;

function grab(source: CanvasImageSource, w: number, h: number): ImageData {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const x = c.getContext('2d')!;
  x.drawImage(source, 0, 0, w, h);
  return x.getImageData(0, 0, w, h);
}

interface DiffResult {
  maePct: number;
  regions: number[][]; // [row][col] MAE %
  worst: { row: number; col: number; pct: number };
}

function diff(a: ImageData, b: ImageData): DiffResult {
  const { width: w, height: h } = a;
  const sums = Array.from({ length: GRID_ROWS }, () => new Array(GRID_COLS).fill(0));
  const counts = Array.from({ length: GRID_ROWS }, () => new Array(GRID_COLS).fill(0));
  let total = 0;
  for (let y = 0; y < h; y++) {
    const row = Math.min(GRID_ROWS - 1, (y / h) * GRID_ROWS | 0);
    for (let x = 0; x < w; x++) {
      const col = Math.min(GRID_COLS - 1, (x / w) * GRID_COLS | 0);
      const i = (y * w + x) * 4;
      const d =
        Math.abs(a.data[i] - b.data[i]) +
        Math.abs(a.data[i + 1] - b.data[i + 1]) +
        Math.abs(a.data[i + 2] - b.data[i + 2]);
      sums[row][col] += d;
      counts[row][col] += 3;
      total += d;
    }
  }
  const regions = sums.map((r, ri) => r.map((s, ci) => (s / counts[ri][ci] / 255) * 100));
  let worst = { row: 0, col: 0, pct: 0 };
  regions.forEach((r, ri) =>
    r.forEach((pct, ci) => {
      if (pct > worst.pct) worst = { row: ri, col: ci, pct };
    }),
  );
  return { maePct: (total / (w * h * 3) / 255) * 100, regions, worst };
}

function paintHeat(el: HTMLCanvasElement, regions: number[][]) {
  el.width = GRID_COLS;
  el.height = GRID_ROWS;
  const x = el.getContext('2d')!;
  const img = x.createImageData(GRID_COLS, GRID_ROWS);
  const max = Math.max(1e-6, ...regions.flat());
  regions.forEach((row, ri) =>
    row.forEach((pct, ci) => {
      const i = (ri * GRID_COLS + ci) * 4;
      const t = pct / max;
      img.data[i] = 40 + t * 215; // red ramps with error
      img.data[i + 1] = 60 + (1 - t) * 140; // green fades
      img.data[i + 2] = 60;
      img.data[i + 3] = 255;
    }),
  );
  x.putImageData(img, 0, 0);
}

export function buildComparePanel(opts: CompareOptions) {
  const refSrc = opts.refSrc ?? '/assets/blender_ref_raw.png';
  const frame = opts.canvas.parentElement!;

  // --- reference overlay (inside the letterboxed frame, same aspect) ---
  const refImg = document.createElement('img');
  refImg.src = refSrc;
  refImg.alt = '';
  Object.assign(refImg.style, {
    position: 'absolute',
    inset: '0',
    width: '100%',
    height: '100%',
    opacity: '0',
    pointerEvents: 'none',
  });
  frame.appendChild(refImg);

  // --- panel ---
  const rows = coverageReport(graph as unknown as IRGraph);
  const sum = coverageSummary(rows);
  const panel = document.createElement('div');
  panel.id = 'cmp';
  panel.innerHTML = `
    <div class="cmp-title">compare vs Blender</div>
    <label>ref overlay <input id="cmpRef" type="range" min="0" max="100" value="0"></label>
    <label><input id="cmpPaper" type="checkbox" checked> paper overlay (visual only)</label>
    <button id="cmpMeasure" type="button">measure</button>
    <div id="cmpScore">score: not measured</div>
    <canvas id="cmpHeat" title="per-region MAE"></canvas>
    <details>
      <summary>fidelity: ${sum.exact} exact / ${sum.approximate} approx / ${sum.structural} structural${sum.unsupported ? ` / ${sum.unsupported} UNSUPPORTED` : ''}</summary>
      <table>
        ${rows
          .map(
            (r) =>
              `<tr class="f-${r.fidelity}"><td>${r.type.replace('ShaderNode', '')}</td><td>${r.count}</td><td>${r.fidelity}</td><td>${r.via ?? ''}</td></tr>`,
          )
          .join('')}
      </table>
    </details>
    <div class="cmp-note">known gaps: cast shadows, small-monkey AO bake, GP lineart vs hull outline</div>
  `;
  document.body.appendChild(panel);

  const $ = <T extends HTMLElement>(id: string) => panel.querySelector('#' + id) as T;
  $<HTMLInputElement>('cmpRef').oninput = (e) => {
    refImg.style.opacity = String(+(e.target as HTMLInputElement).value / 100);
  };
  $<HTMLInputElement>('cmpPaper').onchange = (e) => {
    const paper = document.getElementById('paper');
    if (paper) paper.style.display = (e.target as HTMLInputElement).checked ? '' : 'none';
  };
  $<HTMLButtonElement>('cmpMeasure').onclick = async () => {
    const score = $<HTMLDivElement>('cmpScore');
    score.textContent = 'measuring...';
    try {
      await refImg.decode();
      await opts.renderOnce(); // fresh frame right before readback
      const live = grab(opts.canvas, CAP_W, CAP_H);
      const ref = grab(refImg, CAP_W, CAP_H);
      const d = diff(live, ref);
      score.textContent = `score: MAE ${d.maePct.toFixed(2)}% | worst region r${d.worst.row + 1}c${d.worst.col + 1}: ${d.worst.pct.toFixed(1)}%`;
      paintHeat($<HTMLCanvasElement>('cmpHeat'), d.regions);
    } catch (err) {
      score.textContent = `measure failed: ${err}`;
    }
  };

  // ?measure: auto-run once after load — the hook the headless/CI harness uses.
  // The score is also mirrored to console so log-scraping runs can grab it.
  if (location.search.includes('measure')) {
    setTimeout(async () => {
      $<HTMLButtonElement>('cmpMeasure').click();
      setTimeout(() => {
        console.log('[compare] ' + $<HTMLDivElement>('cmpScore').textContent);
      }, 1500);
    }, 800);
  }

  return { refImg, panel };
}
