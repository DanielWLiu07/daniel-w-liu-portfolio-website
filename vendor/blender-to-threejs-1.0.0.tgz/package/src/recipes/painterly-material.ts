/**
 * Painterly cel material + hand-drawn hull outline (fidelity: approximate,
 * engine-side recipe).
 *
 * Port of pomme's makePainterlyStyle2 (web/public/scene/styles2.js) to TSL:
 * the material HALF of the watercolour look, which the compositor's watercolour
 * graph then paints. Line for line the same numbers:
 *
 *  - MeshToon lighting through a 3-step gradient map (45, 140, 220, 255)
 *  - a stroke normal map sampled triplanar in OBJECT space (scale 1.25) and
 *    added to the normal at strength 2.3, so cel boundaries wobble into blobs
 *  - pigment posterised into 4 dithered zones between a warm light tint and a
 *    cool dark tint, pulled 15% toward grey and clamped to [0.10, 0.92]
 *  - a world-keyed cartoon shadow cel (key (0.73, 0.68, 0.06), cutoff
 *    smoothstep(0.28, 0.52)) mixed to a cool violet shadow pigment
 *  - a back-face hull pushed out by 0.024 + 0.016 * noise, ink-coloured with
 *    noisy coverage (alpha 0.88 * smoothstep(0.08, 0.42, noise))
 *
 * This is not a node graph: the material graph has no light input yet, so a
 * lit cel material cannot be authored through graph() today. It lives here as
 * a recipe next to sketch-material.ts, and moves into the graph when lighting
 * lands there.
 */
import {
  BackSide,
  Color,
  DataTexture,
  Mesh,
  NearestFilter,
  Object3D,
  RedFormat,
  RepeatWrapping,
  Texture,
  Vector3,
} from 'three';
import { MeshBasicNodeMaterial, MeshToonNodeMaterial } from 'three/webgpu';
import {
  Fn,
  abs,
  clamp,
  dot,
  float,
  floor,
  fract,
  mix,
  modelNormalMatrix,
  normalLocal,
  normalView,
  normalWorld,
  normalize,
  positionLocal,
  pow,
  sin,
  smoothstep,
  texture,
  cameraViewMatrix,
  uniform,
  vec2,
  vec3,
  vec4,
  vertexColor,
} from 'three/tsl';
import type { TSLNode } from '../graph/compile';

export interface PainterlyOptions {
  /** The stroke normal map (pomme: textures/watercolor_normal.png), RepeatWrapping. */
  normalMap: Texture;
  /** Normal wobble strength (pomme 2.3). */
  normalScale?: number;
  /** Add the hull outline (pomme yes). */
  hull?: boolean;
  /** Debug views: output one intermediate instead of the pigment. */
  debug?: 'strokes' | 'op' | 'pig' | 'cel' | 'lit' | 'dobj' | 'base' | 'nrm' | 'nrmw';
}

export interface PainterlyHandle {
  /** Restore the original materials and remove hulls. */
  remove: () => void;
  /** Animate the stroke "boil" (pomme leaves it at 0). */
  setBoil: (t: number) => void;
}

/** 3-step toon ramp, exactly pomme's bytes. */
function gradientMap(): DataTexture {
  const g = new DataTexture(new Uint8Array([45, 140, 220, 255]), 4, 1, RedFormat);
  g.minFilter = NearestFilter;
  g.magFilter = NearestFilter;
  g.needsUpdate = true;
  return g;
}

/* 3D value noise (hull), same hash as the GLSL original. Materials have no CPU
 * twin so cross-backend hashing is not a concern here. */
const h3 = (p: TSLNode) => fract(sin(dot(p, vec3(12.99, 78.23, 37.72))).mul(43758.5));
const n3 = Fn(([p]: [TSLNode]) => {
  const i = floor(p);
  let f: TSLNode = fract(p);
  f = f.mul(f).mul(float(3).sub(f.mul(2)));
  const a = mix(h3(i), h3(i.add(vec3(1, 0, 0))), f.x);
  const b = mix(h3(i.add(vec3(0, 1, 0))), h3(i.add(vec3(1, 1, 0))), f.x);
  const c = mix(h3(i.add(vec3(0, 0, 1))), h3(i.add(vec3(1, 0, 1))), f.x);
  const d = mix(h3(i.add(vec3(0, 1, 1))), h3(i.add(vec3(1, 1, 1))), f.x);
  return mix(mix(a, b, f.y), mix(c, d, f.y), f.z);
});

/** Apply the painterly style to every mesh under `root`. */
export function applyPainterlyStyle(root: Object3D, opts: PainterlyOptions): PainterlyHandle {
  const normalMap = opts.normalMap;
  // the stroke map is sampled at object coordinates well outside [0,1]; a
  // texture already uploaded with clamp wrapping keeps clamping unless it is
  // re-uploaded, and every sample then reads the same edge texel (no wobble,
  // no pigment zones, flat cel: exactly the "shader looks off" symptom)
  if (normalMap.wrapS !== RepeatWrapping || normalMap.wrapT !== RepeatWrapping) {
    normalMap.wrapS = RepeatWrapping;
    normalMap.wrapT = RepeatWrapping;
    normalMap.needsUpdate = true;
  }
  const grad = gradientMap();
  const boil = uniform(0);
  const nScale = opts.normalScale ?? 2.3;
  const saved: { mesh: Mesh; material: Mesh['material']; hull?: Mesh }[] = [];

  /** One painterly material for one source material slot. */
  const makeMaterial = (src: { color?: Color; map?: Texture | null; colorNode?: unknown; vertexColors?: boolean }, posScale: number): MeshToonNodeMaterial => {
    const m = new MeshToonNodeMaterial();
    m.color = src.color ? src.color.clone() : new Color(1, 1, 1);
    m.gradientMap = grad;

    // ---- stroke-wobbled normal, triplanar in object space ----
    const op = positionLocal.mul(posScale);
    const f = 1.25;
    const b2 = vec2(boil.mul(0.37), boil.mul(0.21));
    const sx = texture(normalMap, op.zy.mul(f).add(b2)).xyz.mul(2).sub(1);
    const sy = texture(normalMap, op.xz.mul(f).add(0.31).sub(b2)).xyz.mul(2).sub(1);
    const sz = texture(normalMap, op.xy.mul(f).add(0.67).add(b2)).xyz.mul(2).sub(1);
    let tw: TSLNode = pow(abs(normalize(normalLocal)), vec3(4));
    tw = tw.div(tw.x.add(tw.y).add(tw.z));
    const dObj: TSLNode = vec3(0, sx.y, sx.x).mul(tw.x).add(vec3(sy.x, 0, sy.y).mul(tw.y)).add(vec3(sz.x, sz.y, 0).mul(tw.z));
    // GLSL: normal = normalize(normal + normalMatrix * dObj * scale). The
    // matrix product must stay UNNORMALISED (dObj is a small offset); TSL's
    // transformNormalToView normalises, which turned the offset into a unit
    // vector that swamped the real normal and flattened all lighting.
    const dWorld: TSLNode = (modelNormalMatrix as TSLNode).mul(dObj);
    const dView: TSLNode = (cameraViewMatrix as TSLNode).mul(vec4(dWorld, 0)).xyz;
    m.normalNode = normalize(normalView.add(dView.mul(nScale)));

    // ---- pigment: 4 dithered zones, warm light / cool dark, grey pull, gamut clamp ----
    const stroke = clamp(float(0.5).add(dObj.x.add(dObj.y).add(dObj.z).mul(1.1)), 0, 1);
    const wx2 = texture(normalMap, op.zy.mul(0.6).add(0.13)).xyz;
    const wy2 = texture(normalMap, op.xz.mul(0.6).add(0.57)).xyz;
    const wz2 = texture(normalMap, op.xy.mul(0.6).add(0.71)).xyz;
    const washV = wx2.mul(tw.x).add(wy2.mul(tw.y)).add(wz2.mul(tw.z)).xy.sub(0.5);
    const wash = clamp(float(0.5).add(washV.x.add(washV.y).mul(2.2)), 0, 1);
    let pig: TSLNode = clamp(stroke.mul(0.6).add(wash.mul(0.6)), 0, 1);
    const dith = sx.x.add(sy.y).mul(0.22);
    pig = clamp(floor(pig.mul(4).add(dith)).add(0.5).div(4), 0, 1);
    // base pigment: a graph-shaded mesh (compileMaterial) carries its pattern in
    // colorNode; otherwise map * color like the GLSL original
    // (pomme's MeshToonMaterial takes vertexColors from the source too)
    const tint = vec3(m.color.r, m.color.g, m.color.b);
    const base: TSLNode = src.colorNode
      ? (src.colorNode as TSLNode).rgb
      : src.vertexColors
        ? vertexColor().rgb.mul(tint)
        : src.map
          ? texture(src.map).rgb.mul(tint)
          : tint;
    const pigLight = base.mul(vec3(1.42, 1.28, 1.02)).add(0.06);
    const pigDark = base.mul(vec3(0.62, 0.48, 0.7));
    let col: TSLNode = mix(pigDark, pigLight, pig);
    col = clamp(mix(col, vec3(dot(col, vec3(0.333))), 0.15), vec3(0.1), vec3(0.92));

    // ---- world-keyed cartoon shadow cel ----
    const celKey = normalize(vec3(0.73, 0.68, 0.06));
    const nW = normalize(normalWorld.add(dWorld.mul(nScale)));
    const cel = dot(nW, celKey).add(dObj.x.add(dObj.y).mul(0.35));
    const shadowZone = float(1).sub(smoothstep(0.28, 0.52, cel));
    const shadowPig = col.mul(vec3(0.34, 0.3, 0.62)).add(vec3(0.03, 0.0, 0.09));
    m.colorNode = mix(col, shadowPig, shadowZone);
    if (opts.debug && opts.debug !== 'lit') {
      // debug views are UNLIT so the numbers on screen are the term itself
      const dbg = new MeshBasicNodeMaterial();
      const views: Record<string, TSLNode> = {
        strokes: sx.mul(0.5).add(0.5),
        op: fract(op),
        pig: vec3(pig),
        cel: vec3(shadowZone),
        dobj: dObj.mul(0.5).add(0.5),
        base,
        nrm: normalWorld.mul(0.5).add(0.5),
        nrmw: nW.mul(0.5).add(0.5),
      };
      dbg.colorNode = views[opts.debug];
      return dbg as unknown as MeshToonNodeMaterial;
    }
    if (opts.debug === 'lit') m.colorNode = vec3(1);
    return m;
  };

  root.traverse((o) => {
    if (!(o instanceof Mesh) || o.userData.isOutline || o.userData.noStyle) return;
    saved.push({ mesh: o, material: o.material });

    o.geometry.computeBoundingBox();
    const bb = o.geometry.boundingBox!.getSize(new Vector3());
    const posScale = 2.0 / Math.max(bb.x, bb.y, bb.z, 1e-6);

    // multi-material meshes keep one painterly material per slot
    const srcs = (Array.isArray(o.material) ? o.material : [o.material]) as { color?: Color; map?: Texture | null; colorNode?: unknown; vertexColors?: boolean }[];
    const mats = srcs.map((src) => makeMaterial(src, posScale));
    o.material = Array.isArray(o.material) ? mats : mats[0];

    if (opts.hull !== false) {
      const hm = new MeshBasicNodeMaterial();
      hm.side = BackSide;
      hm.transparent = true;
      hm.depthWrite = false;
      const vOp = positionLocal.mul(posScale);
      const w = float(0.024).add(n3(vOp.mul(3)).mul(0.016));
      hm.positionNode = positionLocal.add(normalLocal.mul(w.div(posScale).mul(0.5)));
      const t = n3(vOp.mul(6));
      hm.colorNode = mix(vec3(0.26, 0.03, 0.02), vec3(0.24, 0.26, 0.04), t);
      hm.opacityNode = smoothstep(0.08, 0.42, n3(vOp.mul(6).add(31.7))).mul(0.88);
      hm.alphaTest = 0.03;
      const hull = new Mesh(o.geometry, hm);
      hull.userData.isOutline = true;
      o.add(hull);
      saved[saved.length - 1].hull = hull;
    }
  });

  return {
    remove: () => {
      for (const s of saved) {
        s.mesh.material = s.material;
        if (s.hull) s.mesh.remove(s.hull);
      }
      saved.length = 0;
    },
    setBoil: (t) => {
      boil.value = t;
    },
  };
}
