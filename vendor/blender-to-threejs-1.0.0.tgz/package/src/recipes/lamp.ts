/**
 * One lamp, as a MATERIAL graph term. Graph materials are unlit on purpose
 * (lighting is a node in the graph, not something the renderer adds), so a
 * "single hanging lamp over the table" is this: a spot cone with distance
 * falloff times the Lambert term, all from Geometry position/normal and Math
 * nodes, every knob a runtime uniform. Multiply the returned scalar into a
 * colour graph. Pair with one real three.js SpotLight at the same place for
 * cast shadows on a catcher.
 *
 * Blender: a Spot light object does this for a BSDF; here it is the same
 * arithmetic written as nodes so the look is inspectable and tunable.
 *
 *   light = amb + gain * max(N.L, 0) * spot(cosAngle) / (1 + (d / range)^2)
 *   spot  = smoothstep(cos(outer), cos(inner), cosAngle), inner = outer * (1 - blend)
 */
import type { Graph } from '../graph/builder';
import type { GraphNode, NodeInput } from '../graph/types';
import { smoothStep } from './reveal';

export interface SpotLampOptions {
  /** lamp position (world); initial values of the lampX/lampY/lampZ uniforms */
  position?: [number, number, number];
  /** full cone half-angle in degrees (uniform lampCone, stored as degrees) */
  cone?: number;
  /** soft edge fraction of the cone 0..1 (uniform lampBlend) */
  blend?: number;
  /** distance at which falloff halves (uniform lampRange) */
  range?: number;
  /** ambient floor (uniform lampAmb) */
  ambient?: number;
  /** beam gain (uniform lampGain) */
  gain?: number;
  /** flat normal to use instead of Geometry normal (e.g. up for a table top drawn on a disc) */
  normal?: [number, number, number];
  /** uniform name prefix (default 'lamp'); a second lamp in the same graph needs its own ('spill') */
  prefix?: string;
  /** light both faces the same (abs of the Lambert term): for double-sided sheets whose back faces flip N */
  twoSided?: boolean;
}

export function spotLamp(g: Graph, opts: SpotLampOptions = {}): { light: GraphNode; uniforms: Record<string, GraphNode> } {
  const [lx0, ly0, lz0] = opts.position ?? [0, 8, 0];
  const P = opts.prefix ?? 'lamp';
  const uX = g.uniform(`${P}X`, lx0);
  const uY = g.uniform(`${P}Y`, ly0);
  const uZ = g.uniform(`${P}Z`, lz0);
  const uCone = g.uniform(`${P}Cone`, opts.cone ?? 32);
  const uBlend = g.uniform(`${P}Blend`, opts.blend ?? 0.6);
  const uRange = g.uniform(`${P}Range`, opts.range ?? 9);
  const uAmb = g.uniform(`${P}Amb`, opts.ambient ?? 0.12);
  const uGain = g.uniform(`${P}Gain`, opts.gain ?? 1.4);

  const p = g.position('world');
  const px = g.separate(p, 'x'), py = g.separate(p, 'y'), pz = g.separate(p, 'z');
  const n = opts.normal ? g.combine(opts.normal[0], opts.normal[1], opts.normal[2]) : g.normal('world');
  const nx = g.separate(n, 'x'), ny = g.separate(n, 'y'), nz = g.separate(n, 'z');

  // to-lamp vector and distance
  const Lx = g.subtract(uX, px), Ly = g.subtract(uY, py), Lz = g.subtract(uZ, pz);
  const d = g.math('SQRT', g.add(g.add(g.multiply(Lx, Lx), g.multiply(Ly, Ly)), g.multiply(Lz, Lz)));
  const dSafe = g.math('MAXIMUM', d, 1e-4);
  const lnx = g.divide(Lx, dSafe), lny = g.divide(Ly, dSafe), lnz = g.divide(Lz, dSafe);
  const nl = g.add(g.add(g.multiply(nx, lnx), g.multiply(ny, lny)), g.multiply(nz, lnz));
  const ndotl = opts.twoSided ? g.math('ABSOLUTE', nl) : g.math('MAXIMUM', nl, 0);

  // the lamp points straight down: cos of the angle off-axis is the y component of the unit to-lamp vector
  const cosAng = lny;
  const outer = g.math('COSINE', g.math('RADIANS', uCone));
  const inner = g.math('COSINE', g.math('RADIANS', g.multiply(uCone, g.subtract(1, uBlend))));
  const spot = smoothStep(g, cosAng, outer, inner);

  const dr = g.divide(d, uRange);
  const atten = g.divide(1, g.add(1, g.multiply(dr, dr)));

  const light = g.add(uAmb, g.multiply(g.multiply(g.multiply(uGain, ndotl), spot), atten));
  return { light, uniforms: { [`${P}X`]: uX, [`${P}Y`]: uY, [`${P}Z`]: uZ, [`${P}Cone`]: uCone, [`${P}Blend`]: uBlend, [`${P}Range`]: uRange, [`${P}Amb`]: uAmb, [`${P}Gain`]: uGain } };
}

/** multiply a colour by a scalar light term */
export function lit(g: Graph, color: NodeInput, light: NodeInput): GraphNode {
  return g.multiplyColor(1, color, g.combine(light, light, light));
}
