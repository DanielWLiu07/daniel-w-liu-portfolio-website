/**
 * Paint-in reveal, as a material graph (pomme's uGrow floor reveal, natureScene.js).
 *
 * A noise field over world XZ, biased so it is zero at the impact point, is
 * swept by a `grow` uniform: where field < grow the surface is painted (mask 1),
 * with a soaked darker rim right at the wet front. Unpainted surface is
 * transparent, so only paper shows until the paint reaches it. Blender nodes
 * only: Geometry position, Noise Texture (three scales for the octaves), Math,
 * Map Range.
 *
 *   field = noise * 0.72 + (dist / reach) * 0.42 - 0.18 * (1 - smoothstep(0, 1.4, dist))
 *   mask  = smoothstep(grow + 0.03, grow - 0.10, field)   (inverted: paint where field < grow)
 *   rim   = smoothstep(grow - 0.10, grow - 0.02, field) * (1 - smoothstep(grow - 0.02, grow + 0.03, field))
 *
 * Drive: grow = min(1, 0.2 * clamp(t / 0.05) + 1 - (1 - t / 4.6)^2) from the impact time,
 * exactly pomme's kick + soak.
 */
import type { Graph } from '../graph/builder';
import type { GraphNode, NodeInput } from '../graph/types';

export interface RevealOptions {
  /** World XZ of the impact. */
  centre: [number, number];
  /** Distance at which the field's radial term reaches 0.42 (pomme 8.5). A scalar graph (e.g. a uniform) is fine. */
  reach?: NodeInput;
  /** The grow uniform node (g.uniform('grow', 0)); created if omitted. */
  grow?: GraphNode;
  /**
   * Extra distance added to the radial term, in world units (a scalar graph). Use it to
   * hold parts back: e.g. a table's pedestal gets `max(0, feltY - y) * 4` so anything below
   * the top paints only after the surface around it has.
   */
  extraDistance?: NodeInput;
  /** scale of the noise term (1 = pomme's 0.72); higher = blotchier, more painterly front. A uniform is fine. */
  noiseAmount?: NodeInput;
  /**
   * scale of the radial term (1 = pomme's 0.42). Raise it and lower noiseAmount for a "wet bloom": one
   * front travelling out from the impact with a wobbled, fingered edge instead of blots popping everywhere.
   */
  radialAmount?: NodeInput;
  /** width of the soft front (default 0.13 in field units) */
  softness?: NodeInput;
}

/** GLSL smoothstep(e0, e1, x) as Math nodes (Blender has no smoothstep node; Map Range Smooth Step is the same curve). */
export function smoothStep(g: Graph, x: NodeInput, e0: NodeInput, e1: NodeInput): GraphNode {
  const t = g.math('DIVIDE', g.subtract(x, e0), g.subtract(e1, e0), 0, { clamp: true });
  return g.multiply(g.multiply(t, t), g.subtract(3, g.multiply(t, 2)));
}
const smooth = smoothStep;

export function revealMask(g: Graph, opts: RevealOptions): { mask: GraphNode; rim: GraphNode; grow: GraphNode } {
  const grow = opts.grow ?? g.uniform('grow', 0);
  const reach = opts.reach ?? 8.5;
  const p = g.position('world');
  const px = g.separate(p, 'x');
  const pz = g.separate(p, 'z');
  const dx = g.subtract(px, opts.centre[0]);
  const dz = g.subtract(pz, opts.centre[1]);
  let dist: GraphNode = g.math('SQRT', g.add(g.multiply(dx, dx), g.multiply(dz, dz)));
  if (opts.extraDistance !== undefined) dist = g.add(dist, opts.extraDistance);
  // three octaves like pomme's gn(p*0.5)*0.55 + gn(p*1.4)*0.3 + gn(p*4.2)*0.15
  const xz = g.combine(px, 0, pz);
  const n = g.add(
    g.add(g.multiply(g.noise(xz, { scale: 0.5, detail: 0 }), 0.55), g.multiply(g.noise(xz, { scale: 1.4, detail: 0 }), 0.3)),
    g.multiply(g.noise(xz, { scale: 4.2, detail: 0 }), 0.15),
  );
  const nAmp = g.multiply(0.72, opts.noiseAmount ?? 1);
  const rAmp = g.multiply(0.42, opts.radialAmount ?? 1);
  // fine fingers at the front: a higher octave scaled by distance so the edge frays as it travels
  const fingers = g.multiply(g.multiply(g.subtract(g.noise(xz, { scale: 9, detail: 0 }), 0.5), 0.12), g.math('MINIMUM', g.divide(dist, reach), 1));
  const field = g.subtract(
    g.add(g.add(g.multiply(n, nAmp), g.multiply(g.divide(dist, reach), rAmp)), fingers),
    g.multiply(0.18, g.subtract(1, smooth(g, dist, 0, 1.4))),
  );
  // inverted smoothstep: 1 where field is below the sweep
  const soft = opts.softness ?? 0.13;
  const mask = smooth(g, field, g.add(grow, 0.03), g.subtract(grow, g.subtract(soft, 0.03)));
  const rim = g.multiply(
    smooth(g, field, g.subtract(grow, 0.1), g.subtract(grow, 0.02)),
    g.subtract(1, smooth(g, field, g.subtract(grow, 0.02), g.add(grow, 0.03))),
  );
  // hard gate: nothing before the impact
  const gated = g.multiply(mask, smooth(g, grow, 0.002, 0.02));
  return { mask: gated, rim, grow };
}

/** pomme's grow curve from seconds since impact: a 50 ms kick then a 4.6 s soak. */
export function growFromImpact(secondsSinceImpact: number): number {
  if (secondsSinceImpact < 0) return 0;
  const m = Math.min(1, secondsSinceImpact / 4.6);
  const kick = 0.2 * Math.min(1, Math.max(0, secondsSinceImpact / 0.05));
  return Math.min(1, kick + 1 - (1 - m) * (1 - m));
}
