/**
 * Inverted-hull outline (spec section 11; approximates the Grease-Pencil lineart rig).
 *
 * Normal-inflate, NOT scale-hull — exported meshes have applied transforms, so a
 * scale hull inflates asymmetrically (GOTCHAS). Black BackSide mesh sharing the
 * geometry, positionNode pushed along the local normal, renderOrder -1.
 */
import { BackSide, Mesh } from 'three';
import { MeshBasicNodeMaterial } from 'three/webgpu';
import { normalLocal, positionLocal, uniform, vec3 } from 'three/tsl';

export interface OutlineOptions {
  thickness?: number;
}

export function createOutlineMaterial(opts: OutlineOptions = {}) {
  const uThickness = uniform(opts.thickness ?? 0.018);
  const material = new MeshBasicNodeMaterial();
  material.side = BackSide;
  material.colorNode = vec3(0, 0, 0);
  material.positionNode = positionLocal.add(normalLocal.mul(uThickness));
  return { material, uniforms: { thickness: uThickness } };
}

/**
 * Attach outline hulls to every mesh under `root`.
 * Collect first, add after — adding children DURING traverse() recurses forever (GOTCHAS).
 */
export function addOutlines(root: { traverse(cb: (o: unknown) => void): void }, opts: OutlineOptions = {}) {
  const { material } = createOutlineMaterial(opts);
  const targets: Mesh[] = [];
  root.traverse((o) => {
    if ((o as Mesh).isMesh) targets.push(o as Mesh);
  });
  for (const mesh of targets) {
    const hull = new Mesh(mesh.geometry, material);
    hull.renderOrder = -1;
    mesh.add(hull);
  }
}
