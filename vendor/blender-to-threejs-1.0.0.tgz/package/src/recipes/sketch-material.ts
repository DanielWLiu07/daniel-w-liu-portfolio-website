/**
 * createSketchMaterial — the crosshatch "sketch" recipe (spec section 6, node-for-node).
 *
 * Composition (primitives -> recipe -> overrides, per the brief 4b):
 *   eeveeLighting(normal)                 -> shade        (approximate primitive)
 *   overlay(shade, brightness)            -> finalShade   (exact)
 *   3x map-range bands over finalShade    -> ink masks    (exact; ranges from Bands Sharpness curve)
 *   multiply-from-white over chaotic RGB  -> mask2        (exact)
 *   aoDarken + HSV value variation        -> effectiveInk (approximate: AO strategy enum)
 *   mix(effectiveInk, paper, mask2)       -> color
 *
 * Override layers, cheapest first: uniforms (runtime) -> options (build time)
 * -> strategy enums (ao) -> injectable nodes (normalNode/shadeNode escape hatch).
 */
import { Texture, Vector3 } from 'three';
import { MeshBasicNodeMaterial } from 'three/webgpu';
import { float, mix, oneMinus, select, uniform, vec3 } from 'three/tsl';

import { eeveeLighting, SketchLight, TSLNode } from '../primitives/eevee-lighting';
import { flatShadeNormal } from '../primitives/flat-normal';
import { hatchComposite, hatchUV, sampleHatch } from '../primitives/hatch';
import { AOStrategy, aoDarken, aoNode } from '../primitives/ao';
import { hatchPixelScale, resolveBands } from '../primitives/blender-math';

/** Scene lights from the spec (section 4): Y-up surface->light dirs + energies. */
export const SKETCH_LIGHTS: readonly SketchLight[] = [
  { dir: new Vector3(0.5929, 0.6163, 0.5183).normalize(), energy: 5.0 },
  { dir: new Vector3(0, 1, 0), energy: 3.0 },
] as const;

export interface SketchMaterialOptions {
  /** Ink color, LINEAR channel values straight from Blender (do NOT sRGB-convert). */
  inkColor: [number, number, number];
  /** chaotic.png (sRGB, RepeatWrapping) — the 3 hatch layers in R/G/B. */
  hatchTexture: Texture;
  /** Blender "Bands Sharpness" (monkey 0.529, sphere 0.580769). */
  bandsSharpness?: number;
  /** 1 = flat-shaded (big monkey), 0 = smooth. */
  flatShade?: number;
  /** AO strategy enum; 'uv' needs aoMap (NoColorSpace bake at GTAO distance ~0.2). */
  aoStrategy?: AOStrategy;
  aoMap?: Texture;
  /** Blender AO Amount x bake compensation (spec section 7: approx 0.7 vs the dark Cycles bake). */
  aoAmount?: number;
  /** Principled Base Color grey ("Brightness", linear). */
  brightness?: number;
  roughness?: number;
  /** World bg grey x strength. */
  worldAmbient?: number;
  /** Blender Mapping scale for the hatch (86.63 in the scene). */
  hatchScale?: number;
  /** Render resolution the hatch UV math is defined against. */
  resolution?: [number, number];
  lights?: readonly SketchLight[];
  /** Injectable escape hatches — replace one stage without forking the recipe. */
  normalNode?: TSLNode;
  shadeNode?: (defaultShade: TSLNode) => TSLNode;
}

export interface SketchMaterial {
  material: MeshBasicNodeMaterial;
  /** Runtime-tunable uniforms (never hardcoded floats — brief 4b). */
  uniforms: {
    brightness: ReturnType<typeof uniform>;
    roughness: ReturnType<typeof uniform>;
    worldAmbient: ReturnType<typeof uniform>;
    aoAmount: ReturnType<typeof uniform>;
    flatShade: ReturnType<typeof uniform>;
    pixelScale: ReturnType<typeof uniform>;
    inkColor: ReturnType<typeof uniform>;
  };
  /** Re-derive the three band ranges from a new Bands Sharpness. */
  setBandsSharpness: (sharpness: number) => void;
  setHatchScale: (scale: number) => void;
}

/**
 * GPU-side Blender Overlay at Fac=1 (per mix_overlay in Blender's
 * gpu_shader_common_mix_rgb.glsl): a<0.5 -> 2ab, else 1-2(1-a)(1-b).
 * NO result clamp — the node sets clamp_factor only, and Blender's overlay does
 * not clamp its output (verified vs source; unit-tested in tests/blender-ops).
 */
function overlayNode(a: TSLNode, b: TSLNode): TSLNode {
  const low = a.mul(b).mul(2.0);
  const high = oneMinus(oneMinus(a).mul(oneMinus(b)).mul(2.0));
  return select(a.lessThan(0.5), low, high);
}

export function createSketchMaterial(opts: SketchMaterialOptions): SketchMaterial {
  const {
    bandsSharpness = 0.529,
    aoStrategy = 'none',
    aoAmount = 0.7,
    brightness = 0.3205,
    roughness = 0.509615,
    worldAmbient = 0.05,
    hatchScale = 86.63,
    resolution = [1980, 1080],
    lights = SKETCH_LIGHTS,
  } = opts;

  // --- uniforms (all runtime-tunable) ---
  const uBrightness = uniform(brightness);
  const uRoughness = uniform(roughness);
  const uWorldAmbient = uniform(worldAmbient);
  const uAOAmount = uniform(aoAmount);
  const uFlatShade = uniform(opts.flatShade ?? 0);
  const uPixelScale = uniform(hatchPixelScale(hatchScale));
  // Blender socket colors are LINEAR floats — carry them verbatim in a Vector3
  // uniform so no color-management path can silently re-encode them.
  const uInkColor = uniform(new Vector3(opts.inkColor[0], opts.inkColor[1], opts.inkColor[2]));
  const bandUniforms = resolveBands(bandsSharpness).map((r) => ({
    toMin: uniform(r.toMin),
    toMax: uniform(r.toMax),
  }));

  // --- graph ---
  const normal = opts.normalNode ?? flatShadeNormal(uFlatShade);
  const defaultShade = eeveeLighting(normal, {
    brightness: uBrightness,
    roughness: uRoughness,
    worldAmbient: uWorldAmbient,
    lights,
  });
  const shade = opts.shadeNode ? opts.shadeNode(defaultShade) : defaultShade;
  const finalShade = overlayNode(shade, uBrightness);

  const layers = sampleHatch(opts.hatchTexture, hatchUV(resolution, uPixelScale));
  const mask2 = hatchComposite(finalShade, layers, bandUniforms);

  const ao = aoNode({ strategy: aoStrategy, aoMap: opts.aoMap });
  const darken = aoDarken(ao, uAOAmount);
  let effectiveInk = mix(vec3(uInkColor), vec3(0, 0, 0), darken);
  // HSV Value Variation (spec 6.7): value 0.7, Fac = chaotic G.
  effectiveInk = effectiveInk.mul(mix(float(1.0), float(0.7), layers.g));

  const material = new MeshBasicNodeMaterial();
  material.colorNode = mix(effectiveInk, vec3(1, 1, 1), mask2);

  return {
    material,
    uniforms: {
      brightness: uBrightness,
      roughness: uRoughness,
      worldAmbient: uWorldAmbient,
      aoAmount: uAOAmount,
      flatShade: uFlatShade,
      pixelScale: uPixelScale,
      inkColor: uInkColor,
    },
    setBandsSharpness(sharpness: number) {
      resolveBands(sharpness).forEach((r, i) => {
        bandUniforms[i].toMin.value = r.toMin;
        bandUniforms[i].toMax.value = r.toMax;
      });
    },
    setHatchScale(scale: number) {
      uPixelScale.value = hatchPixelScale(scale);
    },
  };
}
