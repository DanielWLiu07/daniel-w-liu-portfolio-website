/**
 * Per-object watercolour and felt, as MATERIAL graphs (graph() only, every node
 * a Blender shader node). This is the material half of the hybrid split: what
 * belongs to the surface (paper wobble, pigment turbulence, posterised wash,
 * geometric edge darkening, granulation) lives here per object; what needs the
 * neighbourhood (bleed past the silhouette, paper continuity, impact frames)
 * stays in the compositor. Both recipes are fully inspectable in the viewer
 * (`?graph=material:watercolor`, `?graph=material:felt`) and evaluable on the
 * CPU where their inputs are constant.
 *
 * Nodes used: Texture Coordinate (object), Mapping, Noise Texture, Map Range,
 * Color Ramp, Mix, Math, Layer Weight, Geometry normal. Nothing else.
 */
import type { Graph } from '../graph/builder';
import type { GraphNode, NodeInput } from '../graph/types';

export interface WatercolorMaterialOptions {
  /** Base pigment colour (scene-linear). */
  base?: NodeInput;
  /** Object-space texture scale (paper grain frequency). */
  scale?: number;
  /** Paper wobble amplitude in object units. */
  wobble?: number;
  /** Number of wash bands. */
  bands?: number;
  /** Rim darkening strength 0..1. */
  edge?: number;
}

/**
 * Watercolour on one object. Returns the colour socket for compileMaterial.
 */
export function watercolorMaterialGraph(g: Graph, opts: WatercolorMaterialOptions = {}): GraphNode {
  const base = opts.base ?? g.rgb(0.72, 0.1, 0.12);
  const scale = opts.scale ?? 1;
  const wobble = opts.wobble ?? 0.06;
  const bands = opts.bands ?? 3;
  const edge = opts.edge ?? 0.7;

  // paper distortion: object coordinates pushed by a low-frequency noise colour
  const co = g.mapping(g.position('object'), { type: 'POINT', scale: [scale, scale, scale] });
  const wob = g.noise(co, { scale: 9, detail: 1, output: 'color' });
  const push = g.combine(
    g.multiply(g.subtract(g.separate(wob, 'x'), 0.5), wobble),
    g.multiply(g.subtract(g.separate(wob, 'y'), 0.5), wobble),
    g.multiply(g.subtract(g.separate(wob, 'z'), 0.5), wobble),
  );
  const coW = g.combine(
    g.add(g.separate(co, 'x'), g.separate(push, 'x')),
    g.add(g.separate(co, 'y'), g.separate(push, 'y')),
    g.add(g.separate(co, 'z'), g.separate(push, 'z')),
  );

  // pigment turbulence: 0.82 + 0.36 * noise, the same numbers as the pass
  const turb = g.mapRange(g.noise(coW, { scale: 1.05, detail: 2 }), { from: [0, 1], to: [0.82, 1.18], clamp: false });
  let col: GraphNode = g.multiplyColor(1, base, g.combine(turb, turb, turb));

  // posterised wash: a normal-driven "light" quantised into bands with a dithered edge
  const lit = g.mapRange(g.separate(g.normal('world'), 'y'), { from: [-1, 1], to: [0.15, 1], clamp: true });
  const dith = g.multiply(g.subtract(g.noise(coW, { scale: 4.2, detail: 2 }), 0.5), 0.35);
  const q = g.divide(g.add(g.math('FLOOR', g.add(g.multiply(lit, bands), dith)), 0.5), bands);
  const wash = g.blend(0.6, lit, q, { clampResult: true });
  const washRamp = g.colorRamp(
    wash,
    [
      { position: 0, color: [0.35, 0.3, 0.45, 1] },
      { position: 1, color: [1, 1, 1, 1] },
    ],
    'LINEAR',
  );
  col = g.multiplyColor(1, col, washRamp);

  // edge darkening from geometry: pigment pools toward the rim (Layer Weight facing)
  const rim = g.layerWeight(0.35, 'facing');
  const dark = g.multiplyColor(1, col, g.rgb(0.55, 0.45, 0.6));
  col = g.blend(g.multiply(rim, edge), col, dark);

  // granulation: clumpy, only in mid tones
  const gclump = g.multiply(g.noise(coW, { scale: 13, detail: 1 }), g.noise(coW, { scale: 22, detail: 1 }));
  const gran = g.mapRange(gclump, { from: [0, 1], to: [0.9, 1.12], clamp: true });
  col = g.multiplyColor(1, col, g.combine(gran, gran, gran));
  return col;
}

export interface FeltOptions {
  /** Noise detail (octaves) of the fibre and mottle terms; each octave is a full perlin lookup, so lower them on large surfaces (default 3 / 2). */
  fibreDetail?: number;
  mottleDetail?: number;
}

/** Green baize: fibre noise, mottling, and a fuzzy rim from Layer Weight. */
export function feltMaterialGraph(g: Graph, base: NodeInput = g.rgb(0.1, 0.42, 0.24), opts: FeltOptions = {}): GraphNode {
  const co = g.position('object');
  const fibre = g.mapRange(g.noise(co, { scale: 90, detail: opts.fibreDetail ?? 3, roughness: 0.6 }), { from: [0, 1], to: [0.9, 1.1], clamp: true });
  const mottle = g.mapRange(g.noise(co, { scale: 3, detail: opts.mottleDetail ?? 2 }), { from: [0, 1], to: [0.85, 1.05], clamp: true });
  const lift = g.mapRange(g.separate(g.normal('world'), 'y'), { from: [-1, 1], to: [0.4, 1.0], clamp: true });
  const shade = g.multiply(g.multiply(fibre, mottle), lift);
  const col = g.multiplyColor(1, base, g.combine(shade, shade, shade));
  // felt brightens at grazing angles: fibres catch light at the silhouette
  const rim = g.layerWeight(0.5, 'facing');
  return g.blend(g.multiply(rim, 0.35), col, g.multiplyColor(1, col, g.rgb(1.35, 1.3, 1.2)));
}
