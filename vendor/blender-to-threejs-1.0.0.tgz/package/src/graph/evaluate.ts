/**
 * CPU evaluation of an authored graph, on top of the reference ops in
 * src/transpiler/blender-ops.ts.
 *
 * This exists so the node system is testable without a GPU. blender-ops was
 * written as "the executable spec the TSL emitters are unit-tested against" —
 * evaluating a whole graph through it turns that spec into a harness: build a
 * graph, evaluate it, compare against Blender's own numbers. It is also what
 * constant-folds a subtree whose inputs are all literals, so per-material
 * constants reach the GPU as uniforms instead of per-pixel work.
 *
 * Node semantics live here ONLY as dispatch. Every actual formula comes from
 * blender-ops, which cites the Blender GLSL it mirrors. If a value looks wrong,
 * fix it there, once, and both the CPU and GPU paths move together.
 */
import {
  evalColorRamp,
  evalMath,
  invert,
  mapRangeLinear,
  mappingNode,
  mixBlend,
  mixLinearLight,
  mixMultiply,
  mixOverlay,
  mixScreen,
  noiseTex3D,
  gamma,
  vectorMath,
  voronoiTex,
  waveTex3D,
  type MappingType,
  type Vec4,
  type VectorMathOp,
  type VoronoiFeature,
  type VoronoiMetric,
  type WaveBandsDir,
  type WaveProfile,
  type WaveRingsDir,
  type WaveType,
} from '../transpiler/blender-ops';
import { isColor, isNode, type Color, type GraphNode, type GraphValue, type NodeInput } from './types';

/**
 * Blender broadcasts a float into a colour socket as (v, v, v, 1). That
 * direction is well defined and used constantly, so it is supported silently.
 */
function asColor(v: GraphValue): Color {
  return isColor(v) ? v : ([v, v, v, 1] as Vec4);
}

/**
 * The reverse is NOT supported. Blender does convert colour->float implicitly,
 * but which reduction it uses (average vs luminance) differs by context, and
 * this project's rule is to port real values rather than guess at them. Ask the
 * author to be explicit instead of silently picking one.
 */
function asScalar(v: GraphValue, where: string): number {
  if (isColor(v)) {
    throw new Error(
      `[graph] ${where} received a colour where a float was expected. ` +
        'Blender\'s implicit colour->float reduction is context-dependent; ' +
        'take an explicit channel (SeparateColor) rather than guessing.',
    );
  }
  return v;
}

type Evaluator = (node: GraphNode, input: (i: number) => GraphValue) => GraphValue;

/**
 * Marks a node whose value varies per fragment. Constant folding is the only
 * thing the CPU path is for, and a UV or a texture sample has no single answer —
 * so this reports honestly instead of inventing one.
 */
const varying =
  (label: string): Evaluator =>
  () => {
    throw new Error(
      `[graph] ${label} varies per fragment and has no CPU value. ` +
        'Compile the graph instead of evaluating it, or fold only the constant subtrees.',
    );
  };

/**
 * One entry per supported bl_idname. Anything absent throws rather than being
 * approximated — the same honest-degradation rule blender-ops applies to
 * unknown Math operations.
 */
const EVALUATORS: Record<string, Evaluator> = {
  ShaderNodeValue: (n) => n.params.value as number,

  ShaderNodeRGB: (n) => n.params.color as Color,

  ShaderNodeMath: (n, input) =>
    evalMath(
      n.params.operation as string,
      asScalar(input(0), 'Math.a'),
      asScalar(input(1), 'Math.b'),
      asScalar(input(2), 'Math.c'),
      Boolean(n.params.useClamp),
    ),

  ShaderNodeMix: (n, input) => {
    const blend = n.params.blendType as string;
    const flags = {
      clampFactor: Boolean(n.params.clampFactor),
      clampResult: Boolean(n.params.clampResult),
    };
    const fac = asScalar(input(0), 'Mix.fac');
    const rawA = input(1);
    const rawB = input(2);
    // Blender's Mix node carries a data_type. Two floats in means a float mix
    // (what the sketch recipe's overlay actually is); anything else is RGBA.
    const floatMode = !isColor(rawA) && !isColor(rawB);
    const a = asColor(rawA);
    const b = asColor(rawB);

    let out: Color;
    switch (blend) {
      case 'MIX':
        out = mixBlend(fac, a, b, flags);
        break;
      case 'MULTIPLY':
        out = mixMultiply(fac, a, b, flags);
        break;
      case 'OVERLAY':
        out = mixOverlay(fac, a, b, flags);
        break;
      case 'SCREEN':
        out = mixScreen(fac, a, b, flags);
        break;
      case 'LINEAR_LIGHT':
        out = mixLinearLight(fac, a, b, flags);
        break;
      default:
        throw new Error(`[graph] Mix blend type '${blend}' not implemented`);
    }
    // Float mode runs the same verified op on a broadcast value and reads one
    // channel back, rather than keeping a second copy of the formula that could
    // drift from it.
    return floatMode ? out[0] : out;
  },

  ShaderNodeMapRange: (n, input) =>
    mapRangeLinear(
      asScalar(input(0), 'MapRange.value'),
      n.params.fromMin as number,
      n.params.fromMax as number,
      n.params.toMin as number,
      n.params.toMax as number,
      Boolean(n.params.clamp),
    ),

  ShaderNodeValToRGB: (n, input) =>
    evalColorRamp(
      asScalar(input(0), 'ColorRamp.fac'),
      n.params.stops as Parameters<typeof evalColorRamp>[1],
      n.params.interpolation as Parameters<typeof evalColorRamp>[2],
    ),

  ShaderNodeInvert: (_, input) => invert(asScalar(input(0), 'Invert.fac'), asColor(input(1))),

  // Varying inputs have no CPU value by definition — they differ per fragment.
  // They still need entries here: the parity test requires every node type to be
  // known to both backends, and a graph that reaches one of these needs to be
  // told it cannot be folded rather than silently handed a made-up number.
  // Not varying: separating a constant colour is a legitimate fold. It only
  // becomes unfoldable when its input is, and that error propagates on its own.
  GraphSeparate: (n, input) => {
    const v = input(0);
    if (!isColor(v)) {
      throw new Error('[graph] Separate expects a vector or colour, not a float');
    }
    return v[{ x: 0, y: 1, z: 2 }[n.params.channel as 'x' | 'y' | 'z']];
  },

  GraphCombine: (_, input) => [
    asScalar(input(0), 'Combine.x'),
    asScalar(input(1), 'Combine.y'),
    asScalar(input(2), 'Combine.z'),
    1,
  ],

  GraphUV: varying('UV'),
  GraphVertexColor: varying('Vertex colour'),
  GraphPosition: varying('Position'),
  GraphWindow: varying('Window'),
  GraphNormal: varying('Normal'),
  GraphTexture: varying('Texture'),
  GraphTime: varying('Time'),

  /* Noise Texture folds when its vector is a constant (a varying vector throws upstream). */
  ShaderNodeTexNoise: (n, input) => {
    const v = asColor(input(0));
    const scale = asScalar(input(1), 'Noise.scale');
    const r = noiseTex3D([v[0], v[1], v[2]], {
      scale,
      detail: n.params.detail as number,
      roughness: n.params.roughness as number,
      lacunarity: n.params.lacunarity as number,
      distortion: n.params.distortion as number,
      normalize: n.params.normalize as boolean,
    });
    return n.params.output === 'color' ? r.color : r.fac;
  },
  ShaderNodeTexWave: (n, input) => {
    const v = asColor(input(0));
    const r = waveTex3D([v[0], v[1], v[2]], {
      scale: asScalar(input(1), 'Wave.scale'),
      distortion: asScalar(input(2), 'Wave.distortion'),
      detail: n.params.detail as number,
      detailScale: asScalar(input(3), 'Wave.detailScale'),
      detailRoughness: n.params.detailRoughness as number,
      phase: asScalar(input(4), 'Wave.phase'),
      waveType: n.params.waveType as WaveType,
      bandsDirection: n.params.bandsDirection as WaveBandsDir,
      ringsDirection: n.params.ringsDirection as WaveRingsDir,
      waveProfile: n.params.waveProfile as WaveProfile,
    });
    return n.params.output === 'color' ? r.color : r.fac;
  },
  ShaderNodeTexVoronoi: (n, input) => {
    const v = asColor(input(0));
    return voronoiTex([v[0], v[1], v[2]], {
      scale: asScalar(input(1), 'Voronoi.scale'),
      randomness: asScalar(input(2), 'Voronoi.randomness'),
      smoothness: asScalar(input(3), 'Voronoi.smoothness'),
      exponent: asScalar(input(4), 'Voronoi.exponent'),
      metric: n.params.metric as VoronoiMetric,
      feature: n.params.feature as VoronoiFeature,
      dimensions: n.params.dimensions as '2D' | '3D',
    });
  },
  ShaderNodeVectorMath: (n, input) => {
    const a = asColor(input(0)), b = asColor(input(1)), c = asColor(input(2));
    const r = vectorMath(
      n.params.operation as VectorMathOp,
      [a[0], a[1], a[2]], [b[0], b[1], b[2]], [c[0], c[1], c[2]],
      asScalar(input(3), 'VectorMath.scale'),
    );
    return n.params.output === 'value' ? r.value : [r.vector[0], r.vector[1], r.vector[2], 1];
  },
  ShaderNodeGamma: (_, input) => gamma(asColor(input(0)), asScalar(input(1), 'Gamma.gamma')),
  ShaderNodeBsdfDiffuse: varying('Diffuse BSDF'),
  ShaderNodeShaderToRGB: varying('Shader to RGB'),
  ShaderNodeLayerWeight: varying('Layer Weight'),
  ShaderNodeFresnel: varying('Fresnel'),
  ShaderNodeMapping: (n, input) => {
    const v = asColor(input(0));
    const r = mappingNode(
      n.params.mappingType as MappingType,
      [v[0], v[1], v[2]],
      n.params.location as [number, number, number],
      n.params.rotation as [number, number, number],
      n.params.scale as [number, number, number],
    );
    return [r[0], r[1], r[2], 1];
  },

  /**
   * The driven Mapping evaluates the same way the constant one does; the only
   * difference is that location, rotation and scale arrive as inputs. On the CPU
   * they are just three more vectors, so this shares mappingNode with the
   * constant form and cannot drift from it.
   */
  GraphMappingDynamic: (n, input) => {
    const v = asColor(input(0));
    const loc = asColor(input(1));
    const rot = asColor(input(2));
    const sc = asColor(input(3));
    const r = mappingNode(
      n.params.mappingType as MappingType,
      [v[0], v[1], v[2]],
      [loc[0], loc[1], loc[2]],
      [rot[0], rot[1], rot[2]],
      [sc[0], sc[1], sc[2]],
    );
    return [r[0], r[1], r[2], 1];
  },
};

export const isEvaluable = (type: string): boolean => type in EVALUATORS;

/** Node types with a CPU evaluator — used by the parity test against the emitter. */
export const evaluableTypes = (): string[] => Object.keys(EVALUATORS);

/**
 * Evaluate a node (or a bare literal) to a concrete value.
 *
 * The cache is keyed by node id so a diamond in the graph evaluates its shared
 * subtree once, not once per path — graphs of any real size fan in heavily.
 */
export function evaluate(target: NodeInput, cache = new Map<number, GraphValue>()): GraphValue {
  if (!isNode(target)) return target;
  const hit = cache.get(target.id);
  if (hit !== undefined) return hit;

  const fn = EVALUATORS[target.type];
  if (!fn) {
    throw new Error(
      `[graph] no CPU evaluator for '${target.type}'. Unsupported nodes must be ` +
        'declared, not guessed at — add one to EVALUATORS or bake this subtree.',
    );
  }

  const value = fn(target, (i) => evaluate(target.inputs[i], cache));
  cache.set(target.id, value);
  return value;
}

/** Evaluate to a float, rejecting a colour result. */
export function evaluateScalar(target: NodeInput): number {
  return asScalar(evaluate(target), 'result');
}

/** Evaluate to RGBA, broadcasting a float result the way Blender would. */
export function evaluateColor(target: NodeInput): Color {
  return asColor(evaluate(target));
}
