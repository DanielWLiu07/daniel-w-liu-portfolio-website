/**
 * Compositor probe: does the GPU agree with the CPU, and with Blender?
 *
 * Every Blender ground-truth case (tests/fixtures/comp, written by
 * tools/comp-truth/comp_truth.py) is rebuilt as a graph, run through the real
 * Compositor runtime (scene target, materialised stages, final blit) into a
 * float target at the fixture size, read back, and compared pixel for pixel
 * against renderComp (CPU) and the Blender output. Three backends, one graph.
 *
 * Inputs enter as CompositorNodeImage over float DataTextures, exactly the way
 * an application would hand a texture to the graph.
 */
import {
  ClampToEdgeWrapping,
  DataTexture,
  FloatType,
  LinearFilter,
  NoColorSpace,
  OrthographicCamera,
  RGBAFormat,
  RenderTarget,
  Scene,
} from 'three';
import { WebGPURenderer } from 'three/webgpu';
import { compGraph } from '../comp/builder';
import { Compositor } from '../comp/compositor';
import { renderComp, type CompImage } from '../comp/evaluate';
import { TRUTH_APPROX, TRUTH_TOL, buildTruthCase, type TruthManifest } from '../comp/truth-cases';
import { fbm, mangaTone, paperGrain, valueNoise } from '../comp/custom-nodes';
import { watercolorGraph } from '../recipes/watercolor-comp';
import type { CompGraph } from '../comp/builder';
import type { CompInput } from '../comp/types';

const hud = document.getElementById('hud') as HTMLDivElement;

/** GPU vs CPU: half-float stages carry ~11 bits; kernels accumulate a little more. */
const GPU_TOL: Record<string, number> = { filter: 8e-3, blur: 8e-3, chain: 1.2e-2, displace: 2e-2 };
const GPU_TOL_DEFAULT = 4e-3;

interface Result {
  name: string;
  gpuVsCpu: number;
  gpuVsBlender: number;
  cpuVsBlender: number;
  meanGpuVsBlender: number;
  pass: boolean;
}

async function loadF32(url: string, w: number, h: number): Promise<CompImage> {
  const buf = await (await fetch(url)).arrayBuffer();
  const data = new Float32Array(buf);
  if (data.length !== w * h * 4) throw new Error(`${url}: ${data.length} floats`);
  return { width: w, height: h, data };
}

function stats(a: Float32Array, b: Float32Array): { worst: number; mean: number } {
  let worst = 0;
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const d = Math.abs(a[i] - b[i]);
    sum += d;
    if (d > worst) worst = d;
  }
  return { worst, mean: sum / a.length };
}

function flipRows(img: Float32Array, w: number, h: number): Float32Array {
  const out = new Float32Array(img.length);
  for (let y = 0; y < h; y++) out.set(img.subarray(y * w * 4, (y + 1) * w * 4), (h - 1 - y) * w * 4);
  return out;
}

async function run() {
  const m: TruthManifest = await (await fetch('/tests/fixtures/comp/manifest.json')).json();
  const { width: W, height: H } = m;

  const renderer = new WebGPURenderer({ antialias: false });
  await renderer.init();
  renderer.setPixelRatio(1);
  renderer.setSize(W, H, false);

  const inputs = new Map<string, CompImage>();
  const textures = new Map<string, DataTexture>();
  for (const key of m.inputs) {
    const img = await loadF32(`/tests/fixtures/comp/in_${key}.f32`, W, H);
    inputs.set(key, img);
    const t = new DataTexture(img.data, W, H, RGBAFormat, FloatType);
    t.minFilter = LinearFilter;
    t.magFilter = LinearFilter;
    t.wrapS = ClampToEdgeWrapping;
    t.wrapT = ClampToEdgeWrapping;
    t.colorSpace = NoColorSpace;
    t.flipY = false;
    t.needsUpdate = true;
    textures.set(key, t);
  }

  const scene = new Scene();
  const camera = new OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const finalRT = new RenderTarget(W, H, { type: FloatType, colorSpace: NoColorSpace, depthBuffer: false });

  // Orientation: read back a coordinate case first and decide whether the
  // readback rows are top-down or bottom-up relative to the CPU image.
  let flip = false;
  const results: Result[] = [];

  for (const k of m.cases) {
    const c = compGraph();
    const images = new Map<DataTexture, CompImage>();
    const img = (key: string) => {
      const t = textures.get(key)!;
      images.set(t, inputs.get(key)!);
      return c.image(t, 'stretch');
    };
    const out = buildTruthCase(c, k, img);

    const cpu = renderComp(out, { width: W, height: H, images });
    const blender = await loadF32(`/tests/fixtures/comp/out_${k.name}.f32`, W, H);

    const comp = new Compositor(renderer as never, scene, camera, out, { samples: 0, clearAlpha: 0 });
    comp.render(finalRT);
    const raw = (await renderer.readRenderTargetPixelsAsync(finalRT, 0, 0, W, H)) as Float32Array;
    comp.dispose();
    let gpu: Float32Array = new Float32Array(raw as ArrayLike<number>);

    if (k.node === 'coords' && k.mode === 'normalized') {
      const asIs = stats(gpu, cpu.data).worst;
      const flipped = stats(flipRows(gpu, W, H), cpu.data).worst;
      flip = flipped < asIs;
    }
    if (flip) gpu = flipRows(gpu, W, H);

    const gc = stats(gpu, cpu.data);
    const gb = stats(gpu, blender.data);
    const cb = stats(cpu.data, blender.data);
    const tol = GPU_TOL[k.node] ?? GPU_TOL_DEFAULT;
    const approx = TRUTH_APPROX[k.node];
    const blenderOk = approx ? gb.mean <= approx.mean * 1.5 && gb.worst <= approx.worst : gb.worst <= (TRUTH_TOL[k.node] ?? 1e-4) + tol;
    results.push({
      name: k.name,
      gpuVsCpu: gc.worst,
      gpuVsBlender: gb.worst,
      cpuVsBlender: cb.worst,
      meanGpuVsBlender: gb.mean,
      pass: gc.worst <= tol && blenderOk,
    });
  }

  // Custom nodes and the watercolour recipe: no Blender truth exists, so these
  // are GPU vs CPU only.
  const CUSTOM: { name: string; build: (c: CompGraph, src: CompInput) => CompInput; worst: number; mean: number }[] = [
    // custom nodes are bit-exact by construction (integer hash, shared fragment-centre convention)
    { name: 'custom:valueNoise', build: (c) => c.combine(valueNoise(c, c.coords('uniform'), 7), 0, 0, 1), worst: 1e-4, mean: 1e-5 },
    { name: 'custom:fbm', build: (c) => c.combine(fbm(c, c.coords('uniform'), 5), 0, 0, 1), worst: 1e-4, mean: 1e-5 },
    { name: 'custom:mangaTone', build: (c, src) => c.combine(mangaTone(c, c.luminance(src), 0.4), 0, 0, 1), worst: 1e-3, mean: 1e-5 },
    { name: 'custom:paperGrain', build: (c) => c.combine(c.add(paperGrain(c), 0.5), 0, 0, 1), worst: 1e-4, mean: 1e-5 },
    // the recipe runs through 12 displaces and log/exp over half-float stages; measured 1.9e-2 / 5e-5
    { name: 'recipe:watercolor', build: (c, src) => watercolorGraph(c, { source: src }), worst: 4e-2, mean: 5e-4 },
  ];
  for (const k of CUSTOM) {
    const c = compGraph();
    const images = new Map<DataTexture, CompImage>();
    const t = textures.get('photo')!;
    images.set(t, inputs.get('photo')!);
    const out = k.build(c, c.image(t, 'stretch'));
    const cpu = renderComp(out, { width: W, height: H, images });
    const comp = new Compositor(renderer as never, scene, camera, out, { samples: 0, clearAlpha: 0 });
    comp.render(finalRT);
    const raw = (await renderer.readRenderTargetPixelsAsync(finalRT, 0, 0, W, H)) as Float32Array;
    comp.dispose();
    let gpu: Float32Array = new Float32Array(raw as ArrayLike<number>);
    if (flip) gpu = flipRows(gpu, W, H);
    const gc = stats(gpu, cpu.data);
    results.push({ name: k.name, gpuVsCpu: gc.worst, gpuVsBlender: NaN, cpuVsBlender: NaN, meanGpuVsBlender: gc.mean, pass: gc.worst <= k.worst && gc.mean <= k.mean });
  }

  const failed = results.filter((r) => !r.pass);
  hud.innerHTML =
    `<b>${results.length - failed.length}/${results.length} agree (gpu vs cpu vs blender ${m.blender}, readback ${flip ? 'flipped' : 'as-is'})</b><br>` +
    results
      .map(
        (r) =>
          `<span style="color:${r.pass ? '#8f8' : '#f66'}">${r.pass ? 'ok  ' : 'FAIL'}</span> ` +
          `${r.name.padEnd(28, ' ')} gpu-cpu ${r.gpuVsCpu.toExponential(2)}  gpu-blender ${r.gpuVsBlender.toExponential(2)}  cpu-blender ${r.cpuVsBlender.toExponential(2)}`,
      )
      .join('<br>');
  Object.assign(window, { __probe: { results, failed: failed.length, flip } });
  (window as unknown as { __probeReady: boolean }).__probeReady = true;
}

run().catch((err) => {
  hud.textContent = `comp probe failed: ${err}`;
  hud.style.color = '#f66';
  console.error(err);
  (window as unknown as { __probeError: string }).__probeError = String(err);
});
