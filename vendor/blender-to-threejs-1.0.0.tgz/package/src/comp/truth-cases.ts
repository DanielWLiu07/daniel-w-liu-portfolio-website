/**
 * The Blender ground-truth cases, rebuilt as our graphs from the manifest that
 * tools/comp-truth/comp_truth.py writes. Shared by tests/comp-truth.test.ts
 * (CPU vs Blender) and src/comp-probe (GPU vs CPU vs Blender), so all three
 * backends are judged on the identical graph.
 */
import type { CompGraph } from './builder';
import type { CompInput } from './types';
import type { CompBlendType, FilterType } from './comp-ops';

export interface TruthCase {
  name: string;
  node: string;
  input?: string;
  [k: string]: unknown;
}
export interface TruthManifest {
  width: number;
  height: number;
  inputs: string[];
  blender: string;
  cases: TruthCase[];
}

/** Per-node tolerances against Blender (worst abs diff). */
export const TRUTH_TOL: Record<string, number> = { filter: 2e-3, blur: 2e-3, chain: 4e-3 };
/**
 * Displace is tagged approximate: Blender samples with an EWA anisotropic
 * filter, we sample bilinearly with the same zero-border ramp. Measured against
 * 4.5.3: mean |diff| ~0.003, worst ~0.12 on hard edges. Bounded, not exact.
 */
export const TRUTH_APPROX: Record<string, { mean: number; worst: number }> = { displace: { mean: 0.006, worst: 0.15 } };

/** Rebuild a manifest case as one of our graphs. `img(key)` yields an Image node for a named input. */
export function buildTruthCase(c: CompGraph, k: TruthCase, img: (key: string) => CompInput): CompInput {
  const src = () => img(k.input as string);
  const red = (x: CompInput) => c.separate(x, 'r');
  const asRed = (v: CompInput) => c.combine(v, 0, 0, 1);
  switch (k.node) {
    case 'filter':
      return c.filter(src(), k.type as FilterType, k.fac as number);
    case 'blur':
      return c.blur(src(), k.size as [number, number], k.type as 'GAUSS' | 'BOX' | 'TENT', { separable: k.separable as boolean });
    case 'displace':
      return c.displace(src(), img(k.vector as string), k.xScale as number, k.yScale as number);
    case 'hueSat':
      return c.hueSat(src(), k.hue as number, k.sat as number, k.val as number, k.fac as number);
    case 'brightContrast':
      return c.brightContrast(src(), k.bright as number, k.contrast as number);
    case 'gamma':
      return c.gamma(src(), k.gamma as number);
    case 'exposure':
      return c.exposure(src(), k.exposure as number);
    case 'posterize':
      return c.posterize(src(), k.steps as number);
    case 'invert':
      return c.invert(k.fac as number, src(), { color: k.color as boolean, alpha: k.alpha as boolean });
    case 'setAlpha':
      return c.setAlpha(src(), k.alpha as number, k.mode as 'REPLACE_ALPHA' | 'APPLY');
    case 'alphaOver':
      return c.alphaOver(k.fac as number, img(k.bg as string), img(k.fg as string), { straightAlpha: k.straightAlpha as boolean });
    case 'mix':
      return c.mix(k.blend as CompBlendType, k.fac as number, img(k.a as string), img(k.b as string), {
        useAlpha: k.useAlpha as boolean,
        clamp: k.clamp as boolean,
      });
    case 'ramp':
      return c.colorRamp(
        red(src()),
        (k.stops as { position: number; color: [number, number, number, number] }[]).map((s) => ({ position: s.position, color: s.color })),
        k.interpolation as 'LINEAR' | 'CONSTANT' | 'EASE',
      );
    case 'math':
      return asRed(c.math(k.op as string, red(src()), k.b as number, 0, { clamp: k.clamp as boolean }));
    case 'mapValue':
      return asRed(c.mapValue(red(src()), { offset: k.offset as number, size: k.size as number, min: k.min as number, max: k.max as number }));
    case 'mapRange':
      return asRed(c.mapRange(red(src()), { from: k.from as [number, number], to: k.to as [number, number], clamp: k.clamp as boolean }));
    case 'rgb2bw':
      return asRed(c.luminance(src()));
    case 'coords': {
      const co = c.coords(k.mode as 'normalized' | 'uniform' | 'pixel');
      return c.combine(c.separate(co, 'r'), c.separate(co, 'g'), 0, 1);
    }
    case 'chain': {
      const s = src();
      const b = c.blur(s, [3, 3], 'GAUSS', { separable: true });
      const hs = c.hueSat(b, 0.55, 1.4, 0.9, 0.8);
      const bw = c.luminance(s);
      const grey = c.combine(bw, bw, bw, 1);
      const f = c.filter(grey, 'SOBEL');
      const inv = c.invert(1, f, { color: true });
      return c.mix('MULTIPLY', 0.7, hs, inv);
    }
    default:
      throw new Error(`no builder for truth case '${k.node}'`);
  }
}

