/**
 * CPU evaluation of a compositor graph over a whole image.
 *
 * The reference backend. Every node's semantics come from comp-ops.ts (or the
 * shared shader ops), so this is the harness the GPU emitter is checked
 * against: build a graph, evaluate it on a small image, compare pixels.
 *
 * Fields. Every socket is a per-pixel field over the output domain: colours as
 * RGBA Float32 (4 per pixel), floats as 1 per pixel. A field whose inputs are
 * all constants stays a constant (`value` set, `data` absent), which is the
 * constant-folding the GPU path relies on to keep uniforms out of per-pixel
 * work. Kernel nodes force their input to a full buffer, then tap it with
 * Blender's texture_load clamp-to-bounds.
 */
import type { Texture } from 'three';
import {
  evalColorRamp,
  evalMath,
  mapRangeLinear,
  type ColorStop,
  type RampInterpolation,
  type Vec4,
} from '../transpiler/blender-ops';
import {
  alphaOver,
  blurPixel,
  blurWeights,
  blurWeights1D,
  brightContrast,
  displaceCoords,
  exposure,
  filterPixel,
  gamma,
  hueSatVal,
  invertComp,
  luminance,
  mapValue,
  mixRgb,
  posterize,
  setAlpha,
  type BlurFilterType,
  type CompBlendType,
  type FilterType,
} from './comp-ops';
import type { CustomNodeSpec } from './builder';
import { isCompColor, isCompNode, type CompInput, type CompNode, type CompValue } from './types';

export interface CompImage {
  width: number;
  height: number;
  /** RGBA, row-major, row 0 at the BOTTOM (Blender / GL convention). */
  data: Float32Array;
}

export interface CompEvalContext {
  width: number;
  height: number;
  /** The rendered scene for CompositorNodeRLayers 'image'. */
  renderLayer?: CompImage;
  /** World position per pixel for CompositorNodeRLayers 'position'. */
  positionLayer?: CompImage;
  /** Pixel data for CompositorNodeImage textures. */
  images?: Map<Texture, CompImage>;
  /** Runtime uniform overrides by name. */
  uniforms?: Record<string, number>;
  time?: number;
}

export interface Field {
  kind: 'color' | 'scalar';
  /** Constant value when the field does not vary per pixel. */
  value?: CompValue;
  /** Per-pixel data (4 floats per pixel for colour, 1 for scalar). */
  data?: Float32Array;
}

const isConst = (f: Field) => f.value !== undefined;

function readColor(f: Field, i: number): Vec4 {
  if (f.value !== undefined) {
    const v = f.value;
    return isCompColor(v) ? v : [v, v, v, 1];
  }
  const d = f.data!;
  if (f.kind === 'color') return [d[i * 4], d[i * 4 + 1], d[i * 4 + 2], d[i * 4 + 3]];
  const v = d[i];
  return [v, v, v, 1];
}

function readScalar(f: Field, i: number, where: string): number {
  if (f.value !== undefined) {
    if (isCompColor(f.value)) {
      throw new Error(`[comp] ${where} received a colour where a float was expected; take a channel explicitly.`);
    }
    return f.value;
  }
  if (f.kind === 'color') throw new Error(`[comp] ${where} received a colour where a float was expected; take a channel explicitly.`);
  return f.data![i];
}

/**
 * Sample a CompImage bilinearly at normalised coordinates. `border` selects the
 * sampler extend mode: 'edge' clamps texels to the image (GPU_SAMPLER_EXTEND_MODE_EXTEND),
 * 'zero' returns transparent black outside (CLAMP_TO_BORDER, what Displace uses).
 */
export function sampleBilinear(img: CompImage, u: number, v: number, border: 'edge' | 'zero' = 'edge'): Vec4 {
  const x = u * img.width - 0.5;
  const y = v * img.height - 0.5;
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const px = (xx: number, yy: number): Vec4 => {
    if (border === 'zero' && (xx < 0 || yy < 0 || xx >= img.width || yy >= img.height)) return [0, 0, 0, 0];
    const cx = Math.min(img.width - 1, Math.max(0, xx));
    const cy = Math.min(img.height - 1, Math.max(0, yy));
    const i = (cy * img.width + cx) * 4;
    return [img.data[i], img.data[i + 1], img.data[i + 2], img.data[i + 3]];
  };
  const a = px(x0, y0), b = px(x0 + 1, y0), c = px(x0, y0 + 1), d = px(x0 + 1, y0 + 1);
  const out: Vec4 = [0, 0, 0, 0];
  for (let k = 0; k < 4; k++) {
    const top = a[k] + (b[k] - a[k]) * fx;
    const bot = c[k] + (d[k] - c[k]) * fx;
    out[k] = top + (bot - top) * fy;
  }
  return out;
}

/** Displace border: 0.5 exactly on the image edge, 1 a quarter texel inside, 0 a quarter texel outside. */
export function displaceEdgeMask(tx: number, ty: number, w: number, h: number): number {
  const r = 0.25;
  const ramp = (d: number) => Math.min(1, Math.max(0, (d + r) / (2 * r)));
  return ramp(tx) * ramp(w - tx) * ramp(ty) * ramp(h - ty);
}

/** texture_load: integer texel fetch clamped to bounds. */
function loadTexel(img: CompImage, x: number, y: number): Vec4 {
  const cx = Math.min(img.width - 1, Math.max(0, x));
  const cy = Math.min(img.height - 1, Math.max(0, y));
  const i = (cy * img.width + cx) * 4;
  return [img.data[i], img.data[i + 1], img.data[i + 2], img.data[i + 3]];
}

/** Materialise a field as a full RGBA image over the context domain. */
export function fieldToImage(f: Field, ctx: CompEvalContext): CompImage {
  const n = ctx.width * ctx.height;
  const data = new Float32Array(n * 4);
  for (let i = 0; i < n; i++) data.set(readColor(f, i), i * 4);
  return { width: ctx.width, height: ctx.height, data };
}

export function evaluateComp(target: CompInput, ctx: CompEvalContext): Field {
  const memo = new Map<number, Field>();
  const n = ctx.width * ctx.height;

  const constField = (v: CompValue): Field => ({ kind: isCompColor(v) ? 'color' : 'scalar', value: v });

  const colorMap = (inputs: Field[], fn: (vals: Vec4[], i: number) => Vec4): Field => {
    if (inputs.every(isConst)) return { kind: 'color', value: fn(inputs.map((f) => readColor(f, 0)), 0) };
    const data = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) data.set(fn(inputs.map((f) => readColor(f, i)), i), i * 4);
    return { kind: 'color', data };
  };
  const scalarMap = (_inputs: Field[], fn: (i: number) => number, allConst: boolean): Field => {
    if (allConst) return { kind: 'scalar', value: fn(0) };
    const data = new Float32Array(n);
    for (let i = 0; i < n; i++) data[i] = fn(i);
    return { kind: 'scalar', data };
  };

  const ev = (input: CompInput): Field => {
    if (!isCompNode(input)) return constField(input);
    const hit = memo.get(input.id);
    if (hit) return hit;
    const out = evalNode(input);
    memo.set(input.id, out);
    return out;
  };

  const evalNode = (node: CompNode): Field => {
    const p = node.params;
    const ins = node.inputs.map(ev);
    switch (node.type) {
      case 'CompositorNodeRLayers': {
        const rl = p.pass === 'position' ? ctx.positionLayer : ctx.renderLayer;
        if (!rl) throw new Error(`[comp] evaluate: no ${p.pass === 'position' ? 'positionLayer' : 'renderLayer'} image in context`);
        if (rl.width !== ctx.width || rl.height !== ctx.height) throw new Error('[comp] renderLayer size differs from the domain');
        return { kind: 'color', data: rl.data };
      }
      case 'CompositorNodeImage': {
        const tex = p.texture as Texture;
        const img = ctx.images?.get(tex);
        if (!img) throw new Error('[comp] evaluate: no pixel data registered for the Image node texture');
        const fit = p.fit as string;
        const data = new Float32Array(n * 4);
        for (let y = 0; y < ctx.height; y++)
          for (let x = 0; x < ctx.width; x++) {
            const c =
              fit === 'tile'
                ? loadTexel(img, ((x % img.width) + img.width) % img.width, ((y % img.height) + img.height) % img.height)
                : sampleBilinear(img, (x + 0.5) / ctx.width, (y + 0.5) / ctx.height);
            data.set(c, (y * ctx.width + x) * 4);
          }
        return { kind: 'color', data };
      }
      case 'CompositorNodeValue': {
        const name = p.uniform as string | undefined;
        const v = name && ctx.uniforms && name in ctx.uniforms ? ctx.uniforms[name] : (p.value as number);
        return { kind: 'scalar', value: v };
      }
      case 'CompositorNodeRGB':
        return { kind: 'color', value: p.color as Vec4 };
      case 'CompositorNodeTime':
        return { kind: 'scalar', value: ctx.time ?? 0 };
      case 'CompositorNodeCoordinates': {
        const mode = p.mode as string;
        const data = new Float32Array(n * 4);
        const maxSize = Math.max(ctx.width, ctx.height);
        for (let y = 0; y < ctx.height; y++)
          for (let x = 0; x < ctx.width; x++) {
            let cx: number, cy: number;
            if (mode === 'pixel') {
              cx = x;
              cy = y;
            } else if (mode === 'uniform') {
              cx = ((x + 0.5 - ctx.width / 2) / maxSize) * 2;
              cy = ((y + 0.5 - ctx.height / 2) / maxSize) * 2;
            } else {
              cx = (x + 0.5) / ctx.width;
              cy = (y + 0.5) / ctx.height;
            }
            data.set([cx, cy, 0, 0], (y * ctx.width + x) * 4);
          }
        return { kind: 'color', data };
      }

      /* per-pixel */
      case 'CompositorNodeMixRGB': {
        const blend = p.blend as CompBlendType;
        const flags = { useAlpha: p.useAlpha as boolean, clamp: p.clamp as boolean };
        const [fac, a, b] = ins;
        if (ins.every(isConst)) return { kind: 'color', value: mixRgb(blend, readScalar(fac, 0, 'Mix.fac'), readColor(a, 0), readColor(b, 0), flags) };
        const data = new Float32Array(n * 4);
        for (let i = 0; i < n; i++) data.set(mixRgb(blend, readScalar(fac, i, 'Mix.fac'), readColor(a, i), readColor(b, i), flags), i * 4);
        return { kind: 'color', data };
      }
      case 'CompositorNodeMath': {
        const op = p.operation as string;
        const useClamp = p.useClamp as boolean;
        return scalarMap(
          ins,
          (i) => evalMath(op, readScalar(ins[0], i, 'Math.a'), readScalar(ins[1], i, 'Math.b'), readScalar(ins[2], i, 'Math.c'), useClamp),
          ins.every(isConst),
        );
      }
      case 'CompositorNodeValToRGB': {
        const stops = p.stops as ColorStop[];
        const interp = p.interpolation as RampInterpolation;
        const [fac] = ins;
        if (isConst(fac)) return { kind: 'color', value: evalColorRamp(readScalar(fac, 0, 'ColorRamp.fac'), stops, interp) };
        const data = new Float32Array(n * 4);
        for (let i = 0; i < n; i++) data.set(evalColorRamp(readScalar(fac, i, 'ColorRamp.fac'), stops, interp), i * 4);
        return { kind: 'color', data };
      }
      case 'CompositorNodeSeparateColor': {
        const ch = { r: 0, g: 1, b: 2, a: 3 }[p.channel as string]!;
        return scalarMap(ins, (i) => readColor(ins[0], i)[ch], isConst(ins[0]));
      }
      case 'CompositorNodeCombineColor':
        return colorMap(ins, (_, i) => [
          readScalar(ins[0], i, 'Combine.r'),
          readScalar(ins[1], i, 'Combine.g'),
          readScalar(ins[2], i, 'Combine.b'),
          readScalar(ins[3], i, 'Combine.a'),
        ]);
      case 'CompositorNodeInvert':
        return colorMap(ins, (_, i) => invertComp(readScalar(ins[0], i, 'Invert.fac'), readColor(ins[1], i), p.invertColor as boolean, p.invertAlpha as boolean));
      case 'CompositorNodeHueSat':
        return colorMap(ins, (_, i) =>
          hueSatVal(
            readColor(ins[0], i),
            readScalar(ins[1], i, 'HueSat.hue'),
            readScalar(ins[2], i, 'HueSat.saturation'),
            readScalar(ins[3], i, 'HueSat.value'),
            readScalar(ins[4], i, 'HueSat.fac'),
          ),
        );
      case 'CompositorNodeBrightContrast':
        return colorMap(ins, (_, i) => brightContrast(readColor(ins[0], i), readScalar(ins[1], i, 'BrightContrast.bright'), readScalar(ins[2], i, 'BrightContrast.contrast')));
      case 'CompositorNodeGamma':
        return colorMap(ins, (_, i) => gamma(readColor(ins[0], i), readScalar(ins[1], i, 'Gamma.gamma')));
      case 'CompositorNodeExposure':
        return colorMap(ins, (_, i) => exposure(readColor(ins[0], i), readScalar(ins[1], i, 'Exposure.exposure')));
      case 'CompositorNodePosterize':
        return colorMap(ins, (_, i) => posterize(readColor(ins[0], i), readScalar(ins[1], i, 'Posterize.steps')));
      case 'CompositorNodeAlphaOver':
        return colorMap(ins, (_, i) => alphaOver(readScalar(ins[0], i, 'AlphaOver.fac'), readColor(ins[1], i), readColor(ins[2], i), p.straightAlpha as boolean));
      case 'CompositorNodeSetAlpha':
        return colorMap(ins, (_, i) => setAlpha(readColor(ins[0], i), readScalar(ins[1], i, 'SetAlpha.alpha'), p.mode as 'REPLACE_ALPHA' | 'APPLY'));
      case 'CompositorNodeRGBToBW':
        return scalarMap(ins, (i) => luminance(readColor(ins[0], i)), isConst(ins[0]));
      case 'CompositorNodeMapValue':
        return scalarMap(
          ins,
          (i) =>
            mapValue(
              readScalar(ins[0], i, 'MapValue.value'),
              p.offset as number,
              p.size as number,
              p.useMin as boolean,
              p.min as number,
              p.useMax as boolean,
              p.max as number,
            ),
          isConst(ins[0]),
        );
      case 'CompositorNodeMapRange':
        return scalarMap(
          ins,
          (i) =>
            mapRangeLinear(
              readScalar(ins[0], i, 'MapRange.value'),
              p.fromMin as number,
              p.fromMax as number,
              p.toMin as number,
              p.toMax as number,
              p.clamp as boolean,
            ),
          isConst(ins[0]),
        );

      /* kernels */
      case 'CompositorNodeFilter': {
        const type = p.filterType as FilterType;
        const img = fieldToImage(ins[0], ctx);
        const data = new Float32Array(n * 4);
        for (let y = 0; y < ctx.height; y++)
          for (let x = 0; x < ctx.width; x++) {
            const i = y * ctx.width + x;
            const fac = readScalar(ins[1], i, 'Filter.fac');
            data.set(filterPixel(type, fac, (kx, ky) => loadTexel(img, x + kx - 1, y + ky - 1)), i * 4);
          }
        return { kind: 'color', data };
      }
      case 'CompositorNodeBlur': {
        const size = p.size as [number, number];
        const type = p.filterType as BlurFilterType;
        const img = fieldToImage(ins[0], ctx);
        if (p.separable) {
          // symmetric_separable_blur: horizontal pass into a buffer, then vertical
          const wx = blurWeights1D(type, size[0]);
          const wy = blurWeights1D(type, size[1]);
          const mid: CompImage = { width: ctx.width, height: ctx.height, data: new Float32Array(n * 4) };
          for (let y = 0; y < ctx.height; y++)
            for (let x = 0; x < ctx.width; x++) {
              const acc: Vec4 = [0, 0, 0, 0];
              const add = (c: Vec4, wgt: number) => {
                acc[0] += c[0] * wgt;
                acc[1] += c[1] * wgt;
                acc[2] += c[2] * wgt;
                acc[3] += c[3] * wgt;
              };
              add(loadTexel(img, x, y), wx[0]);
              for (let k = 1; k < wx.length; k++) {
                add(loadTexel(img, x + k, y), wx[k]);
                add(loadTexel(img, x - k, y), wx[k]);
              }
              mid.data.set(acc, (y * ctx.width + x) * 4);
            }
          const data = new Float32Array(n * 4);
          for (let y = 0; y < ctx.height; y++)
            for (let x = 0; x < ctx.width; x++) {
              const acc: Vec4 = [0, 0, 0, 0];
              const add = (c: Vec4, wgt: number) => {
                acc[0] += c[0] * wgt;
                acc[1] += c[1] * wgt;
                acc[2] += c[2] * wgt;
                acc[3] += c[3] * wgt;
              };
              add(loadTexel(mid, x, y), wy[0]);
              for (let k = 1; k < wy.length; k++) {
                add(loadTexel(mid, x, y + k), wy[k]);
                add(loadTexel(mid, x, y - k), wy[k]);
              }
              data.set(acc, (y * ctx.width + x) * 4);
            }
          return { kind: 'color', data };
        }
        const w = blurWeights(type, size);
        const data = new Float32Array(n * 4);
        for (let y = 0; y < ctx.height; y++)
          for (let x = 0; x < ctx.width; x++) {
            data.set(blurPixel(w, (dx, dy) => loadTexel(img, x + dx, y + dy)), (y * ctx.width + x) * 4);
          }
        return { kind: 'color', data };
      }
      case 'CompositorNodeDisplace': {
        const img = fieldToImage(ins[0], ctx);
        const data = new Float32Array(n * 4);
        for (let y = 0; y < ctx.height; y++)
          for (let x = 0; x < ctx.width; x++) {
            const i = y * ctx.width + x;
            const vec = readColor(ins[1], i);
            const sx = readScalar(ins[2], i, 'Displace.xScale');
            const sy = readScalar(ins[3], i, 'Displace.yScale');
            const [u, v] = displaceCoords([x, y], [ctx.width, ctx.height], [vec[0], vec[1]], [sx, sy]);
            // Blender samples EWA with a zero border. Measured against 4.5.3: the
            // border is a narrow ramp centred on the image edge (alpha 0.5 exactly
            // on the edge, full one quarter texel in), so: bilinear inside, times an
            // edge mask of half-width 0.25 texel. See COMP_FIDELITY (approximate).
            const m = displaceEdgeMask(u * ctx.width, v * ctx.height, ctx.width, ctx.height);
            const cIn = sampleBilinear(img, u, v, 'edge');
            data.set([cIn[0] * m, cIn[1] * m, cIn[2] * m, cIn[3] * m], i * 4);
          }
        return { kind: 'color', data };
      }

      case 'Custom': {
        const spec = p.spec as CustomNodeSpec;
        const kind = spec.kind;
        const time = ctx.time ?? 0;
        if (kind === 'color') {
          const data = new Float32Array(n * 4);
          for (let y = 0; y < ctx.height; y++)
            for (let x = 0; x < ctx.width; x++) {
              const i = y * ctx.width + x;
              const vals = ins.map((f) => (f.kind === 'color' ? readColor(f, i) : readScalar(f, i, spec.name)));
              const r = spec.cpu(vals, { x: x + 0.5, y: y + 0.5, width: ctx.width, height: ctx.height, time });
              data.set(isCompColor(r) ? r : [r, r, r, 1], i * 4);
            }
          return { kind: 'color', data };
        }
        const data = new Float32Array(n);
        for (let y = 0; y < ctx.height; y++)
          for (let x = 0; x < ctx.width; x++) {
            const i = y * ctx.width + x;
            const vals = ins.map((f) => (f.kind === 'color' ? readColor(f, i) : readScalar(f, i, spec.name)));
            const r = spec.cpu(vals, { x: x + 0.5, y: y + 0.5, width: ctx.width, height: ctx.height, time });
            data[i] = isCompColor(r) ? r[0] : r;
          }
        return { kind: 'scalar', data };
      }
      default:
        throw new Error(`[comp] evaluate: node type '${node.type}' has no evaluator`);
    }
  };

  return ev(target);
}

/** Evaluate and materialise as an RGBA image. */
export function renderComp(target: CompInput, ctx: CompEvalContext): CompImage {
  return fieldToImage(evaluateComp(target, ctx), ctx);
}

/** The node types this evaluator understands (parity test against the emitter). */
export const compEvaluableTypes = (): string[] => [
  'CompositorNodeRLayers',
  'CompositorNodeImage',
  'CompositorNodeValue',
  'CompositorNodeRGB',
  'CompositorNodeTime',
  'CompositorNodeCoordinates',
  'CompositorNodeMixRGB',
  'CompositorNodeMath',
  'CompositorNodeValToRGB',
  'CompositorNodeSeparateColor',
  'CompositorNodeCombineColor',
  'CompositorNodeInvert',
  'CompositorNodeHueSat',
  'CompositorNodeBrightContrast',
  'CompositorNodeGamma',
  'CompositorNodeExposure',
  'CompositorNodePosterize',
  'CompositorNodeAlphaOver',
  'CompositorNodeSetAlpha',
  'CompositorNodeRGBToBW',
  'CompositorNodeMapValue',
  'CompositorNodeMapRange',
  'CompositorNodeFilter',
  'CompositorNodeBlur',
  'CompositorNodeDisplace',
  'Custom',
];
