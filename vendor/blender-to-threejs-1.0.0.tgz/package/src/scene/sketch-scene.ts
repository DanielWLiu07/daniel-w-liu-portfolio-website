/**
 * The monkey_sketch.blend composition, DATA-DRIVEN from the N0 exporters:
 *  - public/assets/scene.json   camera / lights / per-object shading flags
 *                               (tools/export_scene.py — quaternions, C·M·C⁻¹)
 *  - public/assets/models/scene.glb  all mesh objects, subdiv applied,
 *                               transforms carried by the glTF nodes
 *
 * Only per-MATERIAL parameters live here (ink colors, band sharpness, AO
 * amounts — from the IR/spec section 6); transforms are never hand-copied.
 */
import {
  Color,
  DoubleSide,
  Mesh,
  NoColorSpace,
  PerspectiveCamera,
  Scene,
  SRGBColorSpace,
  TextureLoader,
  RepeatWrapping,
  Vector3,
} from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

import { createSketchMaterial, SketchMaterial } from '../recipes/sketch-material';
import { addOutlines } from '../recipes/outline-material';
import { MeshBasicNodeMaterial } from 'three/webgpu';
import type { SketchLight } from '../primitives/eevee-lighting';

interface SceneJSON {
  render: { resolution: [number, number]; view_transform: string };
  world_ambient: number | null;
  camera: {
    position: [number, number, number];
    quaternion: [number, number, number, number];
    vfov_deg: number;
    clip: [number, number];
  };
  lights: { name: string; kind: string; energy: number; dir_to_light_yup: [number, number, number] }[];
  objects: { name: string; shade_flat: boolean; materials: string[] }[];
}

/** Ink colors — Blender 'Colour' sockets, LINEAR (spec section 6). */
const INK_MONKEY: [number, number, number] = [0.1137, 0.7125, 0.0];
const INK_SPHERE: [number, number, number] = [0.0327, 0.2974, 0.7118];

/** Per-material params from the IR/spec; keyed by OBJECT name (GLB drops material names). */
const MATERIAL_PARAMS: Record<string, { ink: [number, number, number]; sharpness: number; aoAmount: number }> = {
  'Suzanne.001': { ink: INK_MONKEY, sharpness: 0.529, aoAmount: 1.0 * 0.7 },
  Suzanne: { ink: INK_MONKEY, sharpness: 0.529, aoAmount: 1.0 * 0.7 },
  Sphere: { ink: INK_SPHERE, sharpness: 0.580769, aoAmount: 0.724 * 0.7 },
};

export async function buildSketchScene() {
  const sceneData = (await (await fetch('/assets/scene.json')).json()) as SceneJSON;
  const [resX, resY] = sceneData.render.resolution;
  const aspect = resX / resY;

  const scene = new Scene();
  scene.background = new Color(0xffffff); // film_transparent=false, white bg

  // Camera straight from the exporter — position + QUATERNION, never lookAt/Euler.
  const cam = sceneData.camera;
  const camera = new PerspectiveCamera(cam.vfov_deg, aspect, cam.clip[0], cam.clip[1]);
  camera.position.set(...cam.position);
  camera.quaternion.set(...cam.quaternion);

  // Lights: exported surface->light dirs + energies feed the eeveeLighting primitive.
  const lights: SketchLight[] = sceneData.lights.map((l) => ({
    dir: new Vector3(...l.dir_to_light_yup).normalize(),
    energy: l.energy,
  }));
  const worldAmbient = sceneData.world_ambient ?? 0.05;

  const texLoader = new TextureLoader();
  const chaotic = await texLoader.loadAsync('/assets/textures/chaotic.png');
  chaotic.colorSpace = SRGBColorSpace; // Blender samples it sRGB too (spec section 8)
  chaotic.wrapS = chaotic.wrapT = RepeatWrapping;
  // UV-baked AO (AO-node EMIT bake, distance 0.20). LINEAR DATA — NoColorSpace,
  // or the sRGB decode darkens 0.7 -> 0.46 and the monkey goes gray (GOTCHAS).
  const suzanneAO = await texLoader.loadAsync('/assets/textures/suzanne_ao.png');
  suzanneAO.colorSpace = NoColorSpace;

  const shadeFlat = new Map(sceneData.objects.map((o) => [o.name, o.shade_flat]));

  const materials: Record<string, SketchMaterial> = {};
  function materialFor(name: string) {
    const params = MATERIAL_PARAMS[name];
    if (!params) return null;
    const mat = createSketchMaterial({
      inkColor: params.ink,
      hatchTexture: chaotic,
      bandsSharpness: params.sharpness,
      flatShade: shadeFlat.get(name) ? 1 : 0,
      // Only Suzanne.001 has a bake so far; the others degrade honestly to 'none'.
      aoStrategy: name === 'Suzanne.001' ? 'uv' : 'none',
      aoMap: name === 'Suzanne.001' ? suzanneAO : undefined,
      aoAmount: params.aoAmount,
      worldAmbient,
      lights,
      resolution: [resX, resY],
    });
    materials[name] = mat;
    return mat;
  }

  // Backdrop: "Background Sketch Shader" renders pure white from this camera
  // (spec section 5) — a white stand-in until that graph is transpiled. Its job
  // here is OCCLUSION: it clips the big monkey's lower half exactly like Blender.
  const backdropMat = new MeshBasicNodeMaterial();
  backdropMat.color = new Color(0xffffff);
  // The backdrop was authored with a negative scale (GOTCHAS: WebGPU crash /
  // flipped winding) — render both sides so it occludes regardless.
  backdropMat.side = DoubleSide;

  const gltf = await new GLTFLoader().loadAsync('/assets/models/scene.glb');
  const outlineTargets: Mesh[] = [];
  gltf.scene.traverse((o) => {
    const mesh = o as Mesh;
    if (!mesh.isMesh) return;
    // GLTF may rename nodes (dots -> underscores); match on the sanitized form.
    const name = [...Object.keys(MATERIAL_PARAMS), 'Plane'].find(
      (n) => mesh.name === n || mesh.name === n.replace(/[^A-Za-z0-9_]/g, ''),
    );
    if (name === 'Plane') {
      mesh.material = backdropMat;
      return; // no outline hull on the backdrop — it would rim the whole frame
    }
    const mat = name ? materialFor(name) : null;
    if (mat) {
      mesh.material = mat.material;
      outlineTargets.push(mesh);
    }
  });
  scene.add(gltf.scene);

  for (const mesh of outlineTargets) addOutlines(mesh, { thickness: 0.018 });

  return { scene, camera, materials, resolution: [resX, resY] as [number, number] };
}
