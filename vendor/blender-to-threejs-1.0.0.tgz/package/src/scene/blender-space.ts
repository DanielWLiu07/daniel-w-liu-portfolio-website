/**
 * Blender's world into Three's, for the parts a material port keeps needing and
 * every caller keeps rewriting: which way is up, and what a 50mm lens is.
 *
 * A ported MATERIAL is only half a ported look. The other half is the rig and
 * the camera, and both of those are stated in Blender's conventions: Z up, a
 * lens in millimetres against a sensor in millimetres, a horizontal field of
 * view when the render is landscape and a vertical one when it is not. Getting
 * any of that wrong shows up as "the shader looks off" and sends you back into
 * the node graph, which is the one place the problem is not.
 */
import { Matrix4, Vector3 } from 'three';

/**
 * Blender (x, y, z) -> Three (x, z, -y).
 *
 * The same convention glTF's `export_yup` uses, so a mesh exported that way and
 * a position converted here land in the same space. It is a rotation, so it can
 * be applied to a point, a direction or a bounding-box centre alike.
 */
export function blenderToThree(x: number, y: number, z: number): Vector3 {
  return new Vector3(x, z, -y);
}

/** The same conversion for a vector already in Blender's axes. */
export function vectorToThree(v: { x: number; y: number; z: number }): Vector3 {
  return blenderToThree(v.x, v.y, v.z);
}

/**
 * A whole Blender world matrix into Three's space.
 *
 * The axis swap is a change of BASIS, so a matrix has to be conjugated by it,
 * M_three = S * M_blender * S^-1, not merely have its translation swapped. Doing
 * only the translation puts an object in the right PLACE with the wrong
 * orientation, which on a symmetric model can look almost right.
 *
 * `rows` is Blender's matrix_world as row-major 4x4, which is what
 * `[list(r) for r in obj.matrix_world]` gives.
 */
export function blenderMatrixToThree(rows: number[][]): Matrix4 {
  // S: (x, y, z) -> (x, z, -y)
  const S = new Matrix4().set(1, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 1);
  const Sinv = new Matrix4().set(1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1);
  const m = new Matrix4().set(
    rows[0][0], rows[0][1], rows[0][2], rows[0][3],
    rows[1][0], rows[1][1], rows[1][2], rows[1][3],
    rows[2][0], rows[2][1], rows[2][2], rows[2][3],
    rows[3][0], rows[3][1], rows[3][2], rows[3][3],
  );
  return S.multiply(m).multiply(Sinv);
}

export interface BlenderCamera {
  /** camera.data.lens, millimetres */
  lens: number;
  /** camera.data.sensor_width, millimetres (Blender's default is 36) */
  sensorWidth?: number;
  /** camera.data.sensor_height, millimetres (Blender's default is 24) */
  sensorHeight?: number;
  /** camera.data.sensor_fit */
  sensorFit?: 'AUTO' | 'HORIZONTAL' | 'VERTICAL';
}

/**
 * Three's PerspectiveCamera.fov (VERTICAL, degrees) for a Blender camera at a
 * given viewport aspect.
 *
 * Blender states the field of view on whichever sensor axis `sensor_fit`
 * selects, and AUTO selects the LONGER side of the render, so the same camera is
 * horizontal-fit in landscape and vertical-fit in portrait. Three only ever
 * takes a vertical angle. Ignoring that is a silent framing error that grows
 * with how far the aspect is from 1, which is exactly the sort of thing that
 * gets blamed on the model.
 */
export function blenderFovY(cam: BlenderCamera, aspect: number): number {
  const sw = cam.sensorWidth ?? 36;
  const sh = cam.sensorHeight ?? 24;
  const fit = cam.sensorFit ?? 'AUTO';
  const horizontal = fit === 'HORIZONTAL' || (fit === 'AUTO' && aspect >= 1);
  if (horizontal) {
    const fovX = 2 * Math.atan(sw / (2 * cam.lens));
    return (2 * Math.atan(Math.tan(fovX / 2) / aspect) * 180) / Math.PI;
  }
  // vertical fit: the sensor height is the angle, and aspect does not enter
  return (2 * Math.atan(sh / (2 * cam.lens)) * 180) / Math.PI;
}

/** Blender's own horizontal field of view in degrees, for checking against the UI. */
export function blenderFovX(cam: BlenderCamera): number {
  const sw = cam.sensorWidth ?? 36;
  return (2 * Math.atan(sw / (2 * cam.lens)) * 180) / Math.PI;
}
