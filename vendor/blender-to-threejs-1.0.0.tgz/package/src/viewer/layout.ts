/**
 * Node-graph layout and SVG rendering for both domains (material graphs and
 * compositor graphs share the {id, type, params, inputs} shape).
 *
 * Draws the graph the way Blender's node editor would: one box per node with a
 * category-coloured header, Blender's node names, input sockets on the left
 * (literal defaults shown inline, links drawn as bezier wires), the output on
 * the right, and the parameters that matter as rows. Layout is by depth:
 * inputs to the left of what consumes them, siblings stacked.
 *
 * Pure functions: no DOM. The viewer page and the CLI both call renderSVG.
 */

export interface AnyNode {
  readonly id: number;
  readonly type: string;
  readonly params: Readonly<Record<string, unknown>>;
  readonly inputs: readonly (AnyNode | number | number[] | readonly number[])[];
}

const isNode = (x: unknown): x is AnyNode => typeof x === 'object' && x !== null && !Array.isArray(x);

/** Blender node names for every type we emit. */
export const LABELS: Record<string, string> = {
  // material graph
  ShaderNodeMath: 'Math',
  ShaderNodeMix: 'Mix',
  ShaderNodeMixRGB: 'Mix',
  ShaderNodeMapRange: 'Map Range',
  ShaderNodeValToRGB: 'Color Ramp',
  ShaderNodeInvert: 'Invert',
  ShaderNodeRGB: 'RGB',
  ShaderNodeValue: 'Value',
  ShaderNodeTexNoise: 'Noise Texture',
  ShaderNodeLayerWeight: 'Layer Weight',
  ShaderNodeFresnel: 'Fresnel',
  ShaderNodeMapping: 'Mapping',
  GraphSeparate: 'Separate XYZ',
  GraphCombine: 'Combine XYZ',
  GraphTexture: 'Image Texture',
  GraphUV: 'Texture Coordinate: UV',
  GraphPosition: 'Geometry: Position',
  GraphWindow: 'Texture Coordinate: Window',
  GraphNormal: 'Geometry: Normal',
  GraphVertexColor: 'Color Attribute',
  GraphTime: 'Value: Time',
  // compositor graph
  CompositorNodeRLayers: 'Render Layers',
  CompositorNodeImage: 'Image',
  CompositorNodeValue: 'Value',
  CompositorNodeRGB: 'RGB',
  CompositorNodeTime: 'Time',
  CompositorNodeCoordinates: 'Image Coordinates',
  CompositorNodeMixRGB: 'Mix',
  CompositorNodeMath: 'Math',
  CompositorNodeValToRGB: 'Color Ramp',
  CompositorNodeSeparateColor: 'Separate Color',
  CompositorNodeCombineColor: 'Combine Color',
  CompositorNodeInvert: 'Invert',
  CompositorNodeHueSat: 'Hue/Saturation/Value',
  CompositorNodeBrightContrast: 'Bright/Contrast',
  CompositorNodeGamma: 'Gamma',
  CompositorNodeExposure: 'Exposure',
  CompositorNodePosterize: 'Posterize',
  CompositorNodeAlphaOver: 'Alpha Over',
  CompositorNodeSetAlpha: 'Set Alpha',
  CompositorNodeRGBToBW: 'RGB to BW',
  CompositorNodeMapValue: 'Map Value',
  CompositorNodeMapRange: 'Map Range',
  CompositorNodeFilter: 'Filter',
  CompositorNodeBlur: 'Blur',
  CompositorNodeDisplace: 'Displace',
  Custom: 'Custom',
};

/** Input socket names, in builder order. */
export const SOCKETS: Record<string, string[]> = {
  ShaderNodeMath: ['Value', 'Value', 'Value'],
  ShaderNodeMix: ['Fac', 'A', 'B'],
  ShaderNodeMapRange: ['Value'],
  ShaderNodeValToRGB: ['Fac'],
  ShaderNodeInvert: ['Fac', 'Color'],
  ShaderNodeTexNoise: ['Vector', 'Scale'],
  ShaderNodeLayerWeight: ['Blend'],
  ShaderNodeFresnel: ['IOR'],
  ShaderNodeMapping: ['Vector'],
  GraphSeparate: ['Vector'],
  GraphCombine: ['X', 'Y', 'Z'],
  GraphTexture: ['Vector'],
  CompositorNodeMixRGB: ['Fac', 'Image', 'Image'],
  CompositorNodeMath: ['Value', 'Value', 'Value'],
  CompositorNodeValToRGB: ['Fac'],
  CompositorNodeSeparateColor: ['Image'],
  CompositorNodeCombineColor: ['Red', 'Green', 'Blue', 'Alpha'],
  CompositorNodeInvert: ['Fac', 'Color'],
  CompositorNodeHueSat: ['Image', 'Hue', 'Saturation', 'Value', 'Fac'],
  CompositorNodeBrightContrast: ['Image', 'Bright', 'Contrast'],
  CompositorNodeGamma: ['Image', 'Gamma'],
  CompositorNodeExposure: ['Image', 'Exposure'],
  CompositorNodePosterize: ['Image', 'Steps'],
  CompositorNodeAlphaOver: ['Fac', 'Background', 'Foreground'],
  CompositorNodeSetAlpha: ['Image', 'Alpha'],
  CompositorNodeRGBToBW: ['Image'],
  CompositorNodeMapValue: ['Value'],
  CompositorNodeMapRange: ['Value'],
  CompositorNodeFilter: ['Image', 'Fac'],
  CompositorNodeBlur: ['Image'],
  CompositorNodeDisplace: ['Image', 'Vector', 'X Scale', 'Y Scale'],
};

/** Header colour by Blender category. */
export function tint(type: string): string {
  if (/RLayers|Image$|GraphUV|GraphPosition|GraphWindow|GraphNormal|GraphVertexColor|GraphTime|Value|RGB$|Coordinates|Time$/.test(type)) return '#83314a'; // input
  if (/TexNoise|GraphTexture/.test(type)) return '#79461d'; // texture
  if (/Separate|Combine|Math|MapRange|MapValue|RGBToBW|Mapping/.test(type)) return '#246283'; // converter / vector
  if (/Filter|Blur|Displace/.test(type)) return '#3d3f66'; // filter
  if (/LayerWeight|Fresnel/.test(type)) return '#83314a';
  if (type === 'Custom') return '#5a5a5a';
  return '#a1a11f'; // colour
}

const NODE_W = 176;
const HEADER_H = 22;
const ROW_H = 17;
const COL_GAP = 70;
const ROW_GAP = 16;
const PAD = 20;

export interface LaidNode {
  id: number;
  type: string;
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  inputs: { name: string; literal: string | null; y: number }[];
  params: string[];
  outY: number;
}
export interface Edge {
  from: number;
  to: number;
  toIndex: number;
}
export interface Layout {
  nodes: LaidNode[];
  edges: Edge[];
  width: number;
  height: number;
}

const fmt = (v: unknown): string => {
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(3).replace(/0+$/, '').replace(/\.$/, '');
  if (typeof v === 'boolean') return v ? 'on' : 'off';
  if (typeof v === 'string') return v;
  if (Array.isArray(v)) return `[${v.map(fmt).join(', ')}]`;
  if (v && typeof v === 'object') {
    const o = v as Record<string, unknown>;
    if ('name' in o && typeof o.name === 'string') return o.name;
    if ('isTexture' in o) return 'texture';
    return '{..}';
  }
  return String(v);
};

/** Params worth showing per node (everything except textures/functions/long lists). */
function paramRows(node: AnyNode): string[] {
  const rows: string[] = [];
  for (const [k, v] of Object.entries(node.params)) {
    if (typeof v === 'function') continue;
    if (v && typeof v === 'object' && 'isTexture' in (v as object)) {
      rows.push(`${k}: ${((v as { name?: string }).name || 'texture')}`);
      continue;
    }
    if (k === 'stops' && Array.isArray(v)) {
      rows.push(`stops: ${v.length}`);
      for (const s of v as { position: number; color: number[] }[]) rows.push(`  ${fmt(s.position)}  ${s.color.map(fmt).join(' ')}`);
      continue;
    }
    if (k === 'spec' && v && typeof v === 'object') {
      rows.push(`${(v as { name: string }).name} (custom)`);
      continue;
    }
    if (v === undefined || v === null) continue;
    rows.push(`${k}: ${fmt(v)}`);
  }
  return rows;
}

export function layoutGraph(root: AnyNode): Layout {
  // depth = longest path from root; column = maxDepth - depth
  const depth = new Map<number, number>();
  const byId = new Map<number, AnyNode>();
  const visit = (n: AnyNode, d: number) => {
    byId.set(n.id, n);
    if ((depth.get(n.id) ?? -1) >= d) return;
    depth.set(n.id, d);
    for (const i of n.inputs) if (isNode(i)) visit(i, d + 1);
  };
  visit(root, 0);
  const maxDepth = Math.max(...depth.values());
  const columns: AnyNode[][] = Array.from({ length: maxDepth + 1 }, () => []);
  for (const [id, d] of depth) columns[maxDepth - d].push(byId.get(id)!);
  for (const col of columns) col.sort((a, b) => a.id - b.id);

  const nodes: LaidNode[] = [];
  const edges: Edge[] = [];
  const pos = new Map<number, LaidNode>();
  let width = PAD;
  let height = 0;
  columns.forEach((col, ci) => {
    let y = PAD;
    const x = PAD + ci * (NODE_W + COL_GAP);
    for (const n of col) {
      const sockets = SOCKETS[n.type] ?? n.inputs.map((_, i) => `in ${i}`);
      const params = paramRows(n);
      const inputs = n.inputs.map((inp, i) => ({
        name: sockets[i] ?? `in ${i}`,
        literal: isNode(inp) ? null : fmt(inp),
        y: 0,
      }));
      const h = HEADER_H + 6 + inputs.length * ROW_H + params.length * ROW_H + 8;
      const laid: LaidNode = {
        id: n.id,
        type: n.type,
        label: LABELS[n.type] ?? n.type,
        x,
        y,
        w: NODE_W,
        h,
        color: tint(n.type),
        inputs,
        params,
        outY: y + HEADER_H / 2,
      };
      laid.inputs.forEach((s, i) => {
        s.y = y + HEADER_H + 6 + i * ROW_H + ROW_H / 2;
      });
      nodes.push(laid);
      pos.set(n.id, laid);
      n.inputs.forEach((inp, i) => {
        if (isNode(inp)) edges.push({ from: inp.id, to: n.id, toIndex: i });
      });
      y += h + ROW_GAP;
    }
    width = Math.max(width, x + NODE_W + PAD);
    height = Math.max(height, y + PAD);
  });
  return { nodes, edges, width, height };
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/** SVG in Blender's dark node-editor palette. */
export function renderSVG(layout: Layout, title = ''): string {
  const byId = new Map(layout.nodes.map((n) => [n.id, n]));
  const out: string[] = [];
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${layout.width}" height="${layout.height + (title ? 28 : 0)}" viewBox="0 0 ${layout.width} ${layout.height + (title ? 28 : 0)}" font-family="ui-monospace, Menlo, monospace" font-size="11">`);
  out.push(`<rect width="100%" height="100%" fill="#1d1d1d"/>`);
  const ty = title ? 28 : 0;
  if (title) out.push(`<text x="${PAD}" y="18" fill="#ddd" font-size="13" font-weight="600">${esc(title)}</text>`);
  // wires
  for (const e of layout.edges) {
    const a = byId.get(e.from)!;
    const b = byId.get(e.to)!;
    const x1 = a.x + a.w, y1 = a.outY + ty;
    const x2 = b.x, y2 = b.inputs[e.toIndex].y + ty;
    const c = Math.max(30, (x2 - x1) / 2);
    out.push(`<path d="M${x1},${y1} C${x1 + c},${y1} ${x2 - c},${y2} ${x2},${y2}" fill="none" stroke="#c9c9c9" stroke-width="1.6" opacity="0.9"/>`);
  }
  for (const n of layout.nodes) {
    const y = n.y + ty;
    out.push(`<g>`);
    out.push(`<rect x="${n.x}" y="${y}" width="${n.w}" height="${n.h}" rx="5" fill="#303030" stroke="#0e0e0e"/>`);
    out.push(`<path d="M${n.x},${y + 5} a5,5 0 0 1 5,-5 h${n.w - 10} a5,5 0 0 1 5,5 v${HEADER_H - 5} h${-n.w} z" fill="${n.color}"/>`);
    out.push(`<text x="${n.x + 9}" y="${y + 15}" fill="#f2f2f2" font-weight="600">${esc(n.label)}</text>`);
    // output socket
    out.push(`<circle cx="${n.x + n.w}" cy="${n.outY + ty}" r="4.5" fill="#c7c729" stroke="#0e0e0e"/>`);
    n.inputs.forEach((s) => {
      const sy = s.y + ty;
      out.push(`<circle cx="${n.x}" cy="${sy}" r="4.5" fill="${s.literal === null ? '#63c763' : '#a1a1a1'}" stroke="#0e0e0e"/>`);
      const text = s.literal === null ? s.name : `${s.name}  ${s.literal}`;
      out.push(`<text x="${n.x + 12}" y="${sy + 4}" fill="#e6e6e6">${esc(text)}</text>`);
    });
    n.params.forEach((p, i) => {
      const py = y + HEADER_H + 6 + n.inputs.length * ROW_H + i * ROW_H + ROW_H / 2 + 4;
      out.push(`<text x="${n.x + 10}" y="${py}" fill="#9dc4e6">${esc(p)}</text>`);
    });
    out.push(`</g>`);
  }
  out.push(`</svg>`);
  return out.join('\n');
}

/**
 * Serialise a graph to plain JSON (textures become their names, functions are
 * dropped) so an application can hand it to the viewer through localStorage or
 * a URL without importing three.
 */
export function serializeGraph(root: AnyNode): string {
  const seen = new Map<number, unknown>();
  const ser = (n: AnyNode): unknown => {
    if (seen.has(n.id)) return { ref: n.id };
    const params: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(n.params)) {
      if (typeof v === 'function') continue;
      if (v && typeof v === 'object' && 'isTexture' in (v as object)) params[k] = { name: (v as { name?: string }).name || 'texture', isTexture: true };
      else if (k === 'spec' && v && typeof v === 'object') params[k] = { name: (v as { name: string }).name };
      else params[k] = v;
    }
    const obj = { id: n.id, type: n.type, params, inputs: n.inputs.map((i) => (isNode(i) ? ser(i) : i)) };
    seen.set(n.id, obj);
    return obj;
  };
  return JSON.stringify(ser(root));
}

/** Inverse of serializeGraph (refs re-linked). */
export function deserializeGraph(json: string): AnyNode {
  const nodes = new Map<number, AnyNode>();
  const rev = (o: unknown): AnyNode | number | number[] => {
    if (typeof o === 'number' || Array.isArray(o)) return o as number | number[];
    const r = o as { ref?: number; id: number; type: string; params: Record<string, unknown>; inputs: unknown[] };
    if (r.ref !== undefined) return nodes.get(r.ref)!;
    const inputs: (AnyNode | number | number[])[] = [];
    const node: AnyNode = { id: r.id, type: r.type, params: r.params, inputs };
    nodes.set(r.id, node);
    for (const i of r.inputs) inputs.push(rev(i));
    return node;
  };
  return rev(JSON.parse(json)) as AnyNode;
}

/**
 * Open a graph in the viewer from an application (any origin). The graph goes
 * over as base64 JSON in the URL hash; the viewer decodes it. Dev helper.
 */
export function openInViewer(root: AnyNode, opts: { viewer?: string; title?: string } = {}): string {
  const base = opts.viewer ?? 'http://localhost:5173/viewer.html';
  const url = `${base}?graph=custom${opts.title ? `&title=${encodeURIComponent(opts.title)}` : ''}#${btoa(encodeURIComponent(serializeGraph(root)))}`;
  if (typeof window !== 'undefined') window.open(url, '_blank');
  return url;
}
