/**
 * Node viewer page. `?graph=<name>` renders a registered graph (see registry.ts),
 * `?graph=custom` renders whatever an app put in localStorage['b2t-graph'] via
 * serializeGraph(). Exposes window.__viewerSVG for tools/graph-svg.mjs.
 */
import { deserializeGraph, layoutGraph, renderSVG } from './layout';
import { getGraph, listGraphs } from './registry';

const q = new URLSearchParams(location.search);
const root = document.getElementById('root') as HTMLDivElement;
const select = document.getElementById('pick') as HTMLSelectElement;
const about = document.getElementById('about') as HTMLDivElement;

for (const name of listGraphs()) {
  const o = document.createElement('option');
  o.value = name;
  o.textContent = name;
  select.appendChild(o);
}
if (localStorage.getItem('b2t-graph') || location.hash.length > 1) {
  const o = document.createElement('option');
  o.value = 'custom';
  o.textContent = 'custom (from app)';
  select.appendChild(o);
}

function show(name: string) {
  let node;
  let title = name;
  if (name === 'custom') {
    // handed over by an app: URL hash (works across origins) or localStorage
    const fromHash = location.hash.length > 1 ? decodeURIComponent(atob(location.hash.slice(1))) : null;
    const json = fromHash ?? localStorage.getItem('b2t-graph');
    if (!json) return;
    node = deserializeGraph(json);
    const t = q.get('title');
    about.textContent = t ? `${t} (from app)` : 'graph handed over by the application';
    if (t) title = t;
  } else {
    const entry = getGraph(name);
    if (!entry) {
      root.textContent = `unknown graph "${name}". Known: ${listGraphs().join(', ')}`;
      return;
    }
    node = entry.build();
    about.textContent = `${entry.domain}: ${entry.about}`;
    title = `${name}  [${entry.domain}]`;
  }
  const svg = renderSVG(layoutGraph(node), title);
  root.innerHTML = svg;
  (window as unknown as { __viewerSVG: string }).__viewerSVG = svg;
  (window as unknown as { __viewerReady: boolean }).__viewerReady = true;
  if (name !== 'custom') history.replaceState(null, '', `?graph=${encodeURIComponent(name)}`);
}

const initial = q.get('graph') ?? listGraphs()[0];
select.value = initial;
select.addEventListener('change', () => show(select.value));
show(initial);
