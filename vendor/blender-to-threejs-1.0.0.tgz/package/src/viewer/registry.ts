/**
 * Named graphs the viewer (and the CLI) can render: the material preview
 * demos, the shipped recipes, and anything an application registers at runtime
 * with registerGraph(). Names are what `?graph=` and `node tools/graph-svg.mjs`
 * take.
 */
import { graph } from '../graph/builder';
import { compGraph } from '../comp/builder';
import { DEMOS } from '../preview/graphs';
import { mangaGraph } from '../recipes/manga-comp';
import { watercolorGraph } from '../recipes/watercolor-comp';
import { feltMaterialGraph, watercolorMaterialGraph } from '../recipes/watercolor-material';
import { revealMask } from '../recipes/reveal';
import type { AnyNode } from './layout';

export interface GraphEntry {
  domain: 'material' | 'compositor';
  about: string;
  build: () => AnyNode;
}

const REGISTRY: Record<string, GraphEntry> = {};

export function registerGraph(name: string, entry: GraphEntry): void {
  REGISTRY[name] = entry;
}
export const listGraphs = (): string[] => Object.keys(REGISTRY);
export const getGraph = (name: string): GraphEntry | undefined => REGISTRY[name];

for (const [name, demo] of Object.entries(DEMOS)) {
  registerGraph(`preview:${name}`, { domain: 'material', about: demo.expect, build: () => demo.build() as AnyNode });
}
registerGraph('material:felt', {
  domain: 'material',
  about: 'green baize: noise fibre + mottling + Layer Weight rim, all Blender shader nodes',
  build: () => feltMaterialGraph(graph()) as AnyNode,
});
registerGraph('material:watercolor', {
  domain: 'material',
  about: 'per-object watercolour: paper wobble, pigment turbulence, posterised wash, edge darkening from geometry',
  build: () => watercolorMaterialGraph(graph()) as AnyNode,
});
registerGraph('material:reveal', {
  domain: 'material',
  about: "paint-in reveal mask swept by a grow uniform from an impact point (pomme's uGrow floor)",
  build: () => revealMask(graph(), { centre: [0, 0] }).mask as AnyNode,
});
registerGraph('comp:watercolor', {
  domain: 'compositor',
  about: "pomme's watercolour pass as a compositor graph",
  build: () => watercolorGraph(compGraph()) as AnyNode,
});
registerGraph('comp:manga', {
  domain: 'compositor',
  about: 'manga print: nested halftone and crosshatch on paper, with sobel ink lines',
  build: () => mangaGraph(compGraph()) as AnyNode,
});
registerGraph('comp:ink', {
  domain: 'compositor',
  about: 'sobel ink lines on paper',
  build: () => {
    const c = compGraph();
    const scene = c.renderLayer();
    const edges = c.filter(c.luminance(scene), 'SOBEL');
    const ink = c.mapRange(c.separate(edges, 'r'), { from: [0, 1.5], to: [0, 1], clamp: true });
    return c.blend(ink, c.rgb(0.96, 0.94, 0.88), c.rgb(0.07, 0.07, 0.07)) as AnyNode;
  },
});
