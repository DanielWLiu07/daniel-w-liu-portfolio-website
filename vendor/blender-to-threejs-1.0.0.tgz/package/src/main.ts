/**
 * Entry: WebGPU renderer (WebGL2 fallback is automatic), letterboxed to the
 * exact Blender render aspect, NoToneMapping + sRGB out (view transform Standard).
 */
import { NoToneMapping } from 'three';
import { WebGPURenderer } from 'three/webgpu';
import { buildSketchScene } from './scene/sketch-scene';
import { buildComparePanel } from './compare/compare';

const canvas = document.getElementById('gl') as HTMLCanvasElement;
const frame = document.getElementById('frame') as HTMLDivElement;
const hud = document.getElementById('hud') as HTMLDivElement;

async function init() {
  const renderer = new WebGPURenderer({ canvas, antialias: true });
  renderer.toneMapping = NoToneMapping; // Blender view transform: Standard
  await renderer.init();

  const { scene, camera, resolution } = await buildSketchScene();
  const aspect = resolution[0] / resolution[1];

  function resize() {
    // Letterbox: largest render-aspect rect that fits the window.
    const w = Math.min(window.innerWidth, window.innerHeight * aspect);
    frame.style.width = `${w}px`;
    frame.style.height = `${w / aspect}px`;
    renderer.setSize(frame.clientWidth, frame.clientHeight, false);
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    // camera.aspect stays the exported render aspect — the frame is letterboxed to it.
  }
  window.addEventListener('resize', resize);
  resize();

  renderer.setAnimationLoop(() => renderer.render(scene, camera));
  hud.textContent = `backend: ${renderer.backend.constructor.name}`;
  (window as unknown as { __sketch: object }).__sketch = { renderer, scene, camera };

  buildComparePanel({
    canvas,
    resolution,
    // renderAsync resolves after the frame is on the canvas — required for a
    // valid readback on the WebGPU backend (and harmless on WebGL2).
    renderOnce: () => renderer.renderAsync(scene, camera) as Promise<void>,
  });
}

init().catch((err) => {
  hud.textContent = `init failed: ${err}`;
  console.error(err);
});
