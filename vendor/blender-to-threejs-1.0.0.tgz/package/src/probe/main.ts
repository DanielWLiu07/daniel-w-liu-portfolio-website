/**
 * Cross-backend probe — does the GPU agree with the CPU?
 *
 * Renders each constant-only case to a 1x1 half-float target and compares the
 * readback against evaluate(). Half-float and NoColorSpace are deliberate: an
 * 8-bit sRGB target quantises to 1/255 and re-encodes on the way out, which
 * would hide small divergences behind rounding and make the rest look wrong.
 *
 * The comparison runs in the page, where both backends are reachable. Puppeteer
 * only harvests the verdict, so nothing depends on reading pixels off a
 * screenshot.
 */
import {
  HalfFloatType,
  Mesh,
  NoColorSpace,
  OrthographicCamera,
  PlaneGeometry,
  RenderTarget,
  Scene,
} from 'three';
import { MeshBasicNodeMaterial, WebGPURenderer } from 'three/webgpu';
import { float, vec3 } from 'three/tsl';

import { compile } from '../graph/compile';
import { evaluate } from '../graph/evaluate';
import { isColor } from '../graph/types';
import { CASES } from './cases';

const hud = document.getElementById('hud') as HTMLDivElement;

/** Half-float carries ~11 bits of mantissa; this is comfortably above its noise. */
const TOLERANCE = 1e-3;

/**
 * A half-float target reads back as a Uint16Array of raw bit patterns, not
 * decoded numbers — 0.3 arrives as 13516 (0x34CC).
 */
function halfToFloat(h: number): number {
  const sign = h & 0x8000 ? -1 : 1;
  const exponent = (h & 0x7c00) >> 10;
  const fraction = h & 0x03ff;
  if (exponent === 0) return sign * 2 ** -14 * (fraction / 1024); // subnormal
  if (exponent === 0x1f) return fraction ? NaN : sign * Infinity;
  return sign * 2 ** (exponent - 15) * (1 + fraction / 1024);
}

interface Result {
  name: string;
  cpu: number;
  gpu: number;
  delta: number;
  pass: boolean;
}

async function run() {
  const renderer = new WebGPURenderer({ antialias: false });
  await renderer.init();

  const target = new RenderTarget(1, 1, { type: HalfFloatType, colorSpace: NoColorSpace });
  const scene = new Scene();
  const camera = new OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const mesh = new Mesh(new PlaneGeometry(2, 2));
  scene.add(mesh);

  const results: Result[] = [];

  for (const c of CASES) {
    // CPU side. Alpha cases read component 3; everything else reads the first
    // channel, which for a scalar graph is the value itself.
    const value = evaluate(c.node);
    const cpu = c.channel === 'a'
      ? (isColor(value) ? value[3] : 1)
      : (isColor(value) ? value[0] : value);

    // GPU side. Route the channel under test into rgb so a 1x1 readback sees it.
    const emitted = compile(c.node);
    const material = new MeshBasicNodeMaterial();
    material.colorNode =
      c.channel === 'a'
        ? vec3(emitted.kind === 'color' ? emitted.node.w : float(1))
        : vec3(emitted.kind === 'color' ? emitted.node.x : emitted.node);
    mesh.material = material;

    renderer.setRenderTarget(target);
    await renderer.renderAsync(scene, camera);
    const pixels = await renderer.readRenderTargetPixelsAsync(target, 0, 0, 1, 1);
    renderer.setRenderTarget(null);

    // Decode only when the backend handed back raw half bits; a float target
    // would already be usable.
    const gpu = pixels instanceof Uint16Array ? halfToFloat(pixels[0]) : pixels[0];
    const delta = Math.abs(gpu - cpu);
    results.push({ name: c.name, cpu, gpu, delta, pass: delta <= TOLERANCE });
  }

  const failed = results.filter((r) => !r.pass);
  hud.innerHTML =
    `<b>${results.length - failed.length}/${results.length} agree</b> · ` +
    `${renderer.backend.constructor.name}<br>` +
    results
      .map(
        (r) =>
          `<span style="color:${r.pass ? '#8f8' : '#f66'}">${r.pass ? 'ok  ' : 'FAIL'}</span> ` +
          `${r.name.padEnd(30, ' ')} cpu ${r.cpu.toFixed(5)}  gpu ${r.gpu.toFixed(5)}`,
      )
      .join('<br>');

  Object.assign(window, { __probe: { results, failed: failed.length } });
  (window as unknown as { __probeReady: boolean }).__probeReady = true;
}

run().catch((err) => {
  hud.textContent = `probe failed: ${err}`;
  hud.style.color = '#f66';
  console.error(err);
  (window as unknown as { __probeError: string }).__probeError = String(err);
});
