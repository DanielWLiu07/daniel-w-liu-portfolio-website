/**
 * Cross-backend probe cases.
 *
 * Every case is a graph made only of constants, so the CPU evaluator produces an
 * exact expected value and the GPU renders a flat colour that can be read back
 * and compared. That is the check the parity test cannot make: parity proves
 * both backends know a node type, not that they agree on what it computes.
 *
 * Cases lean on guards and boundaries rather than happy paths — divergence in
 * the middle of a range is rare, at an edge case it is the norm.
 */
import { graph } from '../graph/builder';
import type { GraphNode } from '../graph/types';

export interface ProbeCase {
  name: string;
  node: GraphNode;
  /**
   * Which part of the result to compare. 'a' routes alpha into the colour so it
   * can be read back at all, since compileMaterial only ever shows rgb.
   */
  channel?: 'rgb' | 'a';
}

const g = graph();
const grey = (v: number) => [v, v, v, 1] as [number, number, number, number];

export const CASES: ProbeCase[] = [
  // --- Math guards ---
  { name: 'divide-by-zero', node: g.divide(0.75, 0) },
  { name: 'divide-normal', node: g.divide(0.6, 2) },
  { name: 'multiply-add', node: g.multiplyAdd(0.25, 0.5, 0.125) },
  { name: 'compare-within-epsilon', node: g.compare(0.5, 0.5000001) },
  { name: 'compare-outside-epsilon', node: g.compare(0.5, 0.6) },
  { name: 'greater-than-equal-is-false', node: g.greaterThan(0.5, 0.5) },
  { name: 'pingpong-mid', node: g.pingpong(1.5, 1) },
  { name: 'pingpong-zero-scale', node: g.pingpong(7, 0) },
  { name: 'clamp-on', node: g.add(0.9, 0.9, { clamp: true }) },

  // --- Domain guards. Blender returns 0 outside a domain rather than NaN, and
  //     a GPU select will not reliably discard a NaN, so each of these is a
  //     place the two backends can silently part company. ---
  { name: 'sqrt-negative', node: g.sqrt(-4) },
  { name: 'sqrt-positive', node: g.multiply(g.sqrt(0.25), 0.5) },
  { name: 'log-out-of-domain', node: g.log(-1, 2) },
  { name: 'log-normal', node: g.multiply(g.log(8, 2), 0.25) },
  { name: 'arcsine-out-of-domain', node: g.math('ARCSINE', 2) },
  { name: 'arccosine-out-of-domain', node: g.math('ARCCOSINE', -2) },
  { name: 'arctan2-origin', node: g.atan2(0, 0) },

  // --- POWER's negative-base branch ---
  { name: 'power-zero-exponent', node: g.pow(-3, 0) },
  { name: 'power-negative-base-even', node: g.multiply(g.pow(-2, 2), 0.125) },
  // abs() because a negative result may not survive the render-target readback.
  { name: 'power-negative-base-odd', node: g.multiply(g.abs(g.pow(-2, 3)), 0.0625) },
  { name: 'power-zero-base', node: g.pow(0, 5) },

  // --- MODULO truncates toward zero; FLOORED_MODULO floors. They disagree in
  //     sign for a negative dividend, which is easy to get backwards. ---
  { name: 'modulo-negative', node: g.multiply(g.abs(g.mod(-7, 3)), 0.25) },
  { name: 'floored-modulo-negative', node: g.multiply(g.math('FLOORED_MODULO', -7, 3), 0.25) },
  { name: 'modulo-zero-divisor', node: g.mod(7, 0) },
  { name: 'floored-modulo-zero-divisor', node: g.math('FLOORED_MODULO', 7, 0) },

  // --- Rounding family, where negatives separate the operations ---
  { name: 'fract-negative', node: g.fract(-0.25) },
  { name: 'floor-negative', node: g.multiply(g.floor(-0.5), -0.5) },
  { name: 'trunc-negative', node: g.abs(g.trunc(-1.75)) },
  { name: 'round-half', node: g.multiply(g.round(0.5), 0.5) },

  { name: 'snap', node: g.snap(1.7, 0.5) },
  { name: 'snap-zero-increment', node: g.snap(1.7, 0) },
  { name: 'wrap', node: g.wrap(5.5, 1, 0) },
  { name: 'wrap-zero-range', node: g.multiply(g.wrap(5.5, 2, 2), 0.25) },
  { name: 'smooth-min-zero-distance', node: g.multiply(g.smoothMin(0.3, 0.5, 0), 2) },
  { name: 'smooth-min-with-distance', node: g.smoothMin(0.3, 0.3, 1) },
  { name: 'sine', node: g.multiply(g.add(g.sin(1), 1), 0.4) },
  { name: 'cosine', node: g.multiply(g.add(g.cos(2), 1), 0.4) },

  // --- MapRange ---
  { name: 'maprange-descending-clamped', node: g.mapRange(2, { from: [0, 1], to: [0.9, 0.1], clamp: true }) },
  { name: 'maprange-ascending-clamped', node: g.mapRange(2, { from: [0, 1], to: [0.1, 0.9], clamp: true }) },
  { name: 'maprange-degenerate-clamped', node: g.mapRange(0.3, { from: [1, 1], to: [0.4, 0.8], clamp: true }) },
  { name: 'maprange-degenerate-unclamped', node: g.mapRange(0.3, { from: [1, 1], to: [0.4, 0.8] }) },

  // --- Mix ---
  { name: 'mix-clamp-factor', node: g.blend(1.5, grey(0), grey(0.8), { clampFactor: true }) },
  { name: 'mix-multiply', node: g.multiplyColor(1, grey(0.6), grey(0.5)) },
  { name: 'mix-overlay-low-branch', node: g.overlay(1, grey(0.25), grey(0.6)) },
  { name: 'mix-overlay-high-branch', node: g.overlay(1, grey(0.75), grey(0.6)) },
  // The exact boundary: Blender's branch tests `< 0.5`, so 0.5 takes the HIGH
  // branch. A step() mask with the wrong comparison flips only this one value.
  { name: 'mix-overlay-at-boundary', node: g.overlay(1, grey(0.5), grey(0.6)) },
  { name: 'mix-float-mode', node: g.overlay(1, 0.25, 0.6) },

  // --- Alpha (invisible through compileMaterial, so probed directly) ---
  {
    name: 'mix-clamp-result-alpha',
    node: g.blend(0, [0.2, 0.2, 0.2, 1.5], grey(0), { clampResult: true }),
    channel: 'a',
  },
  { name: 'mix-keeps-col1-alpha', node: g.blend(1, [0, 0, 0, 0.25], grey(1)), channel: 'a' },
  { name: 'invert-leaves-alpha', node: g.invert(1, [0.25, 0.5, 0.75, 0.3]), channel: 'a' },

  // --- Invert ---
  { name: 'invert-full', node: g.invert(1, grey(0.25)) },
  { name: 'invert-partial', node: g.invert(0.5, grey(0.2)) },

  // --- Noise Texture: the jenkins hash, perlin gradients and fbm must agree in u32 on both backends ---
  { name: 'noise-fac-origin-ish', node: g.noise(g.combine(0.37, -0.81, 0.12), { scale: 5, detail: 2 }) },
  { name: 'noise-fac-negative-lattice', node: g.noise(g.combine(-3.6, 2.2, -0.7), { scale: 3, detail: 3.5, roughness: 0.7, lacunarity: 2.5 }) },
  { name: 'noise-fac-distorted', node: g.noise(g.combine(0.9, 0.4, -1.3), { scale: 4, detail: 2, distortion: 1.2 }) },
  // un-normalised fbm can be negative; the probe reads a colour target, so lift by 1
  { name: 'noise-fac-unnormalised', node: g.add(g.noise(g.combine(0.5, 0.5, 0.5), { scale: 5, detail: 2, normalize: false }), 1) },
  { name: 'noise-detail-zero', node: g.noise(g.combine(1.1, -0.2, 0.3), { scale: 8, detail: 0 }) },
  { name: 'noise-color-g', node: g.separate(g.noise(g.combine(0.2, 0.7, -0.4), { scale: 5, detail: 2, output: 'color' }), 'y') },
  { name: 'noise-color-b', node: g.separate(g.noise(g.combine(0.2, 0.7, -0.4), { scale: 5, detail: 2, output: 'color' }), 'z') },

  // --- Mapping ---
  {
    name: 'mapping-point-x',
    node: g.separate(g.mapping(g.combine(0.4, -0.3, 0.2), { type: 'POINT', location: [0.3, -0.2, 0.1], rotation: [0.2, 0.4, 0.6], scale: [1.5, 0.8, 1] }), 'x'),
  },
  {
    name: 'mapping-texture-y',
    node: g.add(g.separate(g.mapping(g.combine(0.4, -0.3, 0.2), { type: 'TEXTURE', location: [0.3, -0.2, 0.1], rotation: [0.2, 0.4, 0.6], scale: [1.5, 0.8, 2] }), 'y'), 1),
  },
  {
    name: 'mapping-normal-z',
    node: g.separate(g.mapping(g.combine(0.4, -0.3, 0.2), { type: 'NORMAL', rotation: [0.2, 0.4, 0.6], scale: [1.5, 0.8, 1] }), 'z'),
  },

  // --- Gamma: the per-channel guard on non-positive values ---
  { name: 'gamma-0.45', node: g.separate(g.gamma(grey(0.35), 0.4545), 'x') },
  { name: 'gamma-2.2', node: g.separate(g.gamma(grey(0.8), 2.2), 'x') },

  // --- Vector Math: the guarded paths are where two backends can diverge ---
  { name: 'vecmath-divide-zero-x', node: g.separate(g.vectorMath('DIVIDE', grey(0.6), [0, 0, 0, 1]), 'x') },
  { name: 'vecmath-normalize-zero-x', node: g.separate(g.vectorMath('NORMALIZE', [0, 0, 0, 1]), 'x') },
  { name: 'vecmath-modulo-y', node: g.add(g.separate(g.vectorMath('MODULO', [0.77, -0.4, 1.2, 1], [0.3, 0.3, 0.3, 1]), 'y'), 1) },
  { name: 'vecmath-power-y', node: g.add(g.separate(g.vectorMath('POWER', [0.5, -0.4, 1.2, 1], [2, 3, 0.5, 1]), 'y'), 1) },
  { name: 'vecmath-snap-y', node: g.add(g.separate(g.vectorMath('SNAP', [0.77, -0.4, 1.2, 1], [0.3, 0.3, 0.3, 1]), 'y'), 1) },
  { name: 'vecmath-wrap-x', node: g.add(g.separate(g.vectorMath('WRAP', [1.7, -0.4, 0.2, 1], [0.5, 0.5, 0.5, 1], [-0.5, -0.5, -0.5, 1]), 'x'), 1) },
  { name: 'vecmath-cross-z', node: g.add(g.separate(g.vectorMath('CROSS_PRODUCT', [0.37, -0.62, 0.4, 1], [0.5, 0.25, -0.75, 1]), 'z'), 1) },
  { name: 'vecmath-reflect-y', node: g.add(g.separate(g.vectorMath('REFLECT', [0.37, -0.62, 0.4, 1], [0.5, 0.25, -0.75, 1]), 'y'), 1) },
  { name: 'vecmath-faceforward-x', node: g.add(g.separate(g.vectorMath('FACEFORWARD', [0.37, -0.62, 0.4, 1], [0.5, 0.25, -0.75, 1], [1, 0, 0, 1]), 'x'), 1) },
  { name: 'vecmath-refract-x', node: g.add(g.separate(g.vectorMath('REFRACT', [0.37, -0.62, 0.4, 1], [0, 0, 1, 1], [0, 0, 0, 1], { scale: 0.8 }), 'x'), 1) },

  // --- Wave Texture: the three profile branches and the fbm distortion path ---
  { name: 'wave-bands-x-sin', node: g.wave(g.combine(0.37, -0.81, 0.12), { scale: 5 }) },
  { name: 'wave-bands-diag-sin', node: g.wave(g.combine(0.37, -0.81, 0.12), { scale: 3, bandsDirection: 'DIAGONAL' }) },
  { name: 'wave-bands-saw', node: g.wave(g.combine(0.9, 0.4, -1.3), { scale: 4, waveProfile: 'SAW' }) },
  { name: 'wave-bands-tri', node: g.wave(g.combine(0.9, 0.4, -1.3), { scale: 4, waveProfile: 'TRI' }) },
  { name: 'wave-rings-spherical', node: g.wave(g.combine(0.4, 0.25, -0.6), { scale: 4, waveType: 'RINGS', ringsDirection: 'SPHERICAL' }) },
  { name: 'wave-distorted', node: g.wave(g.combine(0.31, 0.52, 0.17), { scale: 5, distortion: 2, detailScale: 1.5 }) },
  { name: 'wave-phase', node: g.wave(g.combine(0.31, 0.52, 0.17), { scale: 5, phase: 1.7 }) },

  // --- Voronoi: the float-BITS hash is what must agree in u32 across backends ---
  { name: 'voronoi-f1-3d', node: g.voronoi(g.combine(0.37, -0.81, 0.12), { scale: 5 }) },
  { name: 'voronoi-f1-3d-rand05', node: g.voronoi(g.combine(0.9, 0.4, -1.3), { scale: 4, randomness: 0.5 }) },
  { name: 'voronoi-f1-2d-chebychev', node: g.voronoi(g.combine(0.37, -0.81, 0), { scale: 5, dimensions: '2D', metric: 'CHEBYCHEV' }) },
  { name: 'voronoi-edge-3d', node: g.voronoi(g.combine(0.31, 0.52, 0.17), { scale: 5, feature: 'DISTANCE_TO_EDGE' }) },
  { name: 'voronoi-smooth-mink', node: g.voronoi(g.combine(0.31, 0.52, 0.17), { scale: 4, feature: 'SMOOTH_F1', metric: 'MINKOWSKI', exponent: 2 }) },
  { name: 'voronoi-smooth-euclid', node: g.voronoi(g.combine(0.37, -0.81, 0.12), { scale: 4, feature: 'SMOOTH_F1' }) },

  // --- Mix: Screen and Linear Light. Linear Light is deliberately UNCLAMPED, so
  //     it is the one most likely to diverge if a backend clamps for it ---
  { name: 'mix-screen', node: g.separate(g.mix('SCREEN', 0.7, grey(0.4), [0.35, 0.6, 0.2, 1]), 'x') },
  { name: 'mix-screen-g', node: g.separate(g.mix('SCREEN', 0.7, grey(0.4), [0.35, 0.6, 0.2, 1]), 'y') },
  { name: 'mix-linear-light', node: g.separate(g.mix('LINEAR_LIGHT', 0.4268, grey(0.4), [0.35, 0.6, 0.2, 1]), 'x') },
  { name: 'mix-linear-light-over', node: g.separate(g.mix('LINEAR_LIGHT', 1, grey(0.9), [0.95, 0.95, 0.95, 1]), 'x') },
  { name: 'mix-linear-light-under', node: g.add(g.separate(g.mix('LINEAR_LIGHT', 1, grey(0.1), [0.02, 0.02, 0.02, 1]), 'x'), 1) },
];
