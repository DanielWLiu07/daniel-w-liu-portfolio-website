/**
 * Graph preview — the visual test bench.
 *
 * Unit tests catch wrong arithmetic but not a shader that compiles to the wrong
 * picture, so every graph needs somewhere to be looked at, interactively and
 * headlessly (tools/capture-preview.mjs).
 *
 * Orbiting matters more than it sounds: a shader tuned to one fixed angle can be
 * badly wrong from another — see the screen-space AO entry in GOTCHAS.md.
 *
 *   /preview.html?graph=bands&shape=plane
 */
import {
  Mesh,
  PerspectiveCamera,
  PlaneGeometry,
  Scene,
  SphereGeometry,
  TorusKnotGeometry,
} from 'three';
import { WebGPURenderer } from 'three/webgpu';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

import { compileMaterial } from '../graph/compile';
import { DEFAULT_DEMO, DEMOS } from './graphs';

const canvas = document.getElementById('gl') as HTMLCanvasElement;
const hud = document.getElementById('hud') as HTMLDivElement;

const params = new URLSearchParams(location.search);
const name = params.get('graph') ?? DEFAULT_DEMO;
const shape = params.get('shape') ?? 'sphere';

async function init() {
  const demo = DEMOS[name];
  if (!demo) {
    throw new Error(`unknown graph '${name}'. Available: ${Object.keys(DEMOS).join(', ')}`);
  }

  const renderer = new WebGPURenderer({ canvas, antialias: true });
  await renderer.init();

  const scene = new Scene();
  const camera = new PerspectiveCamera(45, 1, 0.1, 100);
  camera.position.set(0, 0, 3.2);

  // Shape choice is a measurement decision, not decoration. A sphere only shows
  // a slice of the UV range and curves it, so a UV-driven graph cannot be read
  // off it honestly — the plane shows the full 0..1 in both axes, flat. The knot
  // is for spotting bad normals and seams.
  const geometry =
    shape === 'knot'
      ? new TorusKnotGeometry(0.75, 0.26, 220, 32)
      : shape === 'plane'
        ? new PlaneGeometry(2, 2, 1, 1)
        : new SphereGeometry(1, 96, 64);

  const material = compileMaterial(demo.build());
  scene.add(new Mesh(geometry, material));

  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;

  function resize() {
    const size = Math.min(window.innerWidth, window.innerHeight);
    renderer.setSize(size, size, false);
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    camera.aspect = 1;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  renderer.setAnimationLoop(() => {
    controls.update();
    renderer.render(scene, camera);
  });

  hud.textContent = `${name} — ${demo.expect}  ·  ${renderer.backend.constructor.name}`;

  // The screenshot hook. renderAsync resolves only once the frame is actually on
  // the canvas, which a WebGPU readback needs and WebGL2 doesn't mind.
  Object.assign(window, {
    __preview: {
      renderOnce: () => renderer.renderAsync(scene, camera),
      demos: Object.keys(DEMOS),
      expect: demo.expect,
    },
  });
  (window as unknown as { __previewReady: boolean }).__previewReady = true;
}

init().catch((err) => {
  hud.textContent = `init failed: ${err}`;
  hud.style.color = '#f66';
  console.error(err);
  (window as unknown as { __previewError: string }).__previewError = String(err);
});
