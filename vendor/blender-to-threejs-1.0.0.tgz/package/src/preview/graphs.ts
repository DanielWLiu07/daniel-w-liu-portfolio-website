/**
 * Demo graphs for the preview page.
 *
 * These are chosen to be visually READABLE — if the emitter gets an operation
 * wrong, the sphere shows it rather than hiding it in a plausible gradient. The
 * clamped band in particular saturates over most of the surface, so an
 * order-aware clamp and a naive [0,1] clamp look nothing alike.
 */
import { DataTexture, NearestFilter, RGBAFormat, RepeatWrapping } from 'three';
import { graph } from '../graph/builder';
import type { GraphNode } from '../graph/types';

/**
 * A checkerboard built in memory, so the texture demo needs no asset on disk and
 * a wrong UV or filter setting is unmistakable rather than subtle. NearestFilter
 * keeps the edges hard — a blurry result means the sampler is not being fed what
 * we think it is.
 */
function checkerTexture(size = 8): DataTexture {
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const v = (x + y) % 2 === 0 ? 235 : 25;
      const i = (y * size + x) * 4;
      data[i] = data[i + 1] = data[i + 2] = v;
      data[i + 3] = 255;
    }
  }
  const tex = new DataTexture(data, size, size, RGBAFormat);
  tex.magFilter = NearestFilter;
  tex.minFilter = NearestFilter;
  tex.wrapS = tex.wrapT = RepeatWrapping;
  tex.needsUpdate = true;
  return tex;
}

export interface Demo {
  /** What you should see if the emitter is correct. */
  expect: string;
  build: () => GraphNode;
}

export const DEMOS: Record<string, Demo> = {
  'uv-gradient': {
    expect: 'red to blue left-to-right across the UVs',
    build: () => {
      const g = graph();
      return g.blend(g.separate(g.uv(), 'x'), g.rgb(1, 0, 0), g.rgb(0, 0, 1));
    },
  },

  bands: {
    expect: 'mostly saturated, with a narrow ramp near the left edge',
    build: () => {
      const g = graph();
      // A real band row from the sketch material. The output range runs well
      // past [0,1], so the clamp is doing visible work.
      const band = g.mapRange(g.separate(g.uv(), 'x'), {
        from: [0, 1],
        to: [-0.62, 4.56],
        clamp: true,
      });
      return g.blend(band, g.rgb(0.1, 0.1, 0.12), g.rgb(1, 0.95, 0.9));
    },
  },

  overlay: {
    expect: 'a soft S-curve in grey — darker at the left, brighter at the right',
    build: () => {
      const g = graph();
      // overlay(uv.x, 0.32) — the same shape sketch-material applies to shade.
      return g.overlay(1, g.separate(g.uv(), 'x'), 0.3205);
    },
  },

  pingpong: {
    // scale 1 gives a period of 2, so 6 units of input is 3 full cycles.
    expect: 'three triangle-wave cycles, linear ramps, no blowouts',
    build: () => {
      const g = graph();
      // PINGPONG is one of Blender's guarded ops; a wrong implementation
      // produces obvious banding or a hard seam.
      return g.pingpong(g.multiply(g.separate(g.uv(), 'x'), 6), 1);
    },
  },

  'safe-divide': {
    // The flagship claim, made visible. Blender's DIVIDE returns 0 when the
    // denominator is 0; a plain a/b returns Infinity, which propagates through
    // everything downstream. Uniform black means safe_divide held. Anything
    // else — white, NaN speckle, garbage — means it did not.
    expect: 'uniform black. any white or speckle means divide-by-zero leaked',
    build: () => {
      const g = graph();
      return g.divide(g.separate(g.uv(), 'x'), 0);
    },
  },

  texture: {
    expect: 'an 8x8 checkerboard, crisp, filling the UV square',
    build: () => {
      const g = graph();
      return g.texture(checkerTexture());
    },
  },

  'normal-check': {
    expect: 'smooth shading from the world normal — no facets, no flat colour',
    build: () => {
      const g = graph();
      // normal.y remapped from [-1,1] into [0,1] so the whole range is visible.
      return g.mapRange(g.separate(g.normal(), 'y'), { from: [-1, 1], to: [0, 1] });
    },
  },
};

export const DEFAULT_DEMO = 'uv-gradient';
